// Tailwind theme extension for Suiro AI. Colours reference the CSS variables in tokens.css,
// so light and dark mode switch without any "dark:" classes.
module.exports = {
  theme: {
    extend: {
      colors: {
        blue: { DEFAULT: "var(--blue)", 2: "var(--blue-2)", 3: "var(--blue-3)", 4: "var(--blue-4)", 5: "var(--blue-5)", wash: "var(--blue-wash)" },
        teal: { DEFAULT: "var(--teal)", wash: "var(--teal-wash)" },
        orange: { DEFAULT: "var(--orange)", ink: "var(--orange-ink)", wash: "var(--orange-wash)" },
        beige: { wash: "var(--beige-wash)" },
        green: { DEFAULT: "var(--green)", wash: "var(--green-wash)" },
        red: { DEFAULT: "var(--red)", wash: "var(--red-wash)" },
        ink: { DEFAULT: "var(--ink)", 2: "var(--ink-2)", 3: "var(--ink-3)" },
        line: "var(--line)",
        bg: "var(--bg)",
        surface: { DEFAULT: "var(--surface)", 2: "var(--surface-2)" },
        "on-blue": "var(--on-blue)",
      },
      spacing: { s1: "8px", s2: "16px", s3: "24px", s4: "32px", s5: "48px" },
      borderRadius: { sm: "8px", md: "12px", lg: "16px" },
      fontFamily: { sans: ["Inter", "ui-sans-serif", "system-ui", "-apple-system", "Segoe UI", "Roboto", "sans-serif"] },
      fontSize: {
        caption: ["12px", { fontWeight: "600" }],
        small: ["13px", { lineHeight: "1.5" }],
        base: ["15px", { lineHeight: "1.5" }],
        h3: ["16px", { fontWeight: "650" }],
        h2: ["20px", { lineHeight: "1.3", fontWeight: "650" }],
        h1: ["32px", { lineHeight: "1.2", fontWeight: "650", letterSpacing: "-0.01em" }],
        display: ["40px", { lineHeight: "1.1", fontWeight: "700", letterSpacing: "-0.02em" }],
      },
      maxWidth: { page: "1120px" },
      screens: { tablet: { max: "1000px" }, mobile: { max: "900px" } },
    },
  },
};
