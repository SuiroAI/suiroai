import * as React from "react"
import { addPropertyControls, ControlType, RenderTarget } from "framer"

/**
 * Suiro AI prototype, wrapped as a Framer code component.
 *
 * How to use
 * 1. In Framer: Assets > Code > New Component, name it "SuiroPrototype", paste this file.
 * 2. Drag the component onto the canvas and size it (the app is designed for about 1200 x 800 and up).
 * 3. In the properties panel, upload suiro-ai-prototype.html under "HTML file",
 *    or paste a URL to a hosted copy under "or URL".
 *
 * The prototype runs inside an iframe, so its own styles and scripts stay isolated from your Framer page.
 * To change the prototype itself, edit src/styles.css and src/app.js (see README.md), rebuild the single
 * file, and upload it again.
 *
 * @framerSupportedLayoutWidth any
 * @framerSupportedLayoutHeight any
 * @framerIntrinsicWidth 1200
 * @framerIntrinsicHeight 800
 */
interface Props {
    file?: string
    url?: string
    title?: string
    background?: string
    radius?: number
    style?: React.CSSProperties
}

export default function SuiroPrototype(props: Props) {
    const { file, url, title, background, radius, style } = props
    const src = url || file
    const onCanvas = RenderTarget.current() === RenderTarget.canvas

    const frame: React.CSSProperties = {
        width: "100%",
        height: "100%",
        overflow: "hidden",
        borderRadius: radius,
        background,
        ...style,
    }

    if (!src) {
        return (
            <div
                style={{
                    ...frame,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: 24,
                    textAlign: "center",
                    color: "#606060",
                    font: "500 14px Inter, system-ui, sans-serif",
                    border: "1.5px dashed #adb9e8",
                    boxSizing: "border-box",
                }}
            >
                Upload suiro-ai-prototype.html in the properties panel, or paste a URL.
            </div>
        )
    }

    return (
        <div style={frame}>
            <iframe
                title={title || "Suiro AI prototype"}
                src={src}
                // allow-downloads lets the CSV and shortlist downloads work
                sandbox="allow-scripts allow-same-origin allow-downloads allow-forms allow-popups"
                style={{
                    width: "100%",
                    height: "100%",
                    border: 0,
                    display: "block",
                    // Let Framer select and move the component on the canvas; the app is fully interactive in preview
                    pointerEvents: onCanvas ? "none" : "auto",
                }}
            />
        </div>
    )
}

SuiroPrototype.defaultProps = {
    title: "Suiro AI prototype",
    background: "#f7f8fc",
    radius: 0,
}

addPropertyControls(SuiroPrototype, {
    file: {
        type: ControlType.File,
        title: "HTML file",
        allowedFileTypes: ["html"],
    },
    url: {
        type: ControlType.String,
        title: "or URL",
        placeholder: "https://…",
    },
    title: {
        type: ControlType.String,
        title: "Title",
        defaultValue: "Suiro AI prototype",
    },
    background: {
        type: ControlType.Color,
        title: "Background",
        defaultValue: "#f7f8fc",
    },
    radius: {
        type: ControlType.Number,
        title: "Radius",
        min: 0,
        max: 48,
        defaultValue: 0,
    },
})
