# Suiro AI: developer handoff

Suiro AI helps a retail business answer a plain-language question, such as "What should I restock in my stores next week?", from the files it already has. It checks the data, compares forecasting methods in business terms, produces a report with alerts and an editable order list, collects named approvals, and delivers the result by download, email or schedule.

This package is a **working prototype plus the specs to build it for real**. The prototype is plain HTML, CSS and JavaScript with sample data and simulated back-end behaviour. Use it as the visual and behavioural reference. Do not ship its code.

## Start here

| If you want to... | Open |
| --- | --- |
| See the product | `prototype/suiro-ai-prototype.html` (double-click, no server needed) |
| See every colour, type style and component, light and dark | `design-system.html` |
| Understand the foundations | `docs/01-design-system.md` |
| Build a component | `docs/02-components.md` |
| Understand a screen or flow | `docs/03-screens-and-flows.md` |
| Implement the logic | `docs/04-business-rules.md` |
| Design the data and API | `docs/05-data-model-and-api.md`, `docs/types.d.ts` |
| Check accessibility | `docs/06-accessibility.md` |
| See what is still undecided | `docs/07-open-questions-and-risks.md` |
| Import tokens | `tokens/tokens.css`, `tokens/tokens.json`, `tokens/tailwind.theme.js` |
| See screenshots | `screenshots/` |

## What's in the package

```
README.md
design-system.html          Living style guide. Uses src/styles.css, so it never drifts from the product.
docs/                       Specs (numbered in reading order) and TypeScript types
tokens/                     Design tokens as CSS variables, JSON and a Tailwind theme
prototype/                  The prototype as one file
src/                        The prototype split into index.html, styles.css and app.js
build.mjs                   node build.mjs rebuilds prototype/suiro-ai-prototype.html from src/
screenshots/                22 screens and states (one in dark mode) and 4 presentation images
framer/                     A Framer code component that embeds the prototype
```

## How the prototype is built

- One state object `S` holds everything. `render()` redraws the page from it after every change. There is no framework and no build step.
- Sample data lives at the top of `src/app.js` (`PROD`, `PINFO`, `ROWS`, `DAYS`, `SUP`, `PEOPLE`, `MODELS`). Everything on screen is computed from it, so numbers agree across screens.
- Server behaviour is simulated: model runs, reminders, stock checks and email sends all use a "prototype clock" or timers. See "Simulated in the prototype" below.

## Simulated in the prototype (needs a real back end)

| Prototype behaviour | Production need |
| --- | --- |
| Sample sales, stock, costs and suppliers | File ingestion, validation and storage |
| Five forecasting models with illustrative scores | Real training and held-out evaluation. Metric definitions are in `docs/04-business-rules.md` |
| Timer-based model run | Job queue with progress and completion events |
| "Acting as (prototype)" role switcher | Real authentication. Every permission must be enforced on the server |
| Prototype clock and "Check now" | Scheduled jobs for reminders and stock checks |
| Simulated email, push and "Sent" status | Email and push providers, delivery events |
| Live web search on the Ideas tab (works only inside Claude) | A server-side search service with the same privacy rules |
| Example customer data and example expiry dates (toggles) | Remove the toggles. Show "Not enough data" until the data exists |

## Suggested build order

1. Tokens, then the foundation components (`docs/02-components.md`, "Foundations").
2. Upload, confirm and readiness (steps 1 and 2), with real file parsing.
3. The order list and its rules (step 5). This is the most complex screen, so start the data model here.
4. Approvals, permissions and delivery.
5. Models and the report tabs.
6. Alerts, reminders and notifications.
7. Ideas search last. It depends on legal and privacy decisions (`docs/07-open-questions-and-risks.md`).

## Conventions

- Sentence case everywhere. No jargon in labels. Say "Shortages caught", not "recall".
- If a number cannot be computed from the data, show "Not enough data" and say what would unlock it. Never guess.
- Anything shown as sample or example is labelled on screen.
- Light and dark are both required.

## Known issues fixed while preparing this handoff

- Colour contrast: tertiary text, teal text and green text failed WCAG AA in light mode. Added `--teal-ink` and `--green-ink` and darkened `--ink-3`. Measured ratios are in `docs/06-accessibility.md`.
- A stray `.bad` utility class turned any `.notice.bad` red and bold. Removed.
- Plain links used the browser's default blue in dark mode. Links now use `--blue`.
- The "Entries to review" tile shared a class name with the attention bar. Renamed to `.kpiwarn`.
