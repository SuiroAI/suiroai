/* ---------- Sample data (illustrative; replace with computed values) ---------- */
const ROLES=['Sales history','Stock on hand','Incoming shipments','Supplier rules','Other'];
function rng(seed){return function(){seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const R=rng(11);
const STORES=['LON-01','MUC-01','AUS-01','CHI-01'];
const SF=[1.2,1.0,.85,.55];
const SUP={Northwind:{minU:null,minV:30000,logic:'both'},Orbit:{minU:180,minV:null,logic:'both'},Helix:{minU:80,minV:4000,logic:'both'},Kestrel:{minU:120,minV:3500,logic:'either'}};
const PROD=[
{n:'AeroBook 14',sup:'Northwind',pack:1,base:6,season:'',cv:.22},
{n:'AeroBook 16',sup:'Northwind',pack:1,base:4,season:'',cv:.28},
{n:'Slate Tab 10',sup:'Northwind',pack:1,base:8,season:'Holiday run-up',cv:.35},
{n:'PulseBuds Pro',sup:'Orbit',pack:6,base:18,season:'Holiday run-up',cv:.31},
{n:'PulseBuds Lite',sup:'Orbit',pack:6,base:14,season:'Holiday run-up',cv:.33},
{n:'DockHub 7',sup:'Helix',pack:4,base:7,season:'',cv:.26},
{n:'DockHub 12',sup:'Helix',pack:4,base:4,season:'',cv:.52},
{n:'VoltCharge 65W',sup:'Helix',pack:10,base:16,season:'',cv:.24},
{n:'VoltCharge 30W',sup:'Helix',pack:10,base:12,season:'',cv:.27},
{n:'LumaDesk Lamp',sup:'Kestrel',pack:2,base:5,season:'',cv:.58},
{n:'ErgoMouse M2',sup:'Kestrel',pack:5,base:9,season:'',cv:.29},
{n:'KeyForge 75',sup:'Kestrel',pack:5,base:6,season:'',cv:.41},
{n:'USB-C Cable 2m',sup:'Orbit',pack:20,base:28,season:'',cv:.2},
{n:'Laptop Sleeve 14"',sup:'Kestrel',pack:10,base:12,season:'',cv:.45}];
const DATES=['19 Oct','12 Oct','5 Oct'];
const ROWS=[];
PROD.forEach((pr,p)=>STORES.forEach((st,s)=>{
 const weekly=Math.max(1,Math.round(pr.base*SF[s]*(.85+R()*.3)));
 const up=Math.round(pr.season?18+R()*30:-8+R()*30);
 const cover=+(0.2+Math.pow(R(),1.6)*8.5).toFixed(1);
 const onHand=Math.round(weekly*cover);
 const inc=R()<.3?Math.round(weekly*(.6+R())):0;
 const need=weekly*(1+up/100)*2.5-onHand-inc;
 const sug=need>0?Math.ceil(Math.round(need)/pr.pack)*pr.pack:0;
 const last=Math.max(pr.pack,Math.round(weekly*(1.2+R()*1.2)/pr.pack)*pr.pack);
 const ld=DATES[Math.floor(R()*3)];
 ROWS.push({p,s,sug,qty:sug,weekly,up,cover,onHand,inc,last,ld,big:sug>=1.5*last&&sug>=15,lowHist:s===3&&sug>0&&p%2===0,seasonal:!!pr.season&&up>=15,reviewed:false});
}));
const R2=rng(23);
const D0=Date.UTC(2026,0,3),NDAYS=289,DAY=86400000;
const DOWF=[1.17,.78,.82,.88,.95,1.12,1.28];
const SHARE=SF.map(x=>x/SF.reduce((a,c)=>a+c,0));
const OPEN=[0,0,0,NDAYS-63];
const PINFO=[['Laptops',1049,18],['Laptops',1399,18],['Tablets',429,14],['Audio',179,10],['Audio',79,10],['Accessories',89,22],['Accessories',139,9],['Accessories',59,20],['Accessories',39,20],['Desk',49,26],['Desk',49,12],['Desk',99,3],['Accessories',12,30],['Accessories',29,24]];
const PAVG=PROD.reduce((a,p,i)=>a+PINFO[i][1]*p.base,0)/PROD.reduce((a,p)=>a+p.base,0);
const PRICE=[1.06,1.02,.97,.95].map(x=>PAVG*x);
const CURPACE=ROWS.reduce((a,r)=>a+r.weekly,0)/7;
const KS=CURPACE/(41+(NDAYS-1)*.028+41*.18);
const DAYS=Array.from({length:NDAYS},(_,i)=>{const d=new Date(D0+i*DAY);const tr=KS*(41+i*.028+(i>=NDAYS-42?(i-(NDAYS-42))*.18:0));
  return {i,d,u:STORES.map((_,s)=>i<OPEN[s]?null:Math.round(tr*SHARE[s]*DOWF[d.getUTCDay()]*(.85+R2()*.3)))}});

const R3=rng(41);
ROWS.forEach((r,i)=>{r._i=i;const gap=7/Math.max(r.weekly,.5);r.idle=Math.round(gap*(.3+R3()*1.4));if(r.cover>=6&&r.weekly<=9)r.idle+=Math.round(18+R3()*70);r.idle=Math.min(r.idle,180)});
const SKINDS={std:{label:'Standard',unit:'days',win:30,freq:'weekly',what:'No sale in N days'},long:{label:'Long-life',unit:'days',win:90,freq:'quarterly',what:'No sale in N days'},perish:{label:'Perishable',unit:'days',win:7,freq:'daily',what:'Expires within N days'},tech:{label:'Tech (goes out of date)',unit:'months',win:15,freq:'monthly',what:'On sale over N months'}};
const FREQ={daily:['Daily',24],weekly:['Weekly',168],monthly:['Monthly',720],quarterly:['Quarterly',2160]};
const AL_DEF={Laptops:['tech',15,'monthly'],Tablets:['tech',24,'monthly'],Audio:['std',30,'weekly'],Accessories:['long',90,'quarterly'],Desk:['std',30,'weekly']};
const alDefaults=()=>({push:true,email:false,coverOn:false,coverWks:12,cats:Object.fromEntries(Object.entries(AL_DEF).map(([c,[k,w,f]])=>[c,{kind:k,win:w,freq:f}]))});
const MODELS=[
 {id:'avg',name:'Recent-sales average',tag:'Basic reference',acc:72,err:6.8,recall:71,unneeded:22,
  plain:'Assumes next week will look like the last few weeks. Fast and easy to explain, but it can’t react to a trend or to differences between stores.',
  feats:[['Average weekly sales, last 4 weeks',100,'Sales history']],
  best:'A sanity check. Hard to beat when demand is flat.',watch:'Misses uptrends, so it runs out of stock when demand rises.',
  m:{looks:'Sales only',trend:0,stores:1,explain:3}},
 {id:'lin',name:'Linear regression',tag:'Simple trend',acc:76,err:5.9,recall:76,unneeded:19,
  plain:'Draws a straight trend line through past sales. Works when demand is rising or falling steadily; struggles when it jumps around.',
  feats:[['Sales trend over time',55,'Sales history'],['Average weekly sales, last 4 weeks',30,'Sales history'],['Store',15,'Sales history']],
  best:'Steady products with a clear direction.',watch:'Treats every product with the same straight-line logic. Ignores stock and deliveries.',
  m:{looks:'Sales, store',trend:2,stores:2,explain:3}},
 {id:'cur',name:'Existing business method',tag:'Current practice',acc:78,err:5.4,recall:79,unneeded:17,
  plain:'Your current ordering rule, replayed on the same past weeks so you can see what you’d gain or lose by switching.',
  feats:[['Average weekly sales, last 2 weeks',60,'Sales history'],['Reorder point vs stock on hand',40,'Stock on hand']],
  best:'Familiar to your team. Reacts quickly to the last two weeks.',watch:'Over-reacts to one-off spikes and doesn’t use incoming deliveries.',
  m:{looks:'Sales, stock',trend:2,stores:2,explain:3}},
 {id:'rf',name:'Random forest',tag:'Best tested fit',acc:87,err:3.1,recall:93,unneeded:9,
  plain:'Asks many simple “if this, then that” questions about sales, stock and deliveries, then averages the answers. Copes well with uneven demand and differences between products and stores.',
  feats:[['Average weekly sales, last 4 weeks',29,'Sales history'],['Sales trend vs the month before',17,'Sales history'],['Weeks of stock cover',16,'Stock on hand'],['Store',11,'Sales history'],['Incoming deliveries',9,'Incoming shipments'],['Supplier lead time',8,'Supplier rules'],['Time of year (only 10 months of data)',6,'Sales history'],['Day-of-week sales mix',4,'Sales history']],
  best:'Mixed catalogues: steady items, lumpy items and new stores together.',watch:'Harder to explain a single order. Can’t extrapolate beyond demand it has seen, e.g. a brand-new product.',
  m:{looks:'Sales, stock, deliveries, supplier',trend:3,stores:3,explain:2}},
 {id:'xgb',name:'XGBoost',tag:'Close alternative',acc:85,err:3.4,recall:91,unneeded:10,
  plain:'Similar to a random forest, but each round of questions learns from the previous round’s mistakes. Often just as accurate, a little harder to explain.',
  feats:[['Sales trend vs the month before',26,'Sales history'],['Average weekly sales, last 4 weeks',24,'Sales history'],['Weeks of stock cover',15,'Stock on hand'],['Incoming deliveries',11,'Incoming shipments'],['Store',9,'Sales history'],['Supplier lead time',7,'Supplier rules'],['Time of year (only 10 months of data)',5,'Sales history'],['Day-of-week sales mix',3,'Sales history']],
  best:'Picking up recent changes in demand quickly.',watch:'Can over-fit with little history, such as the newest store.',
  m:{looks:'Sales, stock, deliveries, supplier',trend:3,stores:3,explain:1}}
];
const ORG='northlight-retail.example';
const PEOPLE=[
 {id:'alex',name:'Alex Rivera',role:'Business owner',owner:true,stores:[],email:'alex@'+ORG},
 {id:'priya',name:'Priya Nair',role:'Store manager',stores:['LON-01'],email:'priya@'+ORG},
 {id:'tom',name:'Tom Ellis',role:'Delegate',stores:['LON-01'],email:'tom@'+ORG},
 {id:'jonas',name:'Jonas Weber',role:'Store manager',stores:['MUC-01'],email:'jonas@'+ORG},
 {id:'dana',name:'Dana Ortiz',role:'Store manager',stores:['AUS-01','CHI-01'],email:'dana@'+ORG},
 {id:'marcus',name:'Marcus Bell',role:'Store manager',stores:['CHI-01'],email:'marcus@'+ORG},
 {id:'sam',name:'Sam Cole',role:'Viewer (finance)',stores:[],email:'sam@'+ORG}];
const MGR={'LON-01':'priya','MUC-01':'jonas','AUS-01':'dana','CHI-01':'marcus'};
const EXTERNAL=[{name:'Ledgerworks (accountant)',email:'accounts@ledgerworks.example'}];
const STEPS=['Upload data','Confirm task','Test models','Business report','Review and deliver'];

const S={
  step:1,
  question:'What should I restock in my stores next week?',
  files:[
    {id:1,name:'Sales_t_2_2025.csv',role:'Sales history',rows:48210,cols:7,range:'3 Jan – 18 Oct 2026'},
    {id:2,name:'inventory_position.csv',role:'Stock on hand',rows:1204,cols:5,range:'Snapshot 18 Oct 2026'},
    {id:3,name:'inbound_deliveries.csv',role:'Incoming shipments',rows:86,cols:6,range:'19 Oct – 15 Nov 2026'},
    {id:4,name:'ordering_policy.csv',role:'Supplier rules',rows:312,cols:4,range:'Current'}
  ],
  modelState:'idle', modelDone:0, model:'rf', tab:'summary',
  rv:{group:'store',sort:'qty',filter:'all',q:'',hideZero:true,collapsed:{},sup:''},
  rows:ROWS, notes:{}, openNote:null, general:'',
  clock:0, since:Object.fromEntries([...STORES,'owner'].map(k=>[k,0])), remSent:{}, escalated:{}, nudgeAt:{}, notifs:[], remOpen:false,
  rem:{on:true,n:24,unit:'hours',repeat:24,push:true,email:false,escalate:true},
  fold:{stock:false,pb:false}, ag:{}, agMore:{}, openFlags:{},
  al:alDefaults(), alNext:{}, stockSeen:new Set(), expPreview:false, alOpen:false, stk:{shown:6},
  stale:false, custPreview:false, pb:{saved:null,draft:{methods:[],text:''},hist:[]},
  prod:{q:'',cat:'all',f:'all',sort:'rev',shown:10},
  disc:{focus:[...new Set(PINFO.map(p=>p[0]))],adj:true,priceFit:true,src:{web:true,social:true,market:true},region:'all',vals:{},excl:'',vnote:'',showHidden:false,auto:true,ran:false,manual:false,sig:'',gOpen:false,sOpen:false,state:'idle',results:[],mode:'',msg:'',cat:'all',sort:'fit',shown:6,dismissed:[],sl:[],notes:{},run:null,ctrl:null},
  ch:{gran:'weekly',store:'all',measure:'units',avg:true}, pred:{f:'all',q:'',drv:'all',sort:'cv',shown:8,open:-1},
  supEdit:null, runBy:null, runNotify:{push:true,email:false}, runPending:false,
  user:'alex', log:[], supOpen:false, supQ:'', supOnly:true,
  appr:Object.fromEntries([...STORES,'owner'].map(k=>[k,{state:'pending',by:null,at:null}])),
  recip:new Set(['alex@'+ORG,'priya@'+ORG,'jonas@'+ORG,'dana@'+ORG,'marcus@'+ORG]), pending:[], scope:true, recMsg:null, arVal:'',
  always:new Set(['alex@'+ORG,'sam@'+ORG]), qsOpen:false, rq:'', sends:[], confirmSend:false, sendOpen:{},
  sched:{on:false,freq:'Weekly',day:'Monday',time:'07:00',to:'ops@example.com',needsApproval:true,saved:false}
};
let uid=10;

/* ---------- helpers ---------- */
const $=s=>document.querySelector(s);
const fmt=n=>n.toLocaleString('en-GB');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;$('#toast-slot').appendChild(t);setTimeout(()=>t.remove(),2600)}
const totalUnits=()=>S.rows.reduce((a,r)=>a+r.qty,0);
const skuCount=()=>new Set(S.rows.filter(r=>r.qty>0).map(r=>r.p)).size;
function issues(r){const a=[];const pr=PROD[r.p];if(r.big)a.push('Large vs usual restock');if(r.lowHist)a.push('Short history (new store)');if(r.qty%pr.pack)a.push('Not a full pack of '+pr.pack);if(r.qty>0&&isSlow(r))a.push('Ordering stock that isn’t moving');if(r.qty>0&&isOld(r))a.push('Ordering a model that may be going out of date');const er=expRisk(r._i);if(r.qty>0&&er)a.push('May expire before it sells');return a}
const needsReview=r=>issues(r).length>0&&!r.reviewed;
const toReview=()=>S.rows.filter(needsReview).length;
const edited=()=>S.rows.filter(r=>r.qty!==r.sug).length;
const THRESH=2.5;
const runway=r=>(r.onHand+r.inc)/(r.weekly*(1+r.up/100));
function watchDays(r){if(r.sug>0)return null;const rw=runway(r);if(rw>=THRESH+1)return null;return Math.max(1,Math.round((rw-THRESH)*7))}
const COST_F={Laptops:.78,Tablets:.74,Audio:.55,Accessories:.5,Desk:.52};
const NOCOST=new Set(['KeyForge 75','Laptop Sleeve 14"']);
function unitCost(p){return NOCOST.has(PROD[p].n)?null:Math.round(PINFO[p][1]*COST_F[PINFO[p][0]]*100)/100}
const lineCost=r=>{const c=unitCost(r.p);return c===null?null:r.qty*c};
const orderValue=()=>S.rows.reduce((a,r)=>a+(lineCost(r)||0),0);
const orderMissing=()=>S.rows.filter(r=>r.qty>0&&unitCost(r.p)===null).reduce((a,r)=>a+r.qty,0);
const money=n=>'$'+fmt(Math.round(n));
function supStat(name){
  const rs=S.rows.filter(r=>PROD[r.p].sup===name);const tot=rs.reduce((a,r)=>a+r.qty,0);
  let val=0,miss=0;rs.forEach(r=>{if(r.qty>0){const c=unitCost(r.p);if(c===null)miss+=r.qty;else val+=r.qty*c}});
  const m=SUP[name];const hasU=m.minU!=null,hasV=m.minV!=null,both=hasU&&hasV;
  const okU=!hasU||tot>=m.minU,okV=!hasV||val>=m.minV;
  const ok=tot===0||(!hasU&&!hasV)||(both?(m.logic==='either'?(okU||okV):(okU&&okV)):(hasU?okU:okV));
  const shortU=hasU?Math.max(0,m.minU-tot):0,shortV=hasV?Math.max(0,m.minV-val):0;
  const ru=hasU?shortU/m.minU:0,rv=hasV?shortV/m.minV:0;
  const gap=ok?0:Math.max(1,Math.round((both&&m.logic==='either'?Math.min(ru,rv):ru+rv)*100));
  return{name,tot,val,miss,partial:miss>0,minU:m.minU,minV:m.minV,logic:m.logic,both,okU,okV,ok,shortU,shortV,short:gap,none:tot===0}}
function supRule(s){const u=s.minU!=null?fmt(s.minU)+' units':null,v=s.minV!=null?money(s.minV):null;return u&&v?`${u} ${s.logic==='either'?'or':'and'} ${v}`:(u||v||'no minimum')}
function supNow(s){const p=[];if(s.minU!=null)p.push(fmt(s.tot)+' units');if(s.minV!=null)p.push(money(s.val)+(s.partial?'+':''));return p.join(' · ')}
const supRuleOf=n=>supRule({minU:SUP[n].minU,minV:SUP[n].minV,logic:SUP[n].logic});
function topUp(name){
  const s=supStat(name);if(s.ok||s.none)return '';
  const r=S.rows.filter(q=>PROD[q.p].sup===name&&unitCost(q.p)!==null).sort((a,b)=>b.weekly-a.weekly)[0];if(!r)return '';
  const c=unitCost(r.p),pk=PROD[r.p].pack;const cand=[];if(s.minU!=null)cand.push(s.shortU);if(s.minV!=null)cand.push(Math.ceil(s.shortV/c));
  const need=(s.both&&s.logic!=='either')?Math.max(...cand):Math.min(...cand);const q=Math.max(pk,Math.ceil(need/pk)*pk);
  return `For example, add about ${q} of ${PROD[r.p].n} (${STORES[r.s]}), your fastest seller from ${name}.`}
function supEditToggle(n){if(!me().owner)return;S.supEdit=S.supEdit===n?null:n;render()}
function setSupMin(n,key,val){
  if(!me().owner)return;const m=SUP[n];
  if(key==='logic')m.logic=val;else m[key]=(val===''||isNaN(parseFloat(val)))?null:Math.max(0,parseFloat(val));
  S.log.unshift(nowStr()+' · '+me().name+' changed the '+n+' minimum to '+supRuleOf(n));render()}
const supStats=()=>Object.keys(SUP).map(supStat);
const supShort=()=>supStats().filter(x=>x.short>0);
function rowSupShort(r){const s=supStat(PROD[r.p].sup);return r.qty>0&&s.short>0}
const has=r=>S.files.some(f=>f.role===r);
function readiness(){
  const need=[['Sales history','Needed to learn demand patterns.',true],['Stock on hand','Needed to avoid over-ordering.',true],['Incoming shipments','Stock already on its way is subtracted from the order.',false],['Supplier rules','Pack sizes are applied. Supplier minimums are checked, not forced.',false]];
  return need.map(([r,why,req])=>{
    const f=S.files.find(x=>x.role===r);
    if(!f) return {role:r,state:req?'bad':'warn',file:'—',detail:req?'Missing. Required to continue.':'Missing. The recommendation will skip this check.',why};
    if(r==='Supplier rules') return {role:r,state:'warn',file:f.name,detail:'Minimums found for all 4 suppliers. Unit cost is missing for 2 products, so order value is partial.',why};
    return {role:r,state:'ok',file:f.name,detail:'Ready · '+fmt(f.rows)+' rows, '+f.cols+' columns',why};
  });
}
const blocked=()=>readiness().some(r=>r.state==='bad')||!S.question.trim();
function maxStep(){if(blocked())return 1;if(S.modelState!=='done')return 3;return 5}
function go(n){if(n>maxStep()&&n>S.step)return;S.step=n;render();window.scrollTo({top:0})}

/* account menu */
function toggleMenu(force){
  const m=$('#acct-menu'),b=$('#acct-btn');const open=force!==undefined?force:m.hidden;
  m.hidden=!open;b.setAttribute('aria-expanded',open);
  if(open)toggleBell(false);
  if(open)setTimeout(()=>m.querySelector('a').focus(),0)
}
function menuGo(label){toggleMenu(false);event.preventDefault();toast(label==='Signed out'?'Signed out (prototype)':label+' (not in this prototype)')}
document.addEventListener('click',e=>{if(!e.target.isConnected)return;if(!e.target.closest('.acct-wrap'))toggleMenu(false);if(!e.target.closest('.bell-wrap'))toggleBell(false)});
document.addEventListener('keydown',e=>{
  const m=$('#acct-menu');if(m.hidden)return;
  if(e.key==='Escape'){toggleMenu(false);$('#acct-btn').focus()}
  if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const it=[...m.querySelectorAll('a')];const i=it.indexOf(document.activeElement);it[(i+(e.key==='ArrowDown'?1:-1)+it.length)%it.length].focus()}
});

/* ---------- Decision note: how the owner has decided this before ---------- */
const PBM=[['avg','Previous weekly average'],['lastyear','Same week last year'],['reorder','Fixed reorder points'],['supplier','Supplier minimums and pack sizes'],['gut','Experience or gut feel']];
const pbLabel=k=>(PBM.find(x=>x[0]===k)||[k,k])[1];
const stamp=()=>new Date().toLocaleString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
const baseQty=r=>{const need=r.weekly*THRESH-r.onHand-r.inc;const pk=PROD[r.p].pack;return need>0?Math.ceil(Math.round(need)/pk)*pk:0};
const pbUsesAvg=()=>!!(S.pb.saved&&S.pb.saved.methods.includes('avg'));
function pbDirty(){const s=S.pb.saved,d=S.pb.draft;return JSON.stringify([[...d.methods].sort(),d.text.trim()])!==JSON.stringify([s?[...s.methods].sort():[],s?s.text:''])}
function pbToggle(k){if(!me().owner)return;const m=S.pb.draft.methods;const i=m.indexOf(k);if(i>=0)m.splice(i,1);else m.push(k);render()}
function pbInput(v){S.pb.draft.text=v;const c=$('#pbc');if(c)c.textContent=v.length+' / 300';const u=$('#pbu');if(u)u.hidden=!pbDirty();const b=$('#pbs');if(b)b.disabled=!pbDirty()}
function pbSave(){
  if(!me().owner)return;const d=S.pb.draft;
  if(!d.methods.length&&!d.text.trim()){toast('Choose a method or write a note first');return}
  if(S.pb.saved)S.pb.hist.unshift(S.pb.saved);
  S.pb.saved={methods:[...d.methods],text:d.text.trim(),by:me().name,at:stamp(),forQ:S.question};
  S.log.unshift(nowStr()+' · '+me().name+' saved a note on how this decision was made before');
  render();toast('Saved. It now appears with the forecast and report.')
}
function pbRemove(){if(!me().owner||!S.pb.saved)return;S.pb.hist.unshift(S.pb.saved);S.pb.saved=null;S.pb.draft={methods:[],text:''};S.log.unshift(nowStr()+' · '+me().name+' removed the decision note');render();toast('Note removed')}
function pbRestore(i){if(!me().owner)return;const v=S.pb.hist[i];S.pb.draft={methods:[...v.methods],text:v.text};render()}
function pbCard(){
  const own=!!me().owner,pb=S.pb,d=pb.draft,s=pb.saved;
  const stale=s&&s.forQ.trim()!==S.question.trim();const dis=own?'':'disabled';
  return `<section class="card" aria-labelledby="pb-l">
   <div class="card-head"><div><h2 id="pb-l">How have you decided this before?</h2><p>Optional. A short note on how this decision has been made so far. We show it next to the forecast and compare against it where we can.</p></div><span class="status ${own?'teal':'idle'}">${own?'Business owner':'View only'}</span></div>
   ${stale?`<div class="notice warn"><div><p style="margin:0">Your question changed since this note was saved. It was written for “${esc(s.forQ)}”. Update the note if it no longer applies.</p></div></div>`:''}
   <div class="field-label" style="color:var(--ink)">What did you use?</div>
   <div class="chips" role="group" aria-label="Methods you have used">${PBM.map(([k,l])=>`<button aria-pressed="${d.methods.includes(k)}" ${dis} onclick="pbToggle('${k}')">${l}</button>`).join('')}</div>
   <div class="fld"><label for="pbt">Anything else about how you decide?</label><textarea id="pbt" maxlength="300" ${dis} placeholder="For example: Used the previous weekly average and rounded up to full cartons." oninput="pbInput(this.value)">${esc(d.text)}</textarea></div>
   <div class="summary" style="margin-top:12px"><span><span id="pbc" class="num">${d.text.length} / 300</span> · <span id="pbu" style="color:var(--orange-ink);font-weight:600" ${pbDirty()?'':'hidden'}>Unsaved changes</span>${!pbDirty()&&s?`<span>Saved by ${esc(s.by)} · ${s.at}</span>`:''}${!pbDirty()&&!s?'<span>Not saved yet</span>':''}</span>
    <span class="tools">${s&&own?'<button class="lnk" onclick="pbRemove()">Remove note</button>':''}<button class="btn sm primary" id="pbs" onclick="pbSave()" ${own&&pbDirty()?'':'disabled'}>Save note</button></span></div>
   ${own?'':'<p class="small muted" style="margin-top:8px">Only the business owner can add or edit this note.</p>'}
   ${pb.hist.length?`<details style="margin-top:12px"><summary>Earlier versions (${pb.hist.length})</summary><div style="margin-top:8px">${pb.hist.map((v,i)=>`<div class="ev"><span style="flex:1"><b>${v.methods.map(pbLabel).join(', ')||'No method chosen'}</b>${v.text?`<br><span class="muted small">“${esc(v.text)}”</span>`:''}<br><span class="small muted">${esc(v.by)} · ${v.at}</span></span>${own?`<button class="notebtn" onclick="pbRestore(${i})">Use as draft</button>`:''}</div>`).join('')}</div></details>`:''}
  </section>`;
}
function pbSummary(){
  const s=S.pb.saved;
  if(!s)return `<p class="small muted" style="margin-top:12px">No note on how you’ve decided this before. ${me().owner?'<a href="#" onclick="go(1);return false">Add one</a> to see a comparison in the report.':'The business owner can add one.'}</p>`;
  return `<div class="pbq" style="margin-top:16px"><b>How you’ve decided before:</b> ${s.methods.map(pbLabel).join(', ')||'Not specified'}${s.text?`<br><span class="muted">“${esc(s.text)}”</span>`:''}<div class="small muted" style="margin-top:4px">${esc(s.by)} · ${s.at} · <a href="#" onclick="go(1);return false">${me().owner?'Edit':'View'}</a></div></div>`;
}
function pbStrip(){
  const s=S.pb.saved;if(!s)return '';
  return `<div class="notice info"><div><p style="margin:0"><b>Usual method (${esc(s.by)}):</b> ${s.methods.map(pbLabel).join(', ')||'Not specified'}${s.text?` · “${esc(s.text)}”`:''}${pbUsesAvg()?' <button class="lnk" onclick="S.tab=\'summary\';go(4)">See how this order differs</button>':''}</p></div></div>`;
}
const subTag=x=>x.id==='cur'&&S.pb.saved&&S.pb.saved.methods.length?'Your method: '+S.pb.saved.methods.map(pbLabel).join(', ')+(pbUsesAvg()?'':' (estimated)'):x.tag;
function pbCompare(){
  const s=S.pb.saved;
  if(s&&!S.fold.pb){
    let sum='Reference note only. We can’t replay this method automatically.';
    if(pbUsesAvg()){const tb=S.rows.reduce((a,r)=>a+baseQty(r),0),ts=S.rows.reduce((a,r)=>a+r.sug,0);const pct=tb?Math.round((ts/tb-1)*100):0;sum=`Your usual method: ${fmt(tb)} units. This report: ${fmt(ts)} (${pct>=0?'+':''}${pct}%).`}
    return `<section class="card"><button class="foldh" aria-expanded="false" onclick="toggleFold('pb')"><div><h2>Compared with how you decided before</h2><p>${sum}</p></div><span class="chev" aria-hidden="true">▸</span></button></section>`}
  return pbCompareFull()}
function pbCompareFull(){
  const s=S.pb.saved;
  if(!s)return `<section class="card"><div class="card-head" style="margin-bottom:0"><div><h2>Compared with how you decided before</h2><p>Add a note on how you’ve made this decision so far and we’ll show where this report differs.</p></div>${me().owner?'<button class="btn sm" onclick="go(1)">Add a note</button>':'<span class="small muted">Ask the business owner</span>'}</div></section>`;
  const head=`<div class="pbq"><b>Your usual method:</b> ${s.methods.map(pbLabel).join(', ')||'Not specified'}${s.text?`<br><span class="muted">“${esc(s.text)}”</span>`:''}<div class="small muted" style="margin-top:4px">${esc(s.by)} · ${s.at}</div></div>`;
  let body='';
  if(pbUsesAvg()){
    const rows=S.rows.map(r=>({r,b:baseQty(r),d:r.sug-baseQty(r)}));
    const tb=rows.reduce((a,x)=>a+x.b,0),ts=rows.reduce((a,x)=>a+x.r.sug,0);const diff=rows.filter(x=>x.d!==0).sort((a,b)=>Math.abs(b.d)-Math.abs(a.d));
    const pct=tb?Math.round((ts/tb-1)*100):0;
    body=`<div class="grid4" style="margin-bottom:16px">
      <div class="stat"><h4>Your usual method</h4><div class="v num">${fmt(tb)} units</div><div class="basis">Previous weekly average</div></div>
      <div class="stat"><h4>This report</h4><div class="v num">${fmt(ts)} units</div><div class="basis">${ts-tb>=0?'+':''}${fmt(ts-tb)} (${pct>=0?'+':''}${pct}%)</div></div>
      <div class="stat"><h4>Entries that differ</h4><div class="v num">${diff.length}</div><div class="basis">of ${S.rows.length}</div></div>
      <div class="stat"><h4>Biggest gap</h4><div class="v num">${diff.length?(diff[0].d>0?'+':'')+diff[0].d:'0'}</div><div class="basis">${diff.length?esc(PROD[diff[0].r.p].n)+' · '+STORES[diff[0].r.s]:'None'}</div></div></div>
     ${diff.length?`<div class="tablewrap"><table><thead><tr><th>Product · store</th><th class="r">Usual method</th><th class="r">This report</th><th class="r">Difference</th><th>Why</th></tr></thead><tbody>
     ${diff.slice(0,5).map(x=>`<tr><td><b>${esc(PROD[x.r.p].n)}</b> · ${STORES[x.r.s]}</td><td class="r num">${x.b}</td><td class="r num">${x.r.sug}</td><td class="r num"><b>${x.d>0?'+':''}${x.d}</b></td><td class="small">${x.r.up>=15?'Recent demand is up '+x.r.up+'%, which an average misses':x.r.up<=-3?'Demand is slowing ('+x.r.up+'%)':'Recent trend ('+(x.r.up>0?'+':'')+x.r.up+'%) and pack rounding'}</td></tr>`).join('')}</tbody></table></div>`:'<p class="muted">This report matches your usual method on every entry.</p>'}
     <p class="small muted" style="margin-top:12px;max-width:70ch">Replayed with this week’s data. Your own calculation may round or adjust differently.${s.methods.includes('lastyear')?' We can’t replay “same week last year” because last year’s sales aren’t uploaded.':''}</p>`;
  }else if(s.methods.includes('lastyear')){
    body=`<div class="notice warn"><div><h3>We can’t replay this method yet</h3><p>“Same week last year” needs last year’s sales, which aren’t in your files. Your note is shown for reference.</p><button class="btn sm" onclick="$('#pick3').click()">+ Add last year’s sales</button></div></div>`;
  }else{
    body='<p class="muted" style="max-width:70ch">We can’t replay this method automatically, so your note is shown for reference. Reviewers can see it next to the order list.</p>';
  }
  return `<section class="card"><div class="card-head"><div><h2>Compared with how you decided before</h2><p>Where this report’s suggestions depart from your usual approach.</p></div><div class="btns" style="align-items:center">${me().owner?'<button class="btn ghost" onclick="go(1)">Edit note</button>':''}<button class="lnk" onclick="toggleFold('pb')">Collapse</button></div></div>${head}${body}</section>`;
}

/* ---------- Stock alerts: rules by category ---------- */
const ageDays=()=>Math.floor(S.clock/24);
const idleNow=r=>r.idle>=14?r.idle+ageDays():r.idle;
const monthsNow=r=>PINFO[r.p][2]+Math.floor(ageDays()/30);
const catOf=r=>PINFO[r.p][0];
const ruleOf=r=>S.al.cats[catOf(r)]||{kind:'std',win:30,freq:'weekly'};
const ruleText=k=>SKINDS[k.kind].what.replace('N',k.win);
const nextTxt=c=>{const h=Math.max(0,S.alNext[c]-S.clock);return h<1?'due now':h<48?'in '+Math.round(h)+' hours':'in '+Math.round(h/24)+' days'};
function expMap(){
  if(!S.expPreview)return {};
  const idx=S.rows.map((r,i)=>i).filter(i=>ruleOf(S.rows[i]).kind==='perish').sort((a,b)=>S.rows[b].onHand-S.rows[a].onHand).slice(0,6);
  const d=[6,14,23,41,58,90];const m={};idx.forEach((i,k)=>m[i]=d[k]);return m}
function expDays(i){const m=expMap();return m[i]===undefined?null:m[i]-ageDays()}
function isSlow(r){const k=ruleOf(r);return (k.kind==='std'||k.kind==='long')&&r.onHand>0&&(idleNow(r)>=k.win||(S.al.coverOn&&r.cover>=S.al.coverWks))}
function isOld(r){const k=ruleOf(r);return k.kind==='tech'&&r.onHand>0&&monthsNow(r)>=k.win}
function expRisk(i){
  const r=S.rows[i];const k=ruleOf(r);const d=expDays(i);if(k.kind!=='perish'||d===null||d>k.win)return null;
  const atRisk=d<=0?r.onHand:Math.max(0,r.onHand-Math.floor(r.weekly/7*d*(1+r.up/100)));
  return atRisk>0?{d,atRisk,expired:d<=0}:null}
function slowText(r){return idleNow(r)>=ruleOf(r).win?'No sale in '+idleNow(r)+'d':r.cover+' wks of cover'}
function stockChips(r){
  const out=[];
  if(isSlow(r))out.push(`<span class="chip warn" title="${r.onHand} units on hand. Last sale ${idleNow(r)} days ago.">${slowText(r)}</span>`);
  if(isOld(r))out.push(`<span class="chip warn" title="On sale for ${monthsNow(r)} months, past your ${ruleOf(r).win}-month limit for ${catOf(r)}. May be going out of date.">On sale ${monthsNow(r)} mo</span>`);
  const x=expRisk(r._i);if(x)out.push(`<span class="chip bad">${x.expired?'Expired':'Expires in '+x.d+'d'} · ${x.atRisk} at risk</span>`);
  return out}
function stockAdvice(r,kind,x){
  const o=S.rows.filter(q=>q.p===r.p&&q.s!==r.s&&q.weekly>=Math.max(4,r.weekly*2)).sort((a,b)=>b.weekly-a.weekly)[0];
  const tr=o?`Move some to ${STORES[o.s]}, which sells about ${o.weekly} a week.`:'';
  if(kind==='exp')return `About ${x.atRisk} units may ${x.expired?'be written off':'expire before they sell'}. ${tr||'Consider a markdown, bundle or return.'}`;
  if(kind==='old')return `${r.sug>0?'This week’s suggested order adds to it, so review. ':'Avoid large orders. '}${tr||'Consider a promotion to clear stock before a newer model arrives.'}`;
  return `${r.sug>0?'This week’s suggested order conflicts, so review it. ':'Skip reordering. '}${tr||'Consider a markdown or bundle.'}`}
function flagged(){return S.rows.map((r,i)=>({r,i,slow:isSlow(r),old:isOld(r),exp:expRisk(i)})).filter(o=>o.slow||o.old||o.exp)}
const TLAB={slow:'not moving',old:'going out of date',exp:'may expire'};
function processStockAlerts(silent,force){
  const A=S.al;const chan=A.push||A.email;const cur=new Set();
  const due=Object.keys(A.cats).filter(c=>silent||force||S.clock>=S.alNext[c]);
  const per={},roll={};
  flagged().forEach(o=>{const c=catOf(o.r),st=STORES[o.r.s];
    ['slow','old','exp'].forEach(t=>{if(!o[t])return;const k=o.i+':'+t;cur.add(k);
      if(silent||!due.includes(c))return;
      const kk=c+'|'+t;const isNew=!S.stockSeen.has(k);
      const e=((per[st]=per[st]||{})[kk]=per[st][kk]||{c,t,n:0,nw:0,soon:null});e.n++;if(isNew)e.nw++;
      const g=(roll[kk]=roll[kk]||{c,t,n:0,nw:0});g.n++;if(isNew)g.nw++;
      if(t==='exp')e.soon=e.soon===null?o.exp.d:Math.min(e.soon,o.exp.d)})});
  let people=0;
  const line=e=>`${e.c} ${e.n} ${TLAB[e.t]}${e.nw?` (${e.nw} new)`:''}`;
  if(!silent&&chan){
    Object.entries(per).forEach(([st,m])=>{const ap=approvers(st);notify(ap,`${st}: ${Object.values(m).map(line).join('; ')}.`,'stock');people+=ap.length});
    const rl=Object.values(roll);
    if(rl.length){const ow=PEOPLE.filter(p=>p.owner);notify(ow,rl.map(line).join('; ')+' across your stores.','stock');people+=ow.length;
      S.log.unshift(nowStr()+' · Stock check ('+[...new Set(rl.map(e=>e.c))].join(', ')+', '+[A.push&&'push',A.email&&'email'].filter(Boolean).join(' and ')+'): '+rl.map(line).join('; '))}
  }
  if(silent||chan){
    const ns=new Set();cur.forEach(k=>{const c=catOf(S.rows[+k.split(':')[0]]);if(silent||due.includes(c)||S.stockSeen.has(k))ns.add(k)});S.stockSeen=ns;
    due.forEach(c=>{S.alNext[c]=S.clock+FREQ[A.cats[c].freq][1]})}
  return people}
function setAl(key,val){
  if(!me().owner)return;
  if(key==='coverWks')val=Math.min(104,Math.max(1,parseInt(val)||1));
  S.al[key]=val;render()}
function setCat(c,key,val){
  if(!me().owner)return;const k=S.al.cats[c];
  if(key==='kind'){const d=SKINDS[val];k.kind=val;k.win=d.win;k.freq=d.freq}
  else if(key==='win'){const mx=SKINDS[k.kind].unit==='months'?120:365;k.win=Math.min(mx,Math.max(1,parseInt(val)||1))}
  else k.freq=val;
  S.alNext[c]=S.clock+FREQ[k.freq][1];render()}
function checkNow(){if(!me().owner)return;const n=processStockAlerts(false,true);render();toast(n?'Stock alert sent to '+n+(n===1?' person':' people'):'Nothing to alert on right now')}
function alReset(){if(!me().owner)return;S.al=alDefaults();S.stockSeen=new Set();processStockAlerts(true);render();toast('Alert settings reset')}
function stockCard(){
  if(S.fold.stock)return stockFull();
  const sl=S.rows.filter(isSlow).length,od=S.rows.filter(isOld).length,ex=S.rows.filter(r=>expRisk(r._i)).length;
  return `<section class="card" id="stock-alerts"><button class="foldh" aria-expanded="false" onclick="toggleFold('stock')"><div><h2>Stock that isn’t moving, may expire or is going out of date</h2><p>${sl} not moving · ${od} going out of date · ${ex} may expire. Limits are set by category.</p></div><span class="chev" aria-hidden="true">▸</span></button></section>`}
function stockFull(){
  const A=S.al,own=!!me().owner,dis=own?'':'disabled';
  const cats=Object.keys(A.cats);
  const slow=S.rows.filter(isSlow),old=S.rows.filter(isOld);
  const ex=S.rows.map((r,i)=>({r,x:expRisk(i)})).filter(o=>o.x);
  const val=(rs,f)=>rs.reduce((a,r)=>a+f(r),0);
  const hasKind=k=>cats.some(c=>A.cats[c].kind===k||(k==='slowish'&&['std','long'].includes(A.cats[c].kind)));
  const perish=cats.filter(c=>A.cats[c].kind==='perish');
  const items=[...ex.map(o=>({r:o.r,kind:'exp',x:o.x,val:o.x.atRisk*PINFO[o.r.p][1]})),...old.filter(r=>!expRisk(r._i)).map(r=>({r,kind:'old',val:r.onHand*PINFO[r.p][1]})),...slow.filter(r=>!expRisk(r._i)).map(r=>({r,kind:'slow',val:r.onHand*PINFO[r.p][1]}))];
  const catsWith=cats.filter(c=>items.some(o=>catOf(o.r)===c));
  const shownKeys=new Set(items.slice().sort((a,b)=>b.val-a.val).slice(0,S.stk.shown).map(o=>o.r._i+o.kind));
  const tile=(title,body,na)=>`<div class="stat ${na?'na':''}" style="border:1px solid var(--line);border-radius:var(--r-md);padding:var(--s2)"><h4>${title}</h4>${body}</div>`;
  const kindName=c=>SKINDS[A.cats[c].kind].label;
  const panel=S.alOpen?`<div class="alpanel">
    <div class="tablewrap"><table class="matrix"><thead><tr><th>Category</th><th>Stock type</th><th>Alert limit</th><th>Check</th><th>Next check</th></tr></thead><tbody>
    ${cats.map(c=>{const k=A.cats[c],kd=SKINDS[k.kind];const n=PROD.filter((p,i)=>PINFO[i][0]===c).length;
      return `<tr><td><b>${c}</b><div class="small muted">${n} ${n===1?'product':'products'}</div></td>
       <td><select aria-label="Stock type for ${c}" ${dis} onchange="setCat('${c}','kind',this.value)">${Object.entries(SKINDS).map(([id,d])=>`<option value="${id}" ${k.kind===id?'selected':''}>${d.label}</option>`).join('')}</select></td>
       <td><div style="display:flex;gap:8px;align-items:center"><input type="number" min="1" max="${kd.unit==='months'?120:365}" value="${k.win}" aria-label="Alert limit for ${c}" ${dis} style="max-width:80px;border:1px solid var(--line);border-radius:var(--r-sm);padding:8px;background:var(--surface)" onchange="setCat('${c}','win',this.value)"><span class="small muted">${kd.unit}</span></div><div class="small muted" style="margin-top:2px">${ruleText(k)}</div></td>
       <td><select aria-label="How often to check ${c}" ${dis} onchange="setCat('${c}','freq',this.value)">${Object.entries(FREQ).map(([id,f])=>`<option value="${id}" ${k.freq===id?'selected':''}>${f[0]}</option>`).join('')}</select></td>
       <td class="small">${nextTxt(c)}</td></tr>`}).join('')}</tbody></table></div>
    <div class="remgrid" style="margin-top:16px">
     <div class="fld"><label>Notify by</label><label class="check"><input type="checkbox" ${A.push?'checked':''} ${dis} onchange="setAl('push',this.checked)">Push notification</label><label class="check"><input type="checkbox" ${A.email?'checked':''} ${dis} onchange="setAl('email',this.checked)">Email</label></div>
     <div class="fld"><label>Extra check for Standard and Long-life</label><label class="check"><input type="checkbox" ${A.coverOn?'checked':''} ${dis} onchange="setAl('coverOn',this.checked)"><span>Also flag very high cover</span></label><div style="display:flex;gap:8px;align-items:center"><span class="small muted">Above</span><input id="al-cw" type="number" min="1" max="104" value="${A.coverWks}" ${own&&A.coverOn?'':'disabled'} style="max-width:80px;border:1px solid var(--line);border-radius:var(--r-sm);padding:8px;background:var(--surface)" onchange="setAl('coverWks',this.value)"><span class="small muted">weeks of cover</span></div></div></div>
    <div class="legend small muted" style="display:block;margin-top:12px"><b>Standard</b> and <b>Long-life</b> flag stock with no recent sales, with a longer limit for slow-selling goods such as toys. <b>Perishable</b> flags stock that may expire before it sells, and needs expiry dates. <b>Tech</b> flags products that have been on sale a long time and may be going out of date.</div>
    <p class="small muted" style="margin-top:8px">Store managers and delegates hear about their own stores. The business owner hears about all of them. Each category is checked on its own schedule and sends a summary only when something is flagged.</p>
    <div class="summary" style="margin-top:8px"><span class="small muted">${own?'Changing a type resets its limit and schedule to that type’s defaults.':'Only the business owner can change these settings.'}</span>${own?'<span class="tools"><button class="btn sm" onclick="checkNow()">Check now</button><button class="lnk" onclick="alReset()">Reset to defaults</button></span>':''}</div></div>`:'';
  return `<section class="card" id="stock-alerts"><div class="card-head"><div><h2>Stock that isn’t moving, may expire or is going out of date</h2><p>Each category has its own limit and check schedule. Values are at retail price.</p></div><div class="btns" style="align-items:center"><button class="btn sm" aria-expanded="${S.alOpen}" onclick="S.alOpen=!S.alOpen;render()">${S.alOpen?'Hide alert settings':'Alert settings'}</button><button class="lnk" onclick="toggleFold('stock')">Collapse</button></div></div>
   ${panel}
   <div class="kpis" style="margin-bottom:16px">
    ${tile('Not moving',hasKind('slowish')?`<div class="v num">${slow.length} ${slow.length===1?'entry':'entries'}</div><div class="basis">${fmt(val(slow,r=>r.onHand))} units · ${nf(val(slow,r=>r.onHand*PINFO[r.p][1]))} at retail</div>`:'<div class="v">Not used</div><div class="basis">No category is set to Standard or Long-life</div>',!hasKind('slowish'))}
    ${tile('Going out of date',hasKind('tech')?`<div class="v num">${old.length} ${old.length===1?'entry':'entries'}</div><div class="basis">${fmt(val(old,r=>r.onHand))} units · ${nf(val(old,r=>r.onHand*PINFO[r.p][1]))} at retail</div>`:'<div class="v">Not used</div><div class="basis">No category is set to Tech</div>',!hasKind('tech'))}
    ${tile('May expire',!perish.length?'<div class="v">Not used</div><div class="basis">Set a category to Perishable under Alert settings</div>':S.expPreview?`<div class="v num">${ex.length} ${ex.length===1?'entry':'entries'}</div><div class="basis">${fmt(val(ex.map(o=>o.r),r=>expRisk(r._i).atRisk))} units at risk <span class="status warn">Example dates</span></div>`:'<div class="v">Not enough data</div><div class="basis">Your stock file has no expiry or sell-by dates.</div>',!perish.length||!S.expPreview)}
   </div>
   ${perish.length&&!S.expPreview?`<div class="notice info"><div><p style="margin:0">${perish.join(' and ')} ${perish.length===1?'is':'are'} set to Perishable but your stock file has no expiry or sell-by dates. <button class="lnk" onclick="$('#pick3').click()">Add expiry dates</button></p><label class="check small" style="margin-top:8px"><input type="checkbox" onchange="S.expPreview=this.checked;processStockAlerts(true);render()"><span>Preview with example expiry dates<br><span class="muted">Prototype only. Shows the layout, not your stock.</span></span></label></div></div>`:''}
   ${S.expPreview&&perish.length?`<label class="check small" style="margin-bottom:16px"><input type="checkbox" checked onchange="S.expPreview=this.checked;processStockAlerts(true);render()">Preview with example expiry dates</label>`:''}
   ${items.length?`<div class="tablewrap"><table><thead><tr><th style="min-width:180px">Product · store</th><th>Stock</th><th>Signal</th><th>Cover</th><th style="min-width:260px">What to consider</th></tr></thead><tbody>
    ${catsWith.map(c=>{const rows=items.filter(o=>catOf(o.r)===c&&shownKeys.has(o.r._i+o.kind)).sort((a,b)=>b.val-a.val);if(!rows.length)return '';const k=A.cats[c];
      return `<tr class="group-head"><td colspan="5"><div class="gl"><b>${c}</b><span class="gs">${kindName(c)} · ${ruleText(k)} · checked ${FREQ[k.freq][0].toLowerCase()}</span></div></td></tr>`+rows.map(o=>`<tr><td><b>${esc(PROD[o.r.p].n)}</b> · ${STORES[o.r.s]}<div class="small muted">${PROD[o.r.p].sup}</div></td><td class="num"><b>${o.r.onHand}</b> units<div class="small muted">${nf(o.r.onHand*PINFO[o.r.p][1])} at retail</div></td><td>${o.kind==='exp'?`<span class="chip bad">${o.x.expired?'Expired':'Expires in '+o.x.d+'d'}</span><div class="small muted" style="margin-top:4px">${o.x.atRisk} at risk</div>`:o.kind==='old'?`<span class="chip warn">On sale ${monthsNow(o.r)} months</span>`:`<span class="chip warn">${slowText(o.r)}</span>`}</td><td class="num">${o.r.cover} wks</td><td class="small">${stockAdvice(o.r,o.kind,o.x)}</td></tr>`).join('')}).join('')}</tbody></table></div>
    <div class="summary" style="margin-top:12px"><span>Showing <b class="num">${Math.min(S.stk.shown,items.length)}</b> of <b class="num">${items.length}</b>, grouped by category</span><span class="tools">${items.length>S.stk.shown?`<button class="btn sm" onclick="S.stk.shown+=6;render()">Show ${Math.min(6,items.length-S.stk.shown)} more</button>`:''}<button class="btn sm" onclick="S.rv.group='category';jump('${slow.length?'slow':old.length?'old':'expiry'}','category')">Show in order list</button></span></div>`:`<div class="empty">Nothing has gone quiet, is ageing or is close to expiring with your current limits.</div>`}
   <p class="proto">Prototype: advance the clock under Approvals to age this stock and run the scheduled checks.</p></section>`;
}

/* ---------- Grouped alerts and row flags ---------- */
function rowFlags(r){
  const out=[];const x=expRisk(r._i);const iss=issues(r);const done=!!(r.reviewed&&iss.length);
  const ordSlow=r.qty>0&&isSlow(r),ordOld=r.qty>0&&isOld(r);
  if(x)out.push({sev:'act',t:x.expired?'Expired · '+x.atRisk+' at risk':'Expires in '+x.d+'d · '+x.atRisk+' at risk'});
  if(rowSupShort(r))out.push({sev:'act',t:'Supplier min not met'});
  if(!done&&ordSlow)out.push({sev:'act',t:'Ordering stock that isn’t moving'});
  if(!done&&ordOld)out.push({sev:'act',t:'Ordering a model that may be going out of date'});
  if(r.cover<1&&r.inc===0)out.push({sev:'act',t:'Stock-out risk'});
  if(!done)iss.filter(t=>!/isn.t moving|going out of date|expire/.test(t)).forEach(t=>out.push({sev:'review',t}));
  if(isSlow(r)&&(!ordSlow||done))out.push({sev:'watch',t:slowText(r)});
  if(isOld(r)&&(!ordOld||done))out.push({sev:'watch',t:'On sale '+monthsNow(r)+' mo'});
  if(isWatch(r))out.push({sev:'watch',t:'Reorder in ~'+watchDays(r)+'d'});
  return out}
function sevOf(r){const f=rowFlags(r);return f.some(x=>x.sev==='act')?'act':f.some(x=>x.sev==='review')?'review':f.length?'watch':null}
const sevCount=s=>S.rows.filter(r=>sevOf(r)===s).length;
function setFilter(f){S.rv.filter=f;S.rv.sup='';render()}
function toggleFlags(i){S.openFlags[i]=!S.openFlags[i];render()}
function toggleAg(g,cur){S.ag[g]=!cur;render()}
function toggleFold(k){S.fold[k]=!S.fold[k];render()}
const AGROUPS=[['act','Act before ordering'],['review','Review before approving'],['watch','Keep an eye on'],['ahead','Looking ahead']];
const groupOfAlert=t=>/minimum|suppliers below|Stock-out|expire before/.test(t)?'act':/Uptick|seasonal|New store/.test(t)?'review':'watch';
function attentionCard(mdl){
  const al=alertsList().map(x=>({...x,g:groupOfAlert(x.t)}));
  const fut=futureItems().map(x=>({k:x.k,t:x.t,d:x.d,act:`S.tab='${x.tab}';render()`,btn:x.btn,g:'ahead'}));
  const all=[...al,...fut];const by=g=>all.filter(x=>x.g===g);
  const first=(AGROUPS.find(([g])=>by(g).length)||[])[0];
  const isOpen=g=>S.ag[g]===undefined?g===first:S.ag[g];
  const chips=['act','review','watch'].filter(g=>by(g).length).map(g=>`<span class="sevchip ${g}"><i></i>${by(g).length} ${g==='act'?'to act on':g==='review'?'to review':'to watch'}</span>`).join('');
  return `<section class="card"><div class="card-head" style="margin-bottom:12px"><div><h2>What needs attention</h2><p>Forecast method: ${mdl}. Grouped by what to do first.</p></div><div class="sevchips">${chips}</div></div>
   ${AGROUPS.map(([g,label])=>{const items=by(g);if(!items.length)return '';const open=isOpen(g);const more=!!S.agMore[g];const vis=open?(more?items:items.slice(0,3)):[];
     return `<div class="agrp ${g}"><button class="ghead" aria-expanded="${open}" onclick="toggleAg('${g}',${open})"><i class="gdot" aria-hidden="true"></i><b>${label}</b><span class="gcount num">${items.length}</span><span class="gsum small muted">${items.slice(0,2).map(x=>esc(x.t)).join(' · ')}${items.length>2?' · +'+(items.length-2)+' more':''}</span><span class="chev" aria-hidden="true">${open?'▾':'▸'}</span></button>
      ${open?`<div class="gbody">${vis.map(x=>`<div class="alert"><span class="ic ${x.k}" aria-hidden="true">${x.k==='info'?'i':'!'}</span><div><h4>${x.t}</h4><p>${x.d}</p></div><button class="btn sm" onclick="${x.act}">${x.btn||'Show in list'}</button></div>`).join('')}${items.length>3?`<button class="lnk" style="margin:8px 0 4px" onclick="S.agMore['${g}']=${!more};render()">${more?'Show fewer':'Show '+(items.length-3)+' more'}</button>`:''}</div>`:''}</div>`}).join('')}</section>`;
}
/* ---------- Screen 1 ---------- */
function s1(){
  const totalRows=S.files.reduce((a,f)=>a+f.rows,0);
  return `
  <div class="page-head"><h1>What would you like to understand?</h1>
  <p>Start with a business question and upload the information you already have. No technical setup needed.</p></div>
  <section class="card" aria-labelledby="q-l">
    <label class="field-label" id="q-l" for="q">Your question</label>
    <textarea id="q" class="q" maxlength="200" oninput="S.question=this.value;$('#qc').textContent=this.value.length+' / 200';refreshS1Btn()">${esc(S.question)}</textarea>
    <div class="counter"><span>Describe the decision you need to make, not the type of model you want.</span><span id="qc" class="num">${S.question.length} / 200</span></div>
  </section>
  ${pbCard()}
  <section class="card" aria-labelledby="d-l">
    <div class="card-head"><div><h2 id="d-l">Business data</h2><p>CSV or Excel. Label what each file contains so we can check it.</p></div>
    <button class="btn" onclick="$('#pick').click()">+ Add files</button></div>
    <div class="dropzone" id="dz" ondragover="event.preventDefault();this.classList.add('over')" ondragleave="this.classList.remove('over')" ondrop="dropFiles(event)">
      <strong>Drag files here</strong><span class="muted">or <a href="#" onclick="$('#pick').click();return false">browse your computer</a></span>
    </div>
    <input id="pick" type="file" class="sr" multiple accept=".csv,.xlsx,.xls" onchange="addFiles(this.files)">
    <div class="filelist">
    ${S.files.length?S.files.map(f=>`
      <div class="file">
        <div><div class="name">${esc(f.name)}</div><div class="dims"><b class="num">${fmt(f.rows)}</b> rows · <b>${f.cols}</b> columns</div></div>
        <select aria-label="What ${esc(f.name)} contains" onchange="setRole(${f.id},this.value)">${ROLES.map(r=>`<option ${r===f.role?'selected':''}>${r}</option>`).join('')}</select>
        <div class="dims">${esc(f.range)}</div>
        <button class="iconbtn" aria-label="Remove ${esc(f.name)}" onclick="rmFile(${f.id})">✕</button>
      </div>`).join(''):`<div class="empty">No files yet. Add at least sales history and stock on hand.</div>`}
    </div>
    <div class="totals"><span><b class="num">${S.files.length}</b> ${S.files.length===1?'file':'files'}</span><span><b class="num">${fmt(totalRows)}</b> rows in total</span></div>
  </section>
  <div class="actions"><p class="hint">Files are only used to check whether your question can be answered.</p>
  <div class="right"><button class="btn primary" id="s1btn" onclick="go(2)" ${blocked()?'disabled':''}>Review my task →</button></div></div>
  <p class="proto">Prototype: dimensions for the four sample files are placeholders. Files you add are read in your browser and their rows and columns counted (CSV only).</p>`;
}
function refreshS1Btn(){const b=$('#s1btn');if(b)b.disabled=blocked()}
function setRole(id,r){S.files.find(f=>f.id===id).role=r;render()}
function rmFile(id){const f=S.files.find(x=>x.id===id);S.files=S.files.filter(x=>x.id!==id);S.modelState='idle';render();toast('Removed '+f.name)}
function dropFiles(e){e.preventDefault();addFiles(e.dataTransfer.files)}
function addFiles(list,late){
  [...list].forEach(file=>{
    const f={id:++uid,name:file.name,role:guessRole(file.name),rows:0,cols:0,range:'Reading…'};
    S.files.push(f);
    if(/\.csv$/i.test(file.name)){const rd=new FileReader();rd.onload=()=>{const lines=rd.result.split(/\r?\n/).filter(Boolean);f.rows=Math.max(0,lines.length-1);f.cols=(lines[0]||'').split(',').length;f.range='Dates not detected';render()};rd.readAsText(file)}
    else{f.range=(file.size/1024).toFixed(0)+' KB · Excel'}
  });
  if(late)S.stale=true;else S.modelState='idle';render()
}
function guessRole(n){n=n.toLowerCase();if(/sale/.test(n))return'Sales history';if(/inv|stock/.test(n))return'Stock on hand';if(/inbound|deliver|ship/.test(n))return'Incoming shipments';if(/polic|supplier|rule/.test(n))return'Supplier rules';return'Other'}

/* ---------- Screen 2 ---------- */
function s2(){
  const r=readiness();const bad=r.some(x=>x.state==='bad');
  return `
  <div class="page-head"><h1>Here’s what we’ll help you decide</h1>
  <p>Check the task and your data. Nothing runs until you approve.</p></div>
  <section class="card">
    <div class="card-head"><div><span class="field-label" style="margin:0">Your question</span><h2 style="font-size:22px">${esc(S.question)}</h2></div><button class="btn ghost" onclick="go(1)">Edit question</button></div>
    <p class="muted">We’ll turn this into: <b style="color:var(--ink)">which products and quantities each store should reorder next week.</b></p>
    ${pbSummary()}
    <ol class="steps" style="padding:0">
      <li><b>1. Check demand</b>Recent sales by product and store</li>
      <li><b>2. Check stock</b>Stock on hand and incoming shipments</li>
      <li><b>3. Apply rules</b>Pack sizes and supplier minimums</li>
      <li><b>4. Draft orders</b>A list your team can review and edit</li>
    </ol>
  </section>
  <section class="card">
    <div class="card-head"><div><h2>Data readiness</h2><p>${bad?'One or more required files are missing.':'You can continue. Warnings may affect the recommendation.'}</p></div><button class="btn sm" onclick="go(1)">Add or remove files</button></div>
    <div class="tablewrap"><table>
      <thead><tr><th>Information</th><th>File</th><th>Status</th><th>What we found</th></tr></thead>
      <tbody>${r.map(x=>`<tr><td><b>${x.role}</b><div class="small muted">${x.why}</div></td><td>${esc(x.file)}</td>
      <td><span class="status ${x.state}">${x.state==='ok'?'✓ Ready':x.state==='warn'?'! Check':'✕ Missing'}</span></td><td class="small">${x.detail}</td></tr>`).join('')}</tbody>
    </table></div>
  </section>
  <div class="notice warn"><div><h3>Extra context could improve the recommendation</h3>
    <p>Promotions, seasonal events and planned store closures aren’t in your files. Forecasts may miss unusual demand.</p>
    <button class="btn sm" onclick="$('#pick2').click()">+ Add a promotions or events file</button><input id="pick2" type="file" class="sr" accept=".csv,.xlsx,.xls" onchange="addFiles(this.files);toast('File added')"></div></div>
  <div class="actions"><button class="btn ghost" onclick="go(1)">← Back</button>
  <div class="right"><span class="hint">Analysis will not run until you approve this task.</span>
  <button class="btn primary" onclick="startModels()" ${bad?'disabled':''}>Approve and analyze →</button></div></div>`;
}

/* ---------- Screen 3 ---------- */
let timer=null;
function startModels(){S.stale=false;S.modelState='running';S.modelDone=0;S.step=3;S.runBy=S.user;S.runPending=false;render();window.scrollTo({top:0});
  clearInterval(timer);timer=setInterval(()=>{S.modelDone++;
    if(S.modelDone>=MODELS.length){clearInterval(timer);S.modelState='done';
      if(S.step!==3){const who=PEOPLE.find(p=>p.id===S.runBy)||me();if(S.runNotify.push)notify([who],'Your forecast models are ready to compare.','models');S.runPending=true;
        S.log.unshift(nowStr()+' · Forecast models finished'+(S.runNotify.email?'. Email sent to '+who.name:'')+(S.runNotify.push?'. Alert sent':''));toast('Forecast models are ready')}}
    if(S.step===3)render();else{updateRunBar();updateBell()}},1100)}
function setRunNotify(k,v){S.runNotify[k]=v;render()}
function updateRunBar(){
  const el=$('#runbar');if(!el)return;
  if(S.modelState==='running'&&S.step!==3)el.innerHTML=`<div class="notice info" role="status"><span class="spin" aria-hidden="true"></span><div><b>Testing forecasting models</b> · ${S.modelDone} of ${MODELS.length} done. We’ll alert you when results are ready. <button class="lnk" onclick="go(3)">View progress</button></div></div>`;
  else if(S.runPending&&S.modelState==='done'&&S.step!==3)el.innerHTML=`<div class="notice ok" role="status"><div><b>Forecast models are ready.</b> <button class="lnk" onclick="go(3)">View results</button></div></div>`;
  else el.innerHTML=''}
const dots=n=>[1,2,3].map(i=>`<span class="dot ${i<=n?'on':''}"></span>`).join('');
function s3(){
  if(S.modelState==='idle')return `<div class="page-head"><h1>Compare forecasting models</h1><p>Approve the task first so we can test the models.</p></div><div class="actions"><button class="btn primary" onclick="go(2)">Go to task confirmation</button></div>`;
  const run=S.modelState==='running';const pct=Math.round(S.modelDone/MODELS.length*100);
  const m=MODELS.find(x=>x.id===S.model);const cur=MODELS.find(x=>x.id==='cur');
  const col=(done,v)=>done?v:'—';
  let out=`
  <div class="page-head"><h1>${run?'Testing forecasting models':'Compare forecasting models'}</h1>
  <p>${run?'We’re replaying past weeks to see which method would have predicted demand best. This usually takes a few minutes.':'Choose how to estimate next week’s demand before generating the business report.'}</p></div>`;
  if(run) out+=`<section class="card" aria-live="polite"><div class="card-head"><h2>Testing ${Math.min(S.modelDone+1,MODELS.length)} of ${MODELS.length}</h2><span class="status teal">${pct}%</span></div>
    <div class="progress-wrap" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><div class="progress-fill" style="width:${pct}%"></div></div>
    <p class="muted small">We hold back recent weeks, predict them, then compare with what really sold.</p>
    <div class="notice info" style="margin:16px 0 0"><div><h3>You can leave this page</h3><p>This can take a few minutes. Your progress is saved. We’ll alert you here when the results are ready, and you can pick up where you left off.</p>
     <div style="display:flex;gap:var(--s3);flex-wrap:wrap;margin-top:8px"><label class="check small"><input type="checkbox" ${S.runNotify.push?'checked':''} onchange="setRunNotify('push',this.checked)">Alert me in the app</label><label class="check small"><input type="checkbox" ${S.runNotify.email?'checked':''} onchange="setRunNotify('email',this.checked)">Email me too</label></div></div></div></section>`;
  else out+=`<section class="rec"><span class="status teal">Recommended</span><h2>Random forest</h2>
    <p>Best accuracy, and it catches the most shortages (${MODELS[3].recall} of 100) without ordering more than needed. It is also the only method that used stock and delivery information together with sales.</p></section>`;
  out+=`<section class="card">
    <div class="card-head"><div><h2>Models tested</h2><p>Select a method to see what it looked at. Lower is better for “typical error” and “unneeded orders”; higher is better for the rest.</p></div></div>
    <div role="radiogroup" aria-label="Forecasting model" class="tablewrap">
    <div class="mrow head"><span>Method</span><span>Forecast accuracy</span><span>Typical error</span><span>Shortages caught</span><span>Unneeded orders</span></div>
    ${MODELS.map((x,i)=>{
      const done=i<S.modelDone||!run;const active=run&&i===S.modelDone;const best=x.id==='rf';
      return `<div class="mrow ${!run&&S.model===x.id?'sel':''}">
        <div class="mname"><input type="radio" name="mdl" id="m-${x.id}" ${S.model===x.id?'checked':''} ${run?'disabled':''} onchange="S.model='${x.id}';render()">
        <label for="m-${x.id}"><b>${x.name}</b>${best&&done?' <span class="status teal">Recommended</span>':''}<span class="sub">${subTag(x)}</span></label></div>
        <div class="barbox">${done?`<div class="bar"><i class="${best?'best':''}" style="width:${x.acc}%"></i></div><b class="num">${x.acc}%</b>`:active?`<span class="spin" aria-hidden="true"></span><span class="muted small">Testing…</span>`:`<span class="muted small">Waiting</span>`}</div>
        <div class="num">${col(done,'± '+x.err+' units')}</div><div class="num">${col(done,x.recall+'%')}</div><div class="num">${col(done,x.unneeded+'%')}</div></div>`}).join('')}
    </div>
  </section>`;
  if(!run){
    out+=`
  <section class="card"><div class="card-head"><div><h2>What these numbers mean for your stores</h2><p>Measured on recent weeks the models didn’t see while learning. Example figures use ${m.name}.</p></div></div>
    <div class="metrics">
      <div class="metric"><div class="big num">${m.acc}%</div><h4>Forecast accuracy</h4><p>How close the weekly forecast was to what really sold. Defined as 100% minus the average percentage miss, across all product-store pairs.</p><div class="eg">${m.acc}% accuracy means forecasts were off by about ${100-m.acc}% of units sold. ${cur.acc<m.acc?'Your current method: '+cur.acc+'%.':''}</div></div>
      <div class="metric"><div class="big num">± ${m.err}</div><h4>Typical error, in units</h4><p>How many units the forecast is usually wrong by, for one product in one store in one week.</p><div class="eg">For a product that sells about 25 a week in a store, expect the forecast to be roughly ${Math.round(m.err)} units high or low.</div></div>
      <div class="metric"><div class="big num">${m.recall}%</div><h4>Shortages caught</h4><p>Of the weeks where a store would really have run out, how many the model flagged early enough to reorder. The rest are lost sales.</p><div class="eg">Of 100 product-store weeks that would have run out, ${m.recall} were flagged in time. ${100-m.recall} would have sold out.</div></div>
      <div class="metric"><div class="big num">${m.unneeded}%</div><h4>Unneeded orders</h4><p>Of the reorder suggestions, how many weren’t needed: cash tied up in stock that sat on the shelf.</p><div class="eg">Of 100 reorder suggestions, ${m.unneeded} weren’t needed. ${cur.unneeded>m.unneeded?'Your current method: '+cur.unneeded+'.':''}</div></div>
    </div>
    <p class="muted small" style="margin-top:16px;max-width:70ch">Shortages caught and unneeded orders pull against each other: ordering more catches more shortages but ties up more cash. A better model improves both. Illustrative scores; replace with held-out test results.</p>
  </section>
  <div class="cols2">
  <section class="card"><div class="card-head"><div><h2>What ${m.name} looked at</h2><p>Share of influence on the forecast. Illustrative.</p></div></div>
    ${m.feats.map(f=>`<div class="feat"><div>${f[0]}<span class="src">From ${f[2].toLowerCase()}</span></div><div class="bar"><i class="${m.id==='rf'?'best':''}" style="width:${f[1]*(m.feats.length>3?2.4:1)}%;max-width:100%"></i></div><b class="num small">${f[1]}%</b></div>`).join('')}
    <p class="small muted" style="margin-top:12px">Not used (not in your files): promotions, events, weather, planned closures.</p>
    <p style="margin-top:12px"><b>Best at:</b> ${m.best}</p><p style="margin-top:6px"><b>Watch out for:</b> ${m.watch}</p>
    <p class="muted" style="margin-top:12px;font-size:14px">${m.plain}${m.id==='cur'&&S.pb.saved&&S.pb.saved.text?`<br><br>You told us: “${esc(S.pb.saved.text)}”${pbUsesAvg()?'':' We can’t replay this exactly, so its scores are an estimate from recent sales.'}`:''}</p></section>
  <section class="card"><div class="card-head"><div><h2>How the methods differ</h2><p>Dots show how well each handles it.</p></div></div>
    <div class="tablewrap"><table class="matrix"><thead><tr><th>Method</th><th>Reacts to trends</th><th>Store by store</th><th>Easy to explain</th></tr></thead><tbody>
    ${MODELS.map(x=>`<tr><td><b>${x.name}</b><div class="small muted">Looks at: ${x.m.looks.toLowerCase()}</div></td><td>${dots(x.m.trend)}</td><td>${dots(x.m.stores)}</td><td>${dots(x.m.explain)}</td></tr>`).join('')}</tbody></table></div>
    <p class="small muted" style="margin-top:12px">Simple methods are easier to explain; the recommended method trades some of that for catching more shortages.</p></section>
  </div>`;
  }
  out+=`<div class="actions"><button class="btn ghost" onclick="go(2)">← Back to task</button>
  <div class="right"><button class="btn primary" onclick="go(4)" ${run?'disabled':''}>Generate business report →</button></div></div>`;
  return out;
}

/* ---------- Screen 4 ---------- */
function alertsList(){
  const a=[];
  const up=S.rows.filter(r=>r.up>=25&&r.qty>0);
  if(up.length)a.push({k:'warn',t:'Uptick in demand',d:`${up.length} product-store entries sold 25% or more above their usual pace over the last 2 weeks and need stock.`,act:"jump('uptick','attention')"});
  const se=S.rows.filter(r=>r.seasonal&&r.qty>0);
  const sp=[...new Set(se.map(r=>PROD[r.p].n))];
  if(se.length)a.push({k:'info',t:'Possible seasonal demand',d:`${sp.slice(0,3).join(', ')}${sp.length>3?' and '+(sp.length-3)+' more':''} are rising together, which looks like a holiday run-up. We only have 10 months of history, so we can’t confirm it against last year.`,act:"jump('seasonal','product')"});
  const sh=supShort();
  if(sh.length)a.push({k:'warn',t:sh.length===1?sh[0].name+' minimum not met':sh.length+' suppliers below minimum',d:sh.slice(0,3).map(s=>`${s.name}: ${supNow(s)} of ${supRule(s)}`).join(' · ')+(sh.length>3?' · and '+(sh.length-3)+' more':'')+'. Add units, combine with other stores’ needs, or confirm a smaller order is accepted.',act:"openSup(true)",btn:'View suppliers'});
  const w=S.rows.filter(isWatch).sort((x,y)=>watchDays(x)-watchDays(y));
  if(w.length)a.push({k:'info',t:'Approaching low stock, not ready to order',d:`${w.length} entries don’t need an order yet, but at their current pace they’ll reach their reorder point within a week. Soonest: ${PROD[w[0].p].n} at ${STORES[w[0].s]} in about ${watchDays(w[0])} ${watchDays(w[0])===1?'day':'days'}. Check them before next week’s order.`,act:"jump('watch','store','cover')",btn:'Show watch list'});
  const sl=S.rows.filter(isSlow);
  if(sl.length)a.push({k:'warn',t:'Stock that isn’t moving',d:`${sl.length} ${sl.length===1?'entry is':'entries are'} past ${sl.length===1?'its':'their'} category limit: ${fmt(sl.reduce((x,r)=>x+r.onHand,0))} units, ${nf(sl.reduce((x,r)=>x+r.onHand*PINFO[r.p][1],0))} at retail.`,act:"jump('slow','category')",btn:'Show them'});
  const od=S.rows.filter(isOld).sort((x,y)=>monthsNow(y)-monthsNow(x));
  if(od.length)a.push({k:'warn',t:'Stock that may be going out of date',d:`${od.length} ${od.length===1?'entry is':'entries are'} for products on sale past the limit for ${[...new Set(od.map(catOf))].join(' and ')}. Longest: ${PROD[od[0].p].n}, ${monthsNow(od[0])} months.`,act:"jump('old','category')",btn:'Show them'});
  const ex=S.rows.filter(r=>expRisk(r._i)).sort((x,y)=>expDays(x._i)-expDays(y._i));
  if(ex.length)a.push({k:'bad',t:'Stock may expire before it sells',d:`${ex.length} ${ex.length===1?'entry expires':'entries expire'} within the limit for ${[...new Set(ex.map(catOf))].join(' and ')} at the current sales pace. Soonest: ${PROD[ex[0].p].n} in ${Math.max(0,expDays(ex[0]._i))} days.`,act:"jump('expiry','category')",btn:'Show them'});
  const low=S.rows.filter(r=>r.cover<1&&r.inc===0);
  if(low.length)a.push({k:'bad',t:'Stock-out risk',d:`${low.length} entries have under a week of cover and nothing arriving. Consider expediting.`,act:"jump('all','attention','cover')"});
  const lh=S.rows.filter(r=>r.lowHist);
  if(lh.length)a.push({k:'info',t:'New store, short history',d:`CHI-01 has only about 9 weeks of sales. ${lh.length} of its suggestions rely on limited data.`,act:"jump('review','store')"});
  return a;
}
function jump(f,g,sort){S.rv.filter=f;S.rv.sup='';if(g)S.rv.group=g;if(sort)S.rv.sort=sort;S.rv.hideZero=true;go(5)}
/* ---------- Sales history (sample daily data) ---------- */
const MONS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MONL=['January','February','March','April','May','June','July','August','September','October','November','December'];
const DOWN=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const fd=d=>d.getUTCDate()+' '+MONS[d.getUTCMonth()];
const MINC={daily:28,weekly:8,monthly:6,quarterly:4,yearly:2};
const UNIT={daily:'days',weekly:'weeks',monthly:'months',quarterly:'quarters',yearly:'years'};
const UNIT1={daily:'day',weekly:'week',monthly:'month',quarterly:'quarter',yearly:'year'};
const GRANS=[['daily','Daily'],['weekly','Weekly'],['monthly','Monthly'],['quarterly','Quarterly'],['yearly','Yearly']];
const MAW={daily:7,weekly:4,monthly:3,quarterly:2,yearly:2};
const CMPK={daily:14,weekly:6,monthly:3,quarterly:1,yearly:1};
function keyOf(g,x){const d=x.d;if(g==='daily')return ''+x.i;if(g==='weekly')return ''+Math.floor(x.i/7);if(g==='monthly')return d.getUTCFullYear()+'-'+d.getUTCMonth();if(g==='quarterly')return d.getUTCFullYear()+'-Q'+(Math.floor(d.getUTCMonth()/3)+1);return ''+d.getUTCFullYear()}
function fullLen(g,x){const d=x.d,y=d.getUTCFullYear(),m=d.getUTCMonth();if(g==='daily')return 1;if(g==='weekly')return 7;if(g==='monthly')return new Date(Date.UTC(y,m+1,0)).getUTCDate();if(g==='quarterly'){const q=Math.floor(m/3);return (Date.UTC(y,q*3+3,1)-Date.UTC(y,q*3,1))/DAY}return (Date.UTC(y+1,0,1)-Date.UTC(y,0,1))/DAY}
function labelsOf(g,x){const d=x.d;
  if(g==='daily')return[fd(d),DOWN[d.getUTCDay()]+' '+fd(d)+' '+d.getUTCFullYear()];
  if(g==='weekly')return[fd(d),'Week of '+fd(d)];
  if(g==='monthly')return[MONS[d.getUTCMonth()],MONL[d.getUTCMonth()]+' '+d.getUTCFullYear()];
  if(g==='quarterly'){const q=Math.floor(d.getUTCMonth()/3)+1;return['Q'+q,'Q'+q+' '+d.getUTCFullYear()]}
  return[''+d.getUTCFullYear(),''+d.getUTCFullYear()]}
function series(g,stores,measure){
  const map=new Map();
  DAYS.forEach(x=>{let v=0,open=false;
    stores.forEach(s=>{if(x.u[s]!==null){open=true;v+=measure==='sales'?x.u[s]*PRICE[s]:x.u[s]}});
    if(!open)return;
    const k=keyOf(g,x);let b=map.get(k);
    if(!b){const L=labelsOf(g,x);b={k,label:L[0],long:L[1],days:0,total:0,full:fullLen(g,x)};map.set(k,b)}
    b.days++;b.total+=v});
  return [...map.values()].map(b=>({...b,partial:b.days<b.full}))
}
const chStores=()=>S.ch.store==='all'?[0,1,2,3]:[STORES.indexOf(S.ch.store)];
function avail(g){const n=series(g,chStores(),'units').filter(b=>!b.partial).length;const who=S.ch.store==='all'?'You have':S.ch.store+' has';return{ok:n>=MINC[g],n,reason:`Needs at least ${MINC[g]} full ${UNIT[g]} of history. ${who} ${n}.`}}
function fmtV(v,m){v=Math.round(v);return m==='sales'?'$'+fmt(v):fmt(v)}
function fmtAx(v,m){return m==='sales'?(v>=10000?'$'+(v/1000).toFixed(v>=100000?0:1)+'k':'$'+fmt(Math.round(v))):fmt(Math.round(v))}
let CH=null,curIdx=null;
function chartModel(){
  const g=S.ch.gran,m=S.ch.measure;const data=series(g,chStores(),m);
  const ma=data.map((b,i)=>{const w=MAW[g];if(i<w-1)return null;let s=0;for(let j=i-w+1;j<=i;j++){if(data[j].partial)return null;s+=data[j].total}return s/w});
  const comp=data.filter(b=>!b.partial);const K=CMPK[g];let cmp=null;
  if(comp.length>=2*K){const last=comp.slice(-K),prev=comp.slice(-2*K,-K);const a=last.reduce((s,b)=>s+b.total,0),p=prev.reduce((s,b)=>s+b.total,0);cmp={pct:Math.round((a/p-1)*100),K,from:data.indexOf(last[0]),to:data.indexOf(last[K-1])}}
  return{g,m,data,ma,cmp}
}
function chartHTML(){
  const mdl=chartModel();const{g,m,data,ma,cmp}=mdl;const n=data.length;
  const W=760,H=270,PL=58,PR=14,PT=18,PB=32;
  const vals=data.map(b=>b.total);const hi=Math.max(...vals)*1.08,lo=Math.max(0,Math.floor(Math.min(...vals)*.8));
  const x=i=>PL+(n===1?(W-PL-PR)/2:i*(W-PL-PR)/(n-1)),y=v=>PT+(1-(v-lo)/(hi-lo))*(H-PT-PB);
  const xs=data.map((_,i)=>x(i)),ys=vals.map(y);
  CH={W,H,PL,PR,n,xs,ys,data,g,m};curIdx=null;
  const yt=[0,1,2,3].map(i=>lo+(hi-lo)*i/3);
  const nx=Math.min(6,n);const xi=n===1?[0]:Array.from({length:nx},(_,i)=>Math.round(i*(n-1)/(nx-1)));
  const path=arr=>{let d='',pen=false;arr.forEach((v,i)=>{if(v===null){pen=false;return}d+=(pen?'L':'M')+xs[i].toFixed(1)+' '+y(v).toFixed(1)+' ';pen=true});return d};
  const showMA=S.ch.avg&&n>MAW[g]&&ma.some(v=>v!==null);
  const band=cmp?`<rect class="band" x="${xs[cmp.from]-(n>1?(xs[1]-xs[0])/2:0)}" y="${PT}" width="${(xs[cmp.to]-xs[cmp.from])+(n>1?(xs[1]-xs[0]):20)}" height="${H-PT-PB}"/><text x="${xs[cmp.from]-(n>1?(xs[1]-xs[0])/2:0)+6}" y="${PT+12}">Last ${cmp.K} ${cmp.K===1?UNIT1[g]:UNIT[g]}</text>`:'';
  const last=data[n-1];
  return `<div class="chartbox" id="chartbox" tabindex="0" role="group" aria-label="${GRANS.find(a=>a[0]===g)[1]} ${m==='sales'?'sales':'units sold'} chart, ${n} points. Use the left and right arrow keys to read each value." onkeydown="chartKey(event)" onblur="chartLeave()">
  <svg class="chart" id="chartsvg" viewBox="0 0 ${W} ${H}" aria-hidden="true">
   ${yt.map(v=>`<line class="grid" x1="${PL}" x2="${W-PR}" y1="${y(v)}" y2="${y(v)}"/><text x="${PL-8}" y="${y(v)+4}" text-anchor="end">${fmtAx(v,m)}</text>`).join('')}
   ${band}
   <path class="ln ${showMA?'faint':''}" d="${path(vals)}"/>
   ${showMA?`<path class="ln ma" d="${path(ma)}"/>`:''}
   ${n<=60?data.map((b,i)=>`<circle class="pt ${b.partial?'part':''}" cx="${xs[i]}" cy="${ys[i]}" r="3.5"/>`).join(''):(last.partial?`<circle class="pt part" cx="${xs[n-1]}" cy="${ys[n-1]}" r="4"/>`:'')}
   ${xi.map(i=>`<text x="${xs[i]}" y="${H-8}" text-anchor="${i===0?'start':i===n-1?'end':'middle'}">${data[i].label}</text>`).join('')}
   <g id="cur" style="display:none"><line id="cl" y1="${PT}" y2="${H-PB}"/><circle id="cd" r="5.5"/></g>
   <rect class="hit" x="${PL}" y="${PT}" width="${W-PL-PR}" height="${H-PT-PB}" fill="transparent" onmousemove="chartMove(event)" onmouseleave="chartLeave()" ontouchstart="chartMove(event.touches[0])" ontouchmove="chartMove(event.touches[0])"/>
  </svg>
  <div class="ctip" id="ctip" hidden></div><div class="sr" id="clive" aria-live="polite"></div></div>
  <div class="legend small muted"><span><i class="sw faint"></i>${GRANS.find(a=>a[0]===g)[1]} ${m==='sales'?'sales':'units'}</span>${showMA?`<span><i class="sw ma"></i>${MAW[g]}-${UNIT1[g]} average</span>`:''}${data.some(b=>b.partial)?'<span><i class="sw hollow"></i>Partial period</span>':''}${cmp?'<span><i class="sw bandsw"></i>Compared period</span>':''}</div>`;
}
function chartSet(i){
  const c=CH;if(!c)return;i=Math.max(0,Math.min(c.n-1,i));curIdx=i;
  const b=c.data[i],prev=c.data[i-1];
  const cur=$('#cur');if(!cur)return;cur.style.display='';
  $('#cl').setAttribute('x1',c.xs[i]);$('#cl').setAttribute('x2',c.xs[i]);$('#cd').setAttribute('cx',c.xs[i]);$('#cd').setAttribute('cy',c.ys[i]);
  let delta='';if(prev&&!b.partial&&!prev.partial){const p=Math.round((b.total/prev.total-1)*100)||0;delta=`<div class="${p>=0?'up':'dn'}">${p>0?'+':''}${p}% vs previous ${UNIT1[c.g]}</div>`}
  const val=fmtV(b.total,c.m)+(c.m==='units'?' units':'');
  const tip=$('#ctip');tip.hidden=false;
  tip.innerHTML=`<b>${b.long}</b><div class="v">${val}</div>${c.g!=='daily'?`<div class="muted small">${fmtV(b.total/b.days,c.m)}${c.m==='units'?' units':''} per day</div>`:''}${b.partial?`<div class="note">Partial: ${b.days} of ${b.full} days</div>`:''}${delta}`;
  const pct=c.xs[i]/c.W*100;tip.style.left=pct+'%';tip.classList.toggle('flip',pct>68);
  $('#clive').textContent=b.long+': '+val+(b.partial?' (partial period)':'')
}
function chartMove(e){const svg=$('#chartsvg');if(!svg||!CH)return;const r=svg.getBoundingClientRect();const x=(e.clientX-r.left)/r.width*CH.W;chartSet(Math.round((x-CH.PL)/(CH.W-CH.PL-CH.PR)*(CH.n-1)))}
function chartLeave(){const cur=$('#cur');if(cur)cur.style.display='none';const t=$('#ctip');if(t)t.hidden=true;curIdx=null}
function chartKey(e){if(!CH)return;const k=e.key;if(!['ArrowLeft','ArrowRight','Home','End','Escape'].includes(k))return;e.preventDefault();
  if(k==='Escape'){chartLeave();return}
  let i=curIdx===null?CH.n-1:curIdx;if(k==='ArrowLeft')i--;if(k==='ArrowRight')i++;if(k==='Home')i=0;if(k==='End')i=CH.n-1;chartSet(i)}
function setGran(g){if(!avail(g).ok)return;S.ch.gran=g;render()}
function setChStore(v){S.ch.store=v;if(!avail(S.ch.gran).ok){S.ch.gran=['weekly','daily','monthly'].find(x=>avail(x).ok)||'daily'}render()}
function chartSummary(){
  const{g,m,cmp}=chartModel();const what=m==='sales'?'Sales':'Units sold';
  const scope=S.ch.store==='all'?'across all stores':'at '+S.ch.store;
  if(!cmp)return `${what} ${scope}. Not enough complete periods to compare the latest period with the one before.`;
  const k=cmp.K;const per=k===1?UNIT1[g]:k+' '+UNIT[g];
  return `${what} ${scope} over the last ${per} are <b>${cmp.pct>=0?'up '+cmp.pct+'%':'down '+(-cmp.pct)+'%'}</b> on the ${k===1?'one':k}${k===1?'':''} before. Hover or use the arrow keys to read each point.`
}
function chartCard(){
  const gb=GRANS.map(([k,l])=>{const a=avail(k);return `<button aria-pressed="${S.ch.gran===k}" ${a.ok?'':'disabled'} title="${a.ok?'':esc(a.reason)}" onclick="setGran('${k}')">${l}</button>`}).join('');
  const off=GRANS.filter(([k])=>!avail(k).ok);
  return `<section class="card"><div class="card-head" style="flex-wrap:wrap"><div><h2>${S.ch.measure==='sales'?'Sales':'Units sold'} over time</h2><p>${chartSummary()}</p></div>
    <div class="chctl"><div class="seg" role="group" aria-label="Time period">${gb}</div>
    <div class="seg" role="group" aria-label="Measure"><button aria-pressed="${S.ch.measure==='units'}" onclick="S.ch.measure='units';render()">Units</button><button aria-pressed="${S.ch.measure==='sales'}" onclick="S.ch.measure='sales';render()">Sales</button></div>
    <div class="fld"><label for="chst" class="sr">Store</label><select id="chst" onchange="setChStore(this.value)"><option value="all" ${S.ch.store==='all'?'selected':''}>All stores</option>${STORES.map(s=>`<option ${S.ch.store===s?'selected':''}>${s}</option>`).join('')}</select></div>
    <label class="check small"><input type="checkbox" ${S.ch.avg?'checked':''} onchange="S.ch.avg=this.checked;render()">Moving average</label></div></div>
    ${chartHTML()}
    ${off.length?`<p class="small muted" style="margin-top:12px">${off.map(([k,l])=>`<b>${l}</b> is unavailable: ${avail(k).reason.replace(/^Needs/,'needs').replace(/\.\s/,'. ')}`).join(' ')}</p>`:''}
    <p class="small muted" style="margin-top:8px">We have ${NDAYS} days of history (3 Jan – 18 Oct 2026), so yearly seasonality can’t be confirmed.</p></section>`;
}

/* ---------- Predictable demand ---------- */
const DRVK={dow:['Day of week','Sales run about 30% higher Friday to Sunday.'],trend:['Recent trend','Sales have climbed over the last 6 weeks.'],holiday:['Holiday run-up','Rising alongside other gift items. Unconfirmed: only 10 months of history.'],store:['Store mix','Most units come from one or two stores.'],stockout:['Past stock-outs','Sold out in some past weeks, so real demand may be higher.'],restock:['Restock timing','Sales bunch up right after deliveries arrive.'],bulk:['Bulk orders','A few large purchases swing the weekly total.'],slow:['Slow seller','Only a few sales a week, so one sale moves the average.'],newstore:['New-store ramp-up','CHI-01 is still building a sales pattern.']};
const DRV=[[['dow',60],['store',30],['trend',20]],[['store',45],['dow',35],['slow',20]],[['holiday',55],['trend',40],['dow',30]],[['holiday',60],['dow',45],['trend',35],['stockout',20]],[['holiday',55],['dow',40],['trend',30]],[['restock',40],['dow',35],['store',25]],[['bulk',55],['slow',40],['store',25]],[['dow',50],['restock',30],['trend',20]],[['dow',45],['stockout',30],['restock',25]],[['bulk',50],['slow',45],['newstore',20]],[['dow',40],['store',30],['trend',20]],[['bulk',35],['restock',30],['store',25]],[['dow',45],['restock',35]],[['bulk',40],['dow',30],['newstore',25]]];
const CLS={steady:['Steady','ok','Order to the forecast. Little safety stock needed.'],variable:['Variable','warn','Add a moderate safety stock and recheck mid-week.'],lumpy:['Lumpy','bad','Keep a higher safety stock. Expect forecast misses and review orders by hand.']};
const clsOf=cv=>cv<.3?'steady':cv<.5?'variable':'lumpy';
const PSORT={cv:['Most variable first',(a,b)=>b.cv-a.cv],cvr:['Most predictable first',(a,b)=>a.cv-b.cv],name:['Product A–Z',(a,b)=>a.p.n.localeCompare(b.p.n)]};
function predRows(){
  const q=S.pred.q.trim().toLowerCase();
  return PROD.map((p,i)=>({i,p,cv:p.cv,cls:clsOf(p.cv),drv:DRV[i]})).filter(r=>(S.pred.f==='all'||r.cls===S.pred.f)&&(S.pred.drv==='all'||r.drv.some(d=>d[0]===S.pred.drv))&&(!q||(r.p.n+' '+r.p.sup+' '+r.drv.map(d=>DRVK[d[0]][0]).join(' ')).toLowerCase().includes(q))).sort(PSORT[S.pred.sort][1]);
}
function predCard(){
  const all=PROD.map(p=>clsOf(p.cv));const cnt=k=>all.filter(x=>x===k).length;
  const rows=predRows();const shown=rows.slice(0,S.pred.shown);
  const used=[...new Set(DRV.flat().map(d=>d[0]))];
  const body=shown.map(r=>{
    const c=CLS[r.cls];const open=S.pred.open===r.i;
    const top=r.drv.slice(0,2).map(d=>`<span class="tag">${DRVK[d[0]][0]}</span>`).join(' ')+(r.drv.length>2?` <span class="tag more">+${r.drv.length-2}</span>`:'');
    return `<tr class="prow"><td><b>${r.p.n}</b><div class="small muted">${r.p.sup}</div></td>
    <td><span class="status ${c[1]}">${c[0]}</span><div class="vrow"><div class="vbar"><i class="${c[1]}" style="width:${Math.min(100,r.cv/.7*100)}%"></i></div><span class="small num">${Math.round(r.cv*100)}%</span></div></td>
    <td>${top}</td><td class="r"><button class="notebtn" aria-expanded="${open}" onclick="S.pred.open=${open?-1:r.i};render()">${open?'Hide':'Details'}</button></td></tr>
    ${open?`<tr class="pdet"><td colspan="4"><div class="cols2"><div><h4>Key drivers, most influential first</h4>${r.drv.map(d=>`<div class="feat"><div>${DRVK[d[0]][0]}<span class="src">${DRVK[d[0]][1]}</span></div><div class="bar"><i style="width:${d[1]/60*100}%;max-width:100%"></i></div><b class="num small">${d[1]}%</b></div>`).join('')}</div><div><h4>What it means for ordering</h4><p class="muted" style="font-size:14px;margin-top:6px">${c[2]}</p><p class="small muted" style="margin-top:8px">Week-to-week variation is ${Math.round(r.cv*100)}% of the average. Driver shares are illustrative.</p></div></div></td></tr>`:''}`}).join('');
  return `<section class="card"><div class="card-head"><div><h2>How predictable is demand?</h2><p>Variation is how far weekly sales swing around their average. Drivers are what moves sales for each product. Illustrative.</p></div></div>
  <div class="toolbar"><div class="fld grow"><label for="pq">Search</label><input id="pq" type="search" placeholder="Product, supplier or driver" value="${esc(S.pred.q)}" oninput="S.pred.q=this.value;S.pred.shown=8;render()"></div>
    <div class="fld"><label for="pd">Driver</label><select id="pd" onchange="S.pred.drv=this.value;S.pred.shown=8;render()"><option value="all">All drivers</option>${used.map(k=>`<option value="${k}" ${S.pred.drv===k?'selected':''}>${DRVK[k][0]}</option>`).join('')}</select></div>
    <div class="fld"><label for="ps">Sort by</label><select id="ps" onchange="S.pred.sort=this.value;render()">${Object.entries(PSORT).map(([k,v])=>`<option value="${k}" ${S.pred.sort===k?'selected':''}>${v[0]}</option>`).join('')}</select></div></div>
  <div class="chips" role="group" aria-label="Pattern">${[['all','All',PROD.length],['steady','Steady',cnt('steady')],['variable','Variable',cnt('variable')],['lumpy','Lumpy',cnt('lumpy')]].map(([k,l,c])=>`<button aria-pressed="${S.pred.f===k}" onclick="S.pred.f='${k}';S.pred.shown=8;render()">${l}<span class="n num">${c}</span></button>`).join('')}</div>
  ${rows.length?`<div class="tablewrap"><table class="ptable"><thead><tr><th>Product</th><th>Demand pattern</th><th>Key drivers</th><th></th></tr></thead><tbody>${body}</tbody></table></div>
  <div class="summary" style="margin-top:12px"><span>Showing <b class="num">${shown.length}</b> of <b class="num">${rows.length}</b></span>${rows.length>shown.length?`<button class="btn sm" onclick="S.pred.shown+=8;render()">Show ${Math.min(8,rows.length-shown.length)} more</button>`:''}</div>`:'<div class="empty">No products match. <a href="#" onclick="S.pred={f:\'all\',q:\'\',drv:\'all\',sort:\'cv\',shown:8,open:-1};render();return false">Clear filters</a></div>'}</section>`;
}

/* ---------- Data overview tab ---------- */
function dataTab(){
  const tot=DAYS.reduce((a,x)=>a+x.u.reduce((s,v)=>s+(v||0),0),0);
  const rev=DAYS.reduce((a,x)=>a+x.u.reduce((s,v,i)=>s+(v||0)*PRICE[i],0),0);
  const stSum=STORES.map((_,s)=>DAYS.reduce((a,x)=>a+(x.u[s]||0),0));
  const dowS=DOWN.map((_,k)=>{const xs=DAYS.filter(x=>x.d.getUTCDay()===k);return xs.reduce((a,x)=>a+x.u.reduce((s,v)=>s+(v||0),0),0)/xs.length});const dowT=dowS.reduce((a,b)=>a+b,0);
  const dow=[1,2,3,4,5,6,0].map(k=>[DOWN[k],Math.round(dowS[k]/dowT*100)]);const wk=Math.round((dowS[6]+dowS[0])/dowT*100);
  const prodUnits=PROD.map(p=>({n:p.n,u:p.base*SF.reduce((a,b)=>a+b,0)})).sort((a,b)=>b.u-a.u);
  const pTot=prodUnits.reduce((a,b)=>a+b.u,0);const top5=prodUnits.slice(0,5);const top5p=Math.round(top5.reduce((a,b)=>a+b.u,0)/pTot*100);
  const slow=PROD.filter(p=>p.base<5);
  const cv=S.rows,bk=[['Under 1 week',cv.filter(r=>r.cover<1).length,'o'],['1–3 weeks',cv.filter(r=>r.cover>=1&&r.cover<3).length,''],['3–8 weeks',cv.filter(r=>r.cover>=3&&r.cover<8).length,''],['Over 8 weeks',cv.filter(r=>r.cover>=8).length,'o'],['Not moving',cv.filter(isSlow).length,'o'],['Going out of date',cv.filter(isOld).length,'o']];
  return `
    <p class="proto" style="margin:0 0 16px">Illustrative snapshot. Replace with figures computed from the uploaded files. Measures we can’t compute show as “Not enough data”.</p>
    <div class="grid4" style="margin-bottom:24px">
      <div class="card stat" style="margin:0"><h4>Products sold per day</h4><div class="v num">${Math.round(tot/NDAYS)} units</div><div class="basis">Average over ${NDAYS} days</div></div>
      <div class="card stat" style="margin:0"><h4>Average daily sales</h4><div class="v num">$${fmt(Math.round(rev/NDAYS))}</div><div class="basis">All stores</div></div>
      <div class="card stat na" style="margin:0"><h4>Customers per day</h4><div class="v">Not enough data</div><div class="basis">Needs customer or receipt IDs</div></div>
      <div class="card stat" style="margin:0"><h4>Coverage</h4><div class="v num">${STORES.length} stores · ${PROD.length} products</div><div class="basis">${S.rows.length} product-store pairs</div></div></div>
    ${chartCard()}
    <div class="grid2">
      <section class="card"><h2>Where sales come from</h2><p class="muted small" style="margin:4px 0 12px">Share of units, by store</p>
        ${STORES.map((s,i)=>`<div class="hbar"><span>${s}</span><span class="t"><i style="width:${stSum[i]/tot*100}%"></i></span><b class="num">${Math.round(stSum[i]/tot*100)}%</b></div>`).join('')}
        <p class="small muted" style="margin-top:12px">CHI-01 opened about 9 weeks ago, so its history is short.</p></section>
      <section class="card"><h2>Busiest days</h2><p class="muted small" style="margin:4px 0 12px">Share of weekly units, by day</p>
        ${dow.map(d=>`<div class="hbar"><span>${d[0]}</span><span class="t"><i class="${d[1]>=16?'o':''}" style="width:${d[1]*4.5}%"></i></span><b class="num">${d[1]}%</b></div>`).join('')}
        <p class="small muted" style="margin-top:12px">Saturday and Sunday carry ${wk}% of sales, so deliveries landing Friday matter most.</p></section>
      <section class="card"><h2>Product concentration</h2><p class="muted small" style="margin:4px 0 12px">Your top 5 products make up <b>${top5p}%</b> of units</p>
        ${top5.map(p=>`<div class="hbar"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.n)}">${p.n}</span><span class="t"><i style="width:${p.u/top5[0].u*100}%"></i></span><b class="num">${Math.round(p.u/pTot*100)}%</b></div>`).join('')}
        <p class="small muted" style="margin-top:12px">Getting these right matters most. A miss on a long-tail item costs less.</p></section>
      <section class="card"><h2>Stock health today</h2><p class="muted small" style="margin:4px 0 12px">Weeks of cover at current sales pace, product-store pairs</p>
        ${bk.map(b=>`<div class="hbar"><span>${b[0]}</span><span class="t"><i class="${b[2]}" style="width:${b[1]/S.rows.length*100}%"></i></span><b class="num">${b[1]}</b></div>`).join('')}
        <p class="small muted" style="margin-top:12px">Orange = stock-out or overstock risk. In history we found 23 product-store weeks that sold out, so past sales may understate true demand.</p></section>
    </div>
    ${predCard()}
    <section class="card"><h2>Data quality and coverage</h2>
      <div class="grid2" style="margin-top:12px"><table class="matrix"><tbody>
        <tr><td class="muted">Date range</td><td><b>3 Jan – 18 Oct 2026</b></td></tr>
        <tr><td class="muted">Missing values</td><td><b class="num">0.4%</b> of cells, mostly store region</td></tr>
        <tr><td class="muted">Duplicate records</td><td><b class="num">17</b> removed before analysis</td></tr></tbody></table>
      <table class="matrix"><tbody>
        <tr><td class="muted">Unusual days</td><td><b class="num">3</b> days with sales over 3× normal</td></tr>
        <tr><td class="muted">Slow movers</td><td><b class="num">${slow.length}</b> products under 5 a week</td></tr>
        <tr><td class="muted">Date gaps</td><td><b class="num">2</b> days missing for AUS-01</td></tr>
        <tr><td class="muted">Price changes</td><td>Not enough data</td></tr></tbody></table></div></section>`;
}

/* ---------- Report tabs: customers, products, trends and market ---------- */
const TABS=[['summary','Summary'],['data','Data'],['customers','Customers'],['products','Products'],['trends','Trends'],['ideas','Ideas']];
const TAB_SUB={summary:'Recommended actions for next week, and what could shape the weeks after.',data:'An overview of the data behind the recommendations.',customers:'What we can and can’t say about your customers from the files you uploaded.',products:'How each product contributes, and where supply is concentrated.',trends:'Where demand is heading and what’s coming up, using your own history.',ideas:'Products and brands that could fit your range, searched from public sources against your sourcing guidelines.'};
const TODAY=Date.UTC(2026,9,27);
const LEAD={Northwind:5,Orbit:5,Helix:10,Kestrel:6};
const nf=n=>'$'+fmt(Math.round(n));
const gchip=g=>`<span class="chip ${g>=5?'pos':g<=-3?'neg':'flat'}">${g>0?'+':''}${g}%</span>`;
const hb=(l,pct,val,cls)=>`<div class="hbar"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(l)}">${l}</span><span class="t"><i class="${cls||''}" style="width:${Math.max(1,Math.min(100,pct))}%"></i></span><b class="num">${val}</b></div>`;
let PM=null;
function pm(){
  if(PM)return PM;
  const totUnits=DAYS.reduce((a,x)=>a+x.u.reduce((s,v)=>s+(v||0),0),0);
  const revDays=DAYS.reduce((a,x)=>a+x.u.reduce((s,v,i)=>s+(v||0)*PRICE[i],0),0);
  const sb=PROD.reduce((a,p)=>a+p.base,0);
  const rows=PROD.map((p,i)=>{
    const rs=ROWS.filter(r=>r.p===i);const w=rs.reduce((a,r)=>a+r.weekly,0);
    return{i,p,cat:PINFO[i][0],price:PINFO[i][1],months:PINFO[i][2],units:Math.round(totUnits*p.base/sb),weekly:w,
      growth:Math.round(rs.reduce((a,r)=>a+r.up*r.weekly,0)/w),cover:+(rs.reduce((a,r)=>a+r.onHand,0)/w).toFixed(1),lead:LEAD[p.sup],cost:unitCost(i),margin:unitCost(i)===null?null:Math.round((PINFO[i][1]-unitCost(i))/PINFO[i][1]*100)}});
  const raw=rows.reduce((a,r)=>a+r.units*r.price,0);
  rows.forEach(r=>{r.rev=r.units*r.price*revDays/raw;r.share=r.rev/revDays});
  let cum=0;[...rows].sort((a,b)=>b.rev-a.rev).forEach(r=>{r.abc=cum<.7?'A':cum<.9?'B':'C';cum+=r.share});
  rows.forEach(r=>{r.life=r.months<=4?'New':r.growth>=15?'Growing':r.growth<=-3?'Declining':'Mature'});
  PM={rows,totRev:revDays,totUnits};return PM
}
function lateInput(){return `<input id="pick3" type="file" class="sr" multiple accept=".csv,.xlsx,.xls" onchange="addFiles(this.files,true);toast('File added. Re-run the analysis to include it.')">`}
function staleBanner(){return S.stale?`<div class="notice warn"><div><h3>You added data after this report was made</h3><p>Re-run the analysis so the new files are included in the forecast and report.</p><button class="btn sm" onclick="go(2)">Re-run analysis</button></div></div>`:''}

/* summary: beyond this week */
function futureItems(){
  const M=pm();const A=M.rows.filter(r=>r.abc==='A');const aShare=Math.round(A.reduce((a,r)=>a+r.share,0)*100);
  const fast=[...M.rows].sort((a,b)=>b.growth-a.growth)[0];
  const sup=Object.keys(SUP).map(s=>({s,share:Math.round(M.rows.filter(r=>r.p.sup===s).reduce((a,r)=>a+r.share,0)*100)})).sort((a,b)=>b.share-a.share)[0];
  const bf=Math.round((Date.UTC(2026,10,27)-TODAY)/DAY);
  const it=[
   {k:'info',t:'Fastest-growing product',d:`${fast.p.n} is up ${fast.growth}% over the last 2 weeks${fast.life==='New'?` and only ${fast.months} months on sale`:''}.`,tab:'trends',btn:'See trends'},
   {k:'info',t:'Revenue is concentrated',d:`${A.length} class A products bring in ${aShare}% of revenue. Protect their stock first.`,tab:'products',btn:'See products'},
   {k:'warn',t:'Supplier dependence',d:`${sup.s} supplies ${sup.share}% of revenue, with a ${LEAD[sup.s]}-day lead time.`,tab:'products',btn:'See suppliers'},
   {k:'warn',t:`Black Friday is in ${bf} days`,d:'Check each supplier’s order-by date and whether this week’s minimums still work.',tab:'trends',btn:'See calendar'},
   {k:'info',t:'Customers are a blind spot',d:'Without customer or receipt IDs we can’t measure repeat buying or basket size.',tab:'customers',btn:'See what’s missing'}];
  return it;
}

/* customers */
function womIdx(){const b=[0,0,0,0],n=[0,0,0,0];DAYS.forEach(x=>{const k=Math.min(3,Math.floor((x.d.getUTCDate()-1)/7));b[k]+=x.u.reduce((s,v)=>s+(v||0),0);n[k]++});const avg=b.reduce((a,c)=>a+c,0)/n.reduce((a,c)=>a+c,0);return b.map((v,k)=>Math.round(v/n[k]/avg*100))}
function custTab(){
  const M=pm();const pv=S.custPreview;
  const wi=womIdx(),wl=['Days 1–7','Days 8–14','Days 15–21','Days 22–31'];const dev=Math.max(...wi.map(v=>Math.abs(v-100)));
  const bands=[['Under $50',0,50],['$50–$149',50,150],['$150–$499',150,500],['$500 and over',500,1e9]].map(([l,a,b])=>({l,rev:M.rows.filter(r=>r.price>=a&&r.price<b).reduce((s,r)=>s+r.share,0),un:M.rows.filter(r=>r.price>=a&&r.price<b).reduce((s,r)=>s+r.units,0)/M.totUnits}));
  const chi=[];for(let w=0;w<9;w++){let s=0;for(let d=OPEN[3]+w*7;d<Math.min(NDAYS,OPEN[3]+w*7+7);d++)s+=DAYS[d].u[3];chi.push(s)}
  const last4=s=>DAYS.slice(-28).reduce((a,x)=>a+x.u[s],0)/4;const rel=Math.round(last4(3)/last4(2)*100);const cmax=Math.max(...chi);
  const nw=M.rows.filter(r=>r.life==='New');
  const meas=[['Customers per day','Customer or receipt IDs'],['Average basket size','Receipt IDs on each sale'],['Repeat purchase rate','Customer IDs across dates'],['Customer segments','Customer IDs plus loyalty tier or postcode'],['Promotion response','A promotions calendar'],['Returns and complaints','A returns file']];
  const ex=pv?`<section class="card exblock"><div class="card-head"><div><h2>Customer overview</h2><p>Example layout. These numbers are made up to show what you’ll see once customer IDs are added.</p></div><span class="status warn">Example only</span></div>
    <div class="grid4" style="margin-bottom:24px">
     <div class="stat"><h4>Customers per day</h4><div class="v num">31</div><div class="basis">Across all stores</div></div>
     <div class="stat"><h4>Repeat purchase rate</h4><div class="v num">38%</div><div class="basis">Bought again within 90 days</div></div>
     <div class="stat"><h4>Average basket</h4><div class="v num">$142</div><div class="basis">2.1 items per visit</div></div>
     <div class="stat"><h4>New vs returning</h4><div class="v num">44 / 56</div><div class="basis">Percent of customers</div></div></div>
    <div class="tablewrap"><table><thead><tr><th>Segment</th><th>Customers</th><th>Sales</th><th>What it suggests</th></tr></thead><tbody>
     ${[['Loyal regulars',12,41,'Protect availability of their usual items.'],['Seasonal gifters',22,19,'Stock gift lines earlier, ahead of the holidays.'],['One-time buyers',58,31,'Test follow-up offers to bring them back.'],['Business buyers',8,9,'Offer bulk pricing on accessories.']].map(s=>`<tr><td><b>${s[0]}</b></td><td><div class="vrow"><div class="vbar"><i style="width:${s[1]}%"></i></div><span class="num small">${s[1]}%</span></div></td><td><div class="vrow"><div class="vbar"><i style="width:${s[2]}%"></i></div><span class="num small">${s[2]}%</span></div></td><td class="small">${s[3]}</td></tr>`).join('')}</tbody></table></div></section>`:'';
  return `
  <div class="notice info"><div><h3>Customer data isn’t in your files yet</h3><p>Your sales file has no customer or receipt IDs, so we can’t measure who buys, how often, or what they buy together. Below is what your sales already show, and what to add to see more.</p>
   <button class="btn sm" onclick="$('#pick3').click()">+ Add a customer or receipts file</button></div></div>
  <label class="check" style="margin-bottom:24px"><input type="checkbox" ${pv?'checked':''} onchange="S.custPreview=this.checked;render()"><span>Preview the customer overview with example data<br><span class="small muted">Prototype only. Shows the layout, not your customers.</span></span></label>
  ${ex}
  <h2 style="margin:0 0 12px">What your sales already show</h2>
  <div class="grid2">
   <section class="card"><h3>Pay-cycle pattern</h3><p class="muted small" style="margin:4px 0 12px">Daily sales by part of the month, where 100 is the average day</p>
    ${wi.map((v,k)=>hb(wl[k],v/1.3,v,Math.abs(v-100)>=8?'o':'')).join('')}
    <p class="small muted" style="margin-top:12px">${dev<8?'No strong pay-cycle pattern. Sales are spread evenly across the month.':'Sales shift by up to '+dev+'% across the month. Plan deliveries around it.'}</p></section>
   <section class="card"><h3>What people spend per item</h3><p class="muted small" style="margin:4px 0 12px">Share of revenue, by price band</p>
    ${bands.map(b=>hb(b.l,b.rev*100,Math.round(b.rev*100)+'%')).join('')}
    <p class="small muted" style="margin-top:12px">${Math.round(bands[0].un*100)}% of units sold are under $50, but they bring in ${Math.round(bands[0].rev*100)}% of revenue.</p></section>
   <section class="card"><h3>New store ramp-up (CHI-01)</h3><p class="muted small" style="margin:4px 0 12px">Units per week since opening</p>
    ${chi.map((v,w)=>hb('Week '+(w+1),v/cmax*100,v,w>=5?'':'')).join('')}
    <p class="small muted" style="margin-top:12px">CHI-01 now sells about ${rel}% of what AUS-01 does. Its pattern isn’t settled, so revisit its stock targets in a month.</p></section>
   <section class="card"><h3>New products</h3><p class="muted small" style="margin:4px 0 12px">On sale 4 months or less</p>
    ${nw.length?nw.map(r=>`<div class="lrow"><span><b>${r.p.n}</b><br><span class="small muted">${r.cat} · ${r.months} months on sale</span></span><span style="text-align:right"><b class="num">~${r.weekly}/wk</b><br>${gchip(r.growth)}</span></div>`).join(''):'<p class="muted">No new products.</p>'}
    <p class="small muted" style="margin-top:12px">New products have little history, so forecasts for them are less certain.</p></section>
  </div>
  <section class="card"><div class="card-head"><div><h2>Customer measures</h2><p>We only show measures your data supports. The rest show as “Not enough data” rather than a guess.</p></div></div>
   <div class="tablewrap"><table><thead><tr><th>Measure</th><th>Status</th><th>Needs</th><th></th></tr></thead><tbody>
   ${meas.map(m=>`<tr><td><b>${m[0]}</b></td><td><span class="status idle">Not enough data</span></td><td class="small muted">${m[1]}</td><td class="r"><button class="notebtn" onclick="$('#pick3').click()">Add file</button></td></tr>`).join('')}</tbody></table></div></section>`;
}

/* products */
const PSRT={rev:['Highest revenue',(a,b)=>b.rev-a.rev],growth:['Fastest growing',(a,b)=>b.growth-a.growth],decl:['Fastest declining',(a,b)=>a.growth-b.growth],cover:['Least stock cover',(a,b)=>a.cover-b.cover],name:['Product A–Z',(a,b)=>a.p.n.localeCompare(b.p.n)]};
function prodTab(){
  const M=pm();const P=S.prod;
  const cats=[...new Set(M.rows.map(r=>r.cat))];
  const catRows=cats.map(c=>{const rs=M.rows.filter(r=>r.cat===c);const w=rs.reduce((a,r)=>a+r.weekly,0);return{c,share:rs.reduce((a,r)=>a+r.share,0),g:Math.round(rs.reduce((a,r)=>a+r.growth*r.weekly,0)/w),n:rs.length}}).sort((a,b)=>b.share-a.share);
  const sups=Object.keys(SUP).map(s=>({s,share:M.rows.filter(r=>r.p.sup===s).reduce((a,r)=>a+r.share,0),n:M.rows.filter(r=>r.p.sup===s).length})).sort((a,b)=>b.share-a.share);
  const lc=k=>M.rows.filter(r=>r.life===k).length;const ac=k=>M.rows.filter(r=>r.abc===k).length;
  const q=P.q.trim().toLowerCase();
  const list=M.rows.filter(r=>(P.cat==='all'||r.cat===P.cat)&&(P.f==='all'||r.life===P.f)&&(!q||(r.p.n+' '+r.p.sup+' '+r.cat).toLowerCase().includes(q))).sort(PSRT[P.sort][1]);
  const shown=list.slice(0,P.shown);
  return `
  <div class="grid2" style="margin-bottom:24px">
   <section class="card" style="margin:0"><h3>Revenue by category</h3><p class="muted small" style="margin:4px 0 12px">Share of revenue and recent growth</p>
    ${catRows.map(c=>`<div class="hbar" style="grid-template-columns:110px 1fr 92px"><span>${c.c}</span><span class="t"><i style="width:${c.share*100/catRows[0].share}%"></i></span><b class="num">${Math.round(c.share*100)}% ${gchip(c.g)}</b></div>`).join('')}</section>
   <section class="card" style="margin:0"><h3>Supplier dependence</h3><p class="muted small" style="margin:4px 0 12px">Share of revenue, with lead time and minimum order</p>
    ${sups.map(s=>`<div class="hbar" style="grid-template-columns:110px 1fr 48px"><span>${s.s}</span><span class="t"><i class="${s.share>.4?'o':''}" style="width:${s.share*100/sups[0].share}%"></i></span><b class="num">${Math.round(s.share*100)}%</b></div><div class="small muted" style="margin:-4px 0 8px 122px">${LEAD[s.s]}-day lead · minimum ${supRuleOf(s.s)} · ${s.n} products</div>`).join('')}
    ${sups[0].share>.4?`<p class="small" style="margin-top:8px;color:var(--orange-ink)">${sups[0].s} supplies over 40% of revenue. A delay there would hit sales hard.</p>`:''}</section></div>
  <div class="grid4" style="margin-bottom:24px">
   <div class="card stat" style="margin:0"><h4>Lifecycle</h4><div class="small" style="margin-top:8px">New <b>${lc('New')}</b> · Growing <b>${lc('Growing')}</b><br>Mature <b>${lc('Mature')}</b> · Declining <b>${lc('Declining')}</b></div></div>
   <div class="card stat" style="margin:0"><h4>Revenue classes</h4><div class="small" style="margin-top:8px">A <b>${ac('A')}</b> · B <b>${ac('B')}</b> · C <b>${ac('C')}</b><br><span class="muted">Class A brings in ${Math.round(M.rows.filter(r=>r.abc==='A').reduce((a,r)=>a+r.share,0)*100)}% of revenue</span></div></div>
   <div class="card stat" style="margin:0"><h4>Average margin</h4><div class="v num">${(()=>{const w=M.rows.filter(r=>r.margin!==null);const rev=w.reduce((a,r)=>a+r.units*r.price,0);return Math.round(w.reduce((a,r)=>a+r.units*(r.price-r.cost),0)/rev*100)})()}%</div><div class="basis">${M.rows.filter(r=>r.margin!==null).length} of ${M.rows.length} products · cost missing for ${M.rows.filter(r=>r.margin===null).length}</div></div>
   <div class="card stat na" style="margin:0"><h4>Returns</h4><div class="v">Not enough data</div><div class="basis">Needs a returns file</div></div></div>
  <section class="card"><div class="card-head"><div><h2>Product information</h2><p>Revenue is for the history you uploaded. Growth compares the last 2 weeks with the 6 before.</p></div></div>
   <div class="toolbar"><div class="fld grow"><label for="prq">Search</label><input id="prq" type="search" placeholder="Product, category or supplier" value="${esc(P.q)}" oninput="S.prod.q=this.value;S.prod.shown=10;render()"></div>
    <div class="fld"><label for="prc">Category</label><select id="prc" onchange="S.prod.cat=this.value;S.prod.shown=10;render()"><option value="all">All categories</option>${cats.map(c=>`<option ${P.cat===c?'selected':''}>${c}</option>`).join('')}</select></div>
    <div class="fld"><label for="prs">Sort by</label><select id="prs" onchange="S.prod.sort=this.value;render()">${Object.entries(PSRT).map(([k,v])=>`<option value="${k}" ${P.sort===k?'selected':''}>${v[0]}</option>`).join('')}</select></div></div>
   <div class="chips" role="group" aria-label="Lifecycle">${[['all','All',M.rows.length],['New','New',lc('New')],['Growing','Growing',lc('Growing')],['Mature','Mature',lc('Mature')],['Declining','Declining',lc('Declining')]].map(([k,l,c])=>`<button aria-pressed="${P.f===k}" onclick="S.prod.f='${k}';S.prod.shown=10;render()">${l}<span class="n num">${c}</span></button>`).join('')}</div>
   ${list.length?`<div class="tablewrap"><table class="prodtable"><thead><tr><th style="min-width:200px">Product</th><th style="min-width:170px">Revenue</th><th>Units</th><th>Margin</th><th>Trend</th><th>Class</th><th style="min-width:110px">Stock cover</th><th style="min-width:130px">Supplier</th></tr></thead><tbody>
   ${shown.map(r=>`<tr><td><b>${r.p.n}</b><div class="small muted">${r.cat} · ${nf(r.price)}</div></td>
    <td><b class="num">${nf(r.rev)}</b><div class="vrow"><div class="vbar"><i style="width:${Math.min(100,r.share/M.rows.reduce((m,x)=>Math.max(m,x.share),0)*100)}%"></i></div><span class="small num">${(r.share*100).toFixed(1)}%</span></div></td>
    <td class="num">${fmt(r.units)}</td>
    <td class="num">${r.margin===null?'<span class="muted" title="No unit cost in your files">—</span>':r.margin+'%'}</td>
    <td>${gchip(r.growth)}<div class="small muted" style="margin-top:4px">${r.life}</div></td>
    <td><span class="status ${r.abc==='A'?'teal':'idle'}">${r.abc}</span></td>
    <td class="num">${r.cover<1?`<span class="pill bad">${r.cover} wks</span>`:r.cover<2?`<span class="pill warn">${r.cover} wks</span>`:r.cover>6?`<span class="pill warn">${r.cover} wks</span><div class="small muted">Overstock risk</div>`:r.cover+' wks'}</td>
    <td>${r.p.sup}<div class="small muted">${r.lead}-day lead</div></td></tr>`).join('')}</tbody></table></div>
   <div class="summary" style="margin-top:12px"><span>Showing <b class="num">${shown.length}</b> of <b class="num">${list.length}</b></span>${list.length>shown.length?`<button class="btn sm" onclick="S.prod.shown+=10;render()">Show ${Math.min(10,list.length-shown.length)} more</button>`:''}</div>`:'<div class="empty">No products match. <a href="#" onclick="S.prod={q:\'\',cat:\'all\',f:\'all\',sort:\'rev\',shown:10};render();return false">Clear filters</a></div>'}</section>`;
}

/* trends and market */
function trendsTab(){
  const M=pm();const sorted=[...M.rows].sort((a,b)=>b.growth-a.growth);
  const rising=sorted.slice(0,5),falling=sorted.slice(-3).reverse();
  const cats=[...new Set(M.rows.map(r=>r.cat))].map(c=>{const rs=M.rows.filter(r=>r.cat===c);const w=rs.reduce((a,r)=>a+r.weekly,0);return{c,g:Math.round(rs.reduce((a,r)=>a+r.growth*r.weekly,0)/w)}}).sort((a,b)=>b.g-a.g);
  const gmax=Math.max(...cats.map(c=>Math.abs(c.g)),1);
  const wk=series('weekly',[0,1,2,3],'units').filter(b=>!b.partial);const lastW=wk[wk.length-1].total;
  const l6=wk.slice(-6).reduce((a,b)=>a+b.total,0),p6=wk.slice(-12,-6).reduce((a,b)=>a+b.total,0);
  const g=Math.max(-.02,Math.min(.04,Math.pow(l6/p6,1/6)-1));
  const mdl=MODELS.find(x=>x.id===S.model);const base=(100-mdl.acc)/100;
  const outlook=Array.from({length:6},(_,k)=>{const h=2+k;const p=lastW*Math.pow(1+g,h);const e=base+.02*k;const d=new Date(Date.UTC(2026,9,26)+k*7*DAY);return{label:fd(d),p,lo:p*(1-e),hi:p*(1+e),bf:k===4||k===5}});
  const omax=Math.max(...outlook.map(o=>o.hi));
  const ev=[['Black Friday',Date.UTC(2026,10,27)],['Cyber Monday',Date.UTC(2026,10,30)],['Christmas Day',Date.UTC(2026,11,25)]].map(([n,t])=>({n,t,days:Math.round((t-TODAY)/DAY)}));
  const bfT=ev[0].t;
  const sups=Object.keys(SUP).map(s=>({s,lead:LEAD[s],by:new Date(bfT-LEAD[s]*DAY)})).sort((a,b)=>b.lead-a.lead);
  const hol=M.rows.filter(r=>PROD.find(p=>p.n===r.p.n).season).map(r=>r.p.n);
  const OUT=`
  <div class="grid2" style="margin-bottom:24px">
   <section class="card" style="margin:0"><h3>Rising products</h3><p class="muted small" style="margin:4px 0 12px">Last 2 weeks vs the 6 before</p>
    ${rising.map(r=>`<div class="lrow"><span><b>${r.p.n}</b><br><span class="small muted">${r.cat}${r.life==='New'?' · New':''}</span></span>${gchip(r.growth)}</div>`).join('')}
    <h3 style="margin-top:20px">Slowest</h3>
    ${falling.map(r=>`<div class="lrow"><span><b>${r.p.n}</b><br><span class="small muted">${r.cat}</span></span>${gchip(r.growth)}</div>`).join('')}</section>
   <section class="card" style="margin:0"><h3>Category momentum</h3><p class="muted small" style="margin:4px 0 12px">Unit growth, weighted by how much each product sells</p>
    ${cats.map(c=>hb(c.c,Math.abs(c.g)/gmax*100,(c.g>0?'+':'')+c.g+'%',c.g<0?'o':'')).join('')}
    <p class="small muted" style="margin-top:12px">${hol.length?`${hol.join(', ')} are climbing together, which looks like a holiday run-up. We can’t confirm it against last year.`:''}</p></section></div>
  <section class="card"><div class="card-head"><div><h2>Next 6 weeks, if recent trends continue</h2><p>Projected from your recent weekly pace using ${mdl.name}. The range widens the further out we look.</p></div></div>
   <div class="tablewrap"><table><thead><tr><th>Week of</th><th>Projected units</th><th style="min-width:220px">Likely range</th><th>Note</th></tr></thead><tbody>
   ${outlook.map(o=>`<tr><td><b>${o.label}</b></td><td class="num"><b>${fmt(Math.round(o.p))}</b></td><td><div class="rng"><span class="rl" style="left:${o.lo/omax*100}%;width:${(o.hi-o.lo)/omax*100}%"></span><span class="rd" style="left:${o.p/omax*100}%"></span></div><div class="small muted num">${fmt(Math.round(o.lo))} to ${fmt(Math.round(o.hi))}</div></td><td>${o.bf?'<span class="chip warn">Holiday week. Likely higher, not modelled</span>':''}</td></tr>`).join('')}</tbody></table></div>
   <p class="small muted" style="margin-top:12px">Illustrative. Doesn’t include promotions, events or holiday effects, because last year’s sales aren’t in your files.</p></section>
  <div class="grid2">
   <section class="card" style="margin:0"><h3>Coming up</h3><p class="muted small" style="margin:4px 0 12px">Dates that often change shopping patterns</p>
    ${ev.map(e=>`<div class="lrow"><span><b>${e.n}</b><br><span class="small muted">${new Date(e.t).getUTCDate()} ${MONS[new Date(e.t).getUTCMonth()]}</span></span><b class="num">in ${e.days} days</b></div>`).join('')}
    <p class="small muted" style="margin-top:12px">We can’t size the lift without last year’s sales. Upload them to see how these dates affected your stores.</p>
    <button class="btn sm" style="margin-top:8px" onclick="$('#pick3').click()">+ Add last year’s sales</button></section>
   <section class="card" style="margin:0"><h3>Order-by dates for Black Friday</h3><p class="muted small" style="margin:4px 0 12px">Latest order date, from each supplier’s lead time</p>
    <table class="matrix"><thead><tr><th>Supplier</th><th>Lead time</th><th>Order by</th></tr></thead><tbody>${sups.map(s=>`<tr><td><b>${s.s}</b></td><td class="num">${s.lead} days</td><td class="num"><b>${fd(s.by)}</b></td></tr>`).join('')}</tbody></table>
    <p class="small muted" style="margin-top:12px">Lead times come from your ordering rules. Allow extra days for supplier delays.</p></section></div>
`;
  const CTX=`  <section class="card"><div class="card-head"><div><h2>Market context</h2><p>Competitor prices and category growth rates need your own files. We don’t show market figures we can’t source.</p></div><span class="status idle">Not enough data</span></div>
   <div class="tablewrap"><table><thead><tr><th>Question</th><th>What would answer it</th><th></th></tr></thead><tbody>
   ${[['Are we priced above or below competitors?','Competitor prices by product'],['Is our category growing faster than the market?','Category growth rates for your region'],['Will local events or weather change footfall?','Local events calendar or weather history']].map(r=>`<tr><td>${r[0]}</td><td class="small muted">${r[1]}</td><td class="r"><button class="notebtn" onclick="$('#pick3').click()">Add file</button></td></tr>`).join('')}</tbody></table></div></section>
  <section class="card"><div class="card-head"><div><h2>Decisions to consider</h2><p>Questions these signals raise. They’re prompts, not recommendations.</p></div></div>
   ${[['Order holiday stock earlier?',`${hol.slice(0,2).join(' and ')} are rising and Helix needs ${LEAD.Helix} days. Compare the order-by dates above with this week’s supplier minimums.`],['Rebalance new-store stock?','CHI-01 is still ramping up. Review its stock targets in a month rather than scaling from this week.'],['Range down lumpy items?','Lumpy products swing week to week. Check whether they earn their shelf space.'],['Reduce reliance on one supplier?','Check the supplier dependence chart on the Products tab before agreeing new minimums.']].map(d=>`<div class="alert"><span class="ic info" aria-hidden="true">?</span><div><h4>${d[0]}</h4><p>${d[1]}</p></div><span></span></div>`).join('')}</section>`;
  return OUT+CTX;
}

/* ---------- Product opportunities: web and social search, with sourcing guidelines ---------- */
const CITY={'LON-01':'London','MUC-01':'Munich','AUS-01':'Austin','CHI-01':'Chicago'};
const DCATS=[...new Set(PINFO.map(p=>p[0]))];
const dRange=c=>{const ps=PINFO.filter(p=>p[0]===c).map(p=>p[1]);return ps.length?{min:Math.min(...ps),max:Math.max(...ps)}:null};
const ETYPE={article:'Article',review:'Review',social:'Social post',marketplace:'Best-seller list',example:'Example'};
const VALS=[['small','Small or independent business','Ownership'],['women','Women-owned','Ownership'],['minority','Minority-owned','Ownership'],['black','Black-owned','Ownership'],['lgbtq','LGBTQ+-owned','Ownership'],['veteran','Veteran-owned','Ownership'],['family','Family-owned','Ownership'],['local','Based near my stores','Place'],['country','Based in my stores’ countries','Place'],['sustain','Sustainable materials','Practices'],['labour','Fair labour or ethical manufacturing','Practices'],['bcorp','B Corp or similar certification','Practices'],['repair','Repairable or long-lasting','Practices'],['pack','Plastic-free packaging','Practices']];
const VLAB=k=>(VALS.find(v=>v[0]===k)||[k,k])[1];
const VSTATED=VALS.map(v=>v[0]).filter(k=>k!=='local'&&k!=='country');
const LOCALTOK={'LON-01':{local:['london','england'],country:['united kingdom','uk','britain']},'MUC-01':{local:['munich','münchen','bavaria','bayern'],country:['germany','deutschland']},'AUS-01':{local:['austin','texas'],country:['united states','usa','us','america']},'CHI-01':{local:['chicago','illinois'],country:['united states','usa','us','america']}};
const hasTok=(s,t)=>new RegExp('(^|[^a-zà-ÿ])'+t.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'([^a-zà-ÿ]|$)').test(String(s).toLowerCase());
function placeMatch(based,kind){const st=S.disc.region==='all'?STORES:[S.disc.region];return st.some(s=>LOCALTOK[s][kind].some(t=>hasTok(based,t)))}
const EXAMPLE_OPPS=[
 {brand:'Halo Audio',product:'Open-ear wireless earbuds',category:'Audio',price_usd:129,momentum:'Rising',based_in:'Leeds, UK',values_stated:['small','sustain'],why:'Open-ear designs are getting attention for office and commuting use, next to your in-ear range.',evidence:[{type:'review',title:'Open-ear earbuds roundup',publisher:'Example Tech Review',date:'Oct 2026'},{type:'social',title:'Creator comparison video',publisher:'Example short-video platform',date:'Oct 2026'}],risks:['May draw sales from your existing earbuds','Fit varies a lot between ears']},
 {brand:'Brightwell',product:'100W GaN desktop charger',category:'Accessories',price_usd:69,momentum:'Rising',based_in:'Austin, USA',values_stated:['small','women'],why:'Multi-port chargers pair naturally with laptops and tablets and sit in your accessory price range.',evidence:[{type:'marketplace',title:'Chargers best-seller list',publisher:'Example marketplace',date:'Oct 2026'},{type:'article',title:'Founder profile and product test',publisher:'Example Gadget Guide',date:'Sep 2026'}],risks:['Crowded category with many look-alikes']},
 {brand:'Northgrain',product:'Solid-wood laptop stand',category:'Desk',price_usd:59,momentum:'Steady',based_in:'Munich, Germany',values_stated:['small','family','sustain'],why:'Home-office setups keep featuring stands, and the price fits your desk range.',evidence:[{type:'article',title:'Desk setup guide',publisher:'Example Home Office Blog',date:'Aug 2026'},{type:'review',title:'Stand comparison',publisher:'Example Tech Review',date:'Sep 2026'}],risks:['Bulky to ship and store']},
 {brand:'Kiteboard',product:'Low-profile mechanical keyboard',category:'Desk',price_usd:109,momentum:'Early',based_in:'Chicago, USA',values_stated:['small','black'],why:'Early buzz among desk-setup creators. Close to your newest keyboard.',evidence:[{type:'social',title:'Desk setup tour',publisher:'Example video platform',date:'Oct 2026'}],risks:['Social buzz only so far','Overlaps your newest keyboard']},
 {brand:'SlateWorks',product:'E-ink reading tablet',category:'Tablets',price_usd:289,momentum:'Rising',based_in:'Shenzhen, China',values_stated:[],why:'Gift guides are featuring e-ink tablets ahead of the holidays, below your current tablet price.',evidence:[{type:'article',title:'Holiday gift guide',publisher:'Example Gadget Guide',date:'Oct 2026'},{type:'marketplace',title:'Tablets best-seller list',publisher:'Example marketplace',date:'Oct 2026'}],risks:['Different buyer from your current tablet']},
 {brand:'Ember',product:'Sunrise desk lamp with wireless charging',category:'Desk',price_usd:79,momentum:'Steady',based_in:'Portland, USA',values_stated:['women','bcorp'],why:'Combines two desk needs. Sits above your current lamp price.',evidence:[{type:'review',title:'Smart lamps tested',publisher:'Example Tech Review',date:'Jul 2026'},{type:'article',title:'Certified B Corps in home tech',publisher:'Example Business Weekly',date:'Oct 2026'}],risks:['Priced above your current lamp']},
 {brand:'PackLight',product:'Slim magnetic laptop sleeve',category:'Accessories',price_usd:35,momentum:'Steady',based_in:'London, UK',values_stated:['small','minority','repair'],why:'Slim sleeves keep appearing in commuter bag roundups. Adds a premium option to your sleeve range.',evidence:[{type:'article',title:'Commuter bag essentials',publisher:'Example Gadget Guide',date:'Sep 2026'},{type:'social',title:'Brand story post',publisher:'Example photo platform',date:'Oct 2026'}],risks:['Overlaps your existing sleeve']},
 {brand:'Tidepool',product:'Portable waterproof speaker',category:'Audio',price_usd:99,momentum:'Early',based_in:'Seattle, USA',values_stated:['sustain'],why:'A fast-growing speaker niche that sits beside your earbuds as a gift item.',evidence:[{type:'social',title:'Outdoor gear thread',publisher:'Example forum',date:'Oct 2026'}],risks:['Social buzz only so far','New supplier needed']}];
function catGrowth(c){const rs=pm().rows.filter(r=>r.cat===c);if(!rs.length)return null;const w=rs.reduce((a,r)=>a+r.weekly,0);return Math.round(rs.reduce((a,r)=>a+r.growth*r.weekly,0)/w)}
const slug=s=>String(s).toLowerCase().replace(/[^a-z0-9]+/g,'-');
function safeUrl(u){return /^https?:\/\/[^\s"'<>]+$/i.test(u||'')?u:''}
function normOpp(o,mode){
  const cat=DCATS.find(c=>c.toLowerCase()===String(o.category||'').trim().toLowerCase())||String(o.category||'Other').slice(0,40);
  const ev=(Array.isArray(o.evidence)?o.evidence:[]).slice(0,3).map(e=>({type:ETYPE[e&&e.type]?e.type:'article',title:String(e&&e.title||'Source').slice(0,120),publisher:String(e&&e.publisher||'').slice(0,60),date:String(e&&e.date||'').slice(0,20),url:mode==='live'?safeUrl(e&&e.url):''}));
  const price=Number(o.price_usd);
  return{id:slug((o.brand||'')+'-'+(o.product||'')),brand:String(o.brand||'Unknown brand').slice(0,50),product:String(o.product||'').slice(0,80),category:cat,price:isFinite(price)&&price>0?price:null,
    momentum:['Rising','Steady','Early'].includes(o.momentum)?o.momentum:'Early',why:String(o.why||'').slice(0,200),based_in:String(o.based_in||'').slice(0,60),
    valuesStated:(Array.isArray(o.values_stated)?o.values_stated:[]).filter(k=>VSTATED.includes(k)),evidence:ev,risks:(Array.isArray(o.risks)?o.risks:[]).slice(0,3).map(r=>String(r).slice(0,100)),mode}
}
function oppView(o){
  const stocked=DCATS.includes(o.category);const rg=dRange(o.category);
  let pf='unknown';if(!stocked)pf='new';else if(o.price){pf=o.price>rg.max*1.25?'above':o.price<rg.min*.75?'below':'fit'}
  const overlap=stocked?PROD.map((p,i)=>({p,i})).filter(x=>PINFO[x.i][0]===o.category&&(!o.price||(PINFO[x.i][1]>=o.price*.6&&PINFO[x.i][1]<=o.price*1.6))).map(x=>x.p.n):[];
  const nonSocial=o.evidence.filter(e=>e.type!=='social').length;const types=new Set(o.evidence.map(e=>e.type)).size;
  const conf=nonSocial===0?'Low':(o.evidence.length>=2&&types>=2)?'High':o.evidence.length>=2?'Medium':'Low';
  const g=stocked?catGrowth(o.category):null;
  const vm=Object.entries(S.disc.vals).map(([k,s])=>{let st;
    if(k==='local'||k==='country')st=!o.based_in?'unknown':placeMatch(o.based_in,k==='local'?'local':'country')?'matched':'no';
    else st=o.valuesStated.includes(k)&&o.evidence.length?'matched':'unverified';
    return{k,s,st}});
  const mustFail=vm.filter(x=>x.s==='must'&&x.st!=='matched');
  const vscore=vm.reduce((a,x)=>a+(x.st==='matched'?(x.s==='must'?2:1):0),0);
  const score=(stocked?2:0)+(pf==='fit'?2:pf==='unknown'?1:0)+(o.momentum==='Rising'?2:1)+(conf==='High'?2:conf==='Medium'?1:0)+(g!==null&&g>=5?1:0)-(overlap.length>=2?1:0)+vscore;
  return{...o,stocked,pf,overlap,conf,g,vm,mustFail,score}
}
const DISC_SYS='You are a retail trend researcher. Use web search to find products or brands that are gaining interest and could fit a retailer\'s range and sourcing guidelines. Rely only on what you find in search results. Never invent brands, products, URLs or statistics. Prefer items supported by at least two independent sources, and say when support is thin. Include public social media posts or creator roundups when search surfaces them, but treat them as weaker evidence than reviews or sales lists. Never infer who owns or runs a business, or any personal characteristic, from a name, photo or appearance. List a guideline key in values_stated only when a source you cite explicitly states it. Return ONLY a JSON array, with no prose and no markdown, of at most 5 objects with keys: brand, product, category (one of the retailer\'s categories, or a new category name), price_usd (typical retail price as a number, or null), momentum ("Rising", "Steady" or "Early"), based_in (city and country where the brand is based, or null), values_stated (array of guideline keys), why (max 25 words on why it fits), evidence (array of up to 2 objects with keys type ("article","review","social" or "marketplace"), title, publisher, url, date), risks (array of up to 2 short strings). If you find fewer than 3 credible candidates, return fewer.';
const clean=s=>String(s||'').replace(/[\r\n]+/g,' ').replace(/\s+/g,' ').trim();
const exclList=()=>clean(S.disc.excl).split(/[,;]/).map(x=>x.trim()).filter(Boolean);
function discBrief(){
  const D=S.disc;const rng=c=>{const r=dRange(c);return r.min===r.max?`${c} (about $${r.min})`:`${c} ($${r.min} to $${r.max})`};
  const regs=D.region==='all'?STORES.map(s=>CITY[s]):[CITY[D.region]];
  const srcs=[D.src.web&&'web articles and reviews',D.src.social&&'public social media posts and creator roundups',D.src.market&&'marketplace best-seller lists'].filter(Boolean);
  const must=Object.entries(D.vals).filter(([,s])=>s==='must').map(([k])=>k+' = '+VLAB(k)),nice=Object.entries(D.vals).filter(([,s])=>s==='pref').map(([k])=>k+' = '+VLAB(k));
  const g=(must.length||nice.length)?` Sourcing guidelines. ${must.length?'Must have: '+must.join('; ')+'.':''} ${nice.length?'Nice to have: '+nice.join('; ')+'.':''} Only list a guideline key in values_stated if a cited source explicitly states it. Always give based_in.`:'';
  const ex=exclList().length?` Do not suggest these brands: ${exclList().join(', ')}.`:'';
  const note=clean(D.vnote)?` Also consider: ${clean(D.vnote)}.`:'';
  return `Today is 27 October 2026. A consumer electronics retailer sells in ${regs.join(', ')}. Categories stocked and typical price ranges: ${DCATS.map(rng).join('; ')}. Focus on: ${D.focus.length?D.focus.join(', '):'any stocked category'}. ${D.adj?'Adjacent categories are welcome.':'Stay within the focus categories.'} ${D.priceFit?'Stay close to the price ranges above.':''} Find products or brands with growing interest ahead of the holiday season. Use these source types: ${srcs.join(', ')}.${g}${ex}${note}`
}
function parseOpps(text){
  const a=text.indexOf('[');if(a<0)return[];
  const z=text.lastIndexOf(']');let arr=null;
  if(z>a){try{arr=JSON.parse(text.slice(a,z+1))}catch(_){}}
  if(!arr){
    const cuts=[...text.matchAll(/\}\s*,\s*\{\s*"brand"/g)].map(m=>m.index).reverse();
    const e=text.lastIndexOf('}');if(e>a)cuts.unshift(e);
    for(const c of cuts){try{arr=JSON.parse(text.slice(a,c+1)+']');break}catch(_){}}
  }
  return Array.isArray(arr)?arr.filter(x=>x&&typeof x==='object'&&x.brand&&x.product).slice(0,8):[]
}
async function runDiscovery(auto){
  const D=S.disc;if(!D.src.web&&!D.src.social&&!D.src.market)return;D.manual=!auto;
  const ctrl=typeof AbortController!=='undefined'?new AbortController():null;D.ctrl=ctrl;
  D.state='searching';D.msg='';render();
  try{
    const res=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',signal:ctrl?ctrl.signal:undefined,headers:{'Content-Type':'application/json'},body:JSON.stringify({model:'claude-sonnet-4-6',max_tokens:1000,system:DISC_SYS,messages:[{role:'user',content:discBrief()}],tools:[{type:'web_search_20250305',name:'web_search'}]})});
    if(!res.ok)throw new Error('HTTP '+res.status);
    const data=await res.json();
    const text=(data.content||[]).filter(b=>b.type==='text').map(b=>b.text).join('\n');
    const list=parseOpps(text).map(o=>normOpp(o,'live'));
    if(!list.length)throw new Error('No usable results');
    D.results=list;D.mode='live';D.msg=''
  }catch(e){
    if(e&&e.name==='AbortError'){D.state='idle';render();return}
    D.results=EXAMPLE_OPPS.map(o=>normOpp(o,'example'));D.mode='example';
    D.msg='Live search isn’t available in this preview, so these are made-up examples to show the layout.'
  }
  D.state='done';D.sig=discSig();D.run=new Date();D.shown=6;D.cat='all';D.dismissed=[];D.showHidden=false;render()
}
function cancelDiscovery(){if(S.disc.ctrl)S.disc.ctrl.abort();else{S.disc.state='idle';render()}}
function toggleFocus(c){const f=S.disc.focus;const i=f.indexOf(c);if(i>=0)f.splice(i,1);else f.push(c);render()}
function valToggle(k){if(!me().owner)return;if(S.disc.vals[k])delete S.disc.vals[k];else S.disc.vals[k]='pref';render()}
function valStrict(k,v){if(!me().owner)return;S.disc.vals[k]=v;render()}
function valClear(){if(!me().owner)return;S.disc.vals={};S.disc.excl='';S.disc.vnote='';render()}
function slToggle(id){const s=S.disc.sl;const i=s.indexOf(id);if(i>=0)s.splice(i,1);else s.push(id);render()}
function dismissOpp(id){S.disc.dismissed.push(id);S.disc.sl=S.disc.sl.filter(x=>x!==id);render()}
function slCSV(){
  const D=S.disc;let c='brand,product,category,price_usd,based_in,guidelines_matched,momentum,confidence,sources,note\n';
  D.results.filter(o=>D.sl.includes(o.id)).forEach(o=>{const v=oppView(o);c+=[v.brand,v.product,v.category,v.price||'',v.based_in,v.vm.filter(x=>x.st==='matched').map(x=>VLAB(x.k)).join('; '),v.momentum,v.conf,v.evidence.map(e=>e.url||e.publisher+': '+e.title).join(' | '),D.notes[v.id]||''].map(x=>'"'+String(x).replace(/"/g,'""')+'"').join(',')+'\n'});
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([c],{type:'text/csv'}));a.download='product_shortlist.csv';a.click();toast('Shortlist downloaded')
}
function valChip(x){
  const m={matched:['ok','✓ '+VLAB(x.k)],unverified:['idle','? '+VLAB(x.k)+' not stated'],no:['warn','✗ '+VLAB(x.k)],unknown:['idle','? Location not found']}[x.st];
  return `<span class="status ${m[0]}" title="${x.s==='must'?'Must have':'Nice to have'}">${esc(m[1])}${x.s==='must'?' · must':''}</span>`
}
function oppCard(o){
  const v=oppView(o);const D=S.disc;const inSl=D.sl.includes(v.id);
  const pfTxt={fit:['ok','Price fits your range'],above:['warn','Priced above your range'],below:['warn','Priced below your range'],unknown:['idle','Price unknown'],new:['warn','New category for you']}[v.pf];
  const mom={Rising:'pos',Steady:'flat',Early:'seas'}[v.momentum];
  return `<article class="opp ${inSl?'sel':''}"><div class="opp-h"><div><h3>${esc(v.brand)}</h3><div class="muted" style="font-size:14px">${esc(v.product)}${v.based_in?` · <span class="small">${esc(v.based_in)}</span>`:''}</div></div>
    <div class="opp-b"><span class="tag">${esc(v.category)}</span>${v.price?`<span class="tag">~$${fmt(Math.round(v.price))}</span>`:''}<span class="chip ${mom}">${v.momentum}</span><span class="status ${v.conf==='High'?'ok':v.conf==='Medium'?'teal':'idle'}" title="Based on how many independent sources we found, not on how popular the product is">${v.conf} confidence</span></div></div>
    <p style="margin:8px 0">${esc(v.why)}</p>
    ${v.vm.length?`<div class="small muted" style="margin-bottom:4px">Your guidelines</div><div class="fitrow" style="margin-bottom:8px">${v.vm.map(valChip).join('')}</div>`:''}
    <div class="small muted" style="margin-bottom:4px">Range fit</div><div class="fitrow"><span class="status ${v.stocked?'ok':'warn'}">${v.stocked?'Category you stock':'New category for you'}</span><span class="status ${pfTxt[0]}">${pfTxt[1]}</span>${v.g!==null?`<span class="status ${v.g>=5?'ok':'idle'}">Your ${esc(v.category)} sales ${v.g>0?'+':''}${v.g}%</span>`:''}</div>
    <p class="small muted" style="margin-top:8px">${v.overlap.length?'May overlap with: '+v.overlap.map(esc).join(', ')+'.':v.stocked?'No close overlap in your price range.':'Nothing like it in your range yet.'} Customer fit is based on public interest only, since we have no customer data.</p>
    <details style="margin-top:8px"><summary>Evidence (${v.evidence.length}) and risks</summary>
     <div style="margin-top:8px">${v.evidence.map(e=>`<div class="ev"><span class="tag">${ETYPE[e.type]}</span><span>${e.url?`<a href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">${esc(e.title)}</a>`:esc(e.title)}<br><span class="small muted">${esc(e.publisher)}${e.date?' · '+esc(e.date):''}</span></span></div>`).join('')||'<p class="small muted">No sources returned.</p>'}</div>
     <h4 style="margin-top:12px">Before you commit</h4><ul class="small" style="margin:4px 0 0;padding-left:18px">${v.risks.map(r=>`<li>${esc(r)}</li>`).join('')}${v.vm.some(x=>x.st==='matched'&&x.k!=='local'&&x.k!=='country')?'<li>Ownership and certification come from the cited sources. Confirm them with the supplier.</li>':''}<li>Margin and supplier terms aren’t known. Check them first.</li></ul></details>
    <div class="btns" style="margin-top:12px"><button class="btn sm ${inSl?'':'primary'}" onclick="slToggle('${v.id}')" aria-pressed="${inSl}">${inSl?'✓ On shortlist':'Add to shortlist'}</button><button class="btn sm" onclick="dismissOpp('${v.id}')">Not interested</button></div></article>`;
}
const discSig=()=>{const D=S.disc;return JSON.stringify([D.focus,D.adj,D.priceFit,D.region,D.src,D.vals,D.excl,D.vnote])};
function valCycle(k){if(!me().owner)return;const v=S.disc.vals[k];if(!v)S.disc.vals[k]='pref';else if(v==='pref')S.disc.vals[k]='must';else delete S.disc.vals[k];render()}
function gChip(k){
  const s=S.disc.vals[k];const st=s==='must'?'must have':s==='pref'?'nice to have':'off';
  return `<button class="${s==='must'?'must':''}" aria-pressed="${!!s}" ${me().owner?'':'disabled'} aria-label="${esc(VLAB(k))}, ${st}. Press to change." title="Click to cycle: off, nice to have, must have" onclick="valCycle('${k}')">${esc(VLAB(k))}${s?' · '+(s==='must'?'must':'nice'):''}</button>`
}
function discCard(){
  const D=S.disc,own=!!me().owner,dis=own?'':'disabled';
  const sources=D.src.web||D.src.social||D.src.market;const searching=D.state==='searching';
  const ex=exclList().map(x=>x.toLowerCase());
  const all=D.state==='done'?D.results.filter(o=>!D.dismissed.includes(o.id)&&!ex.some(t=>o.brand.toLowerCase().includes(t))).map(oppView):[];
  const cats=[...new Set(all.map(v=>v.category))];
  const hidden=all.filter(v=>v.mustFail.length);
  const SR={fit:['Best fit',(a,b)=>b.score-a.score],conf:['Most evidence',(a,b)=>['Low','Medium','High'].indexOf(b.conf)-['Low','Medium','High'].indexOf(a.conf)||b.score-a.score],rising:['Rising first',(a,b)=>['Early','Steady','Rising'].indexOf(b.momentum)-['Early','Steady','Rising'].indexOf(a.momentum)||b.score-a.score]};
  const list=all.filter(v=>(D.showHidden||!v.mustFail.length)&&(D.cat==='all'||v.category===D.cat)).sort(SR[D.sort][1]);
  const shown=list.slice(0,D.shown);
  const changed=D.state==='done'&&D.sig!==discSig();
  const live=D.mode==='live';
  const sel=Object.entries(D.vals);
  const nsrc=[D.src.web,D.src.social,D.src.market].filter(Boolean).length;
  const sl=D.results.filter(o=>D.sl.includes(o.id)).map(oppView);
  const head=`<div class="card-head"><div><h2>Products and brands to consider adding</h2><p>Public web pages, reviews, best-seller lists and social posts, matched to your range and sourcing guidelines.</p></div>
    <div class="btns" style="align-items:center">${D.state==='done'?`<span class="status ${live?'teal':'warn'}">${live?'Live search':'Example only'}</span>`:''}<button class="btn primary" onclick="runDiscovery()" ${sources&&!searching?'':'disabled'}>${D.state==='done'?'Search again':'Search the web'}</button></div></div>`;
  const filters=`<div class="card filterbar">
    ${D.state==='done'?`<div class="frow"><span class="flab">Show</span><div class="chips" role="group" aria-label="Category"><button aria-pressed="${D.cat==='all'}" onclick="S.disc.cat='all';S.disc.shown=6;render()">All<span class="n num">${all.filter(v=>D.showHidden||!v.mustFail.length).length}</span></button>${cats.filter(c=>D.cat===c||all.some(v=>v.category===c&&(D.showHidden||!v.mustFail.length))).map(c=>`<button aria-pressed="${D.cat===c}" onclick="S.disc.cat='${esc(c).replace(/'/g,'')}';S.disc.shown=6;render()">${esc(c)}<span class="n num">${all.filter(v=>v.category===c&&(D.showHidden||!v.mustFail.length)).length}</span></button>`).join('')}</div>
      <div class="fld sortf"><label for="dsort" class="sr">Sort by</label><select id="dsort" onchange="S.disc.sort=this.value;render()">${Object.entries(SR).map(([k,v])=>`<option value="${k}" ${D.sort===k?'selected':''}>${v[0]}</option>`).join('')}</select></div></div>`:''}
    <div class="frow"><span class="flab">Guidelines</span><div class="chips" role="group" aria-label="Guidelines applied">${sel.length?sel.map(([k])=>gChip(k)).join(''):'<span class="small muted" style="align-self:center">None set</span>'}<button class="lnk" onclick="S.disc.gOpen=!S.disc.gOpen;render()" aria-expanded="${D.gOpen}">${D.gOpen?'Done':own?'Edit guidelines':'See all guidelines'}</button></div></div>
    ${D.gOpen?`<div class="gpanel">${own?'<p class="small muted" style="margin-bottom:8px">Press a guideline to cycle: off, nice to have (ranks higher), must have (hides ideas that don’t meet it).</p>':'<p class="small muted" style="margin-bottom:8px">Only the business owner can change guidelines. They apply to your results.</p>'}
      ${['Ownership','Place','Practices'].map(g=>`<div class="small muted" style="margin:8px 0 4px">${g}</div><div class="chips" role="group" aria-label="${g}">${VALS.filter(v=>v[2]===g).map(v=>gChip(v[0])).join('')}</div>`).join('')}
      <p class="small muted" style="margin-top:12px">We never guess who owns a business from a name or photo. A guideline shows as matched only when a cited source says so. Confirm with the supplier.</p>${sel.length&&own?'<button class="lnk" style="margin-top:4px" onclick="valClear()">Clear all guidelines and exclusions</button>':''}</div>`:''}
  </div>`;
  const settings=`<details class="card setcard" ${D.sOpen?'open':''} ontoggle="S.disc.sOpen=this.open"><summary><b>Search settings</b><span>${esc(D.focus.join(', ')||'All stocked categories')} · ${D.region==='all'?'All store regions':CITY[D.region]} · ${nsrc} ${nsrc===1?'source':'sources'}</span></summary>
    <div class="setgrid">
     <div><h4>Search these categories</h4><div class="chips" role="group" aria-label="Categories to search" style="margin-top:8px">${DCATS.map(c=>`<button aria-pressed="${D.focus.includes(c)}" onclick="toggleFocus('${c}')">${c}</button>`).join('')}</div>
      <label class="check small" style="margin-top:8px"><input type="checkbox" ${D.adj?'checked':''} onchange="S.disc.adj=this.checked;render()">Include adjacent categories</label>
      <label class="check small" style="margin-top:6px"><input type="checkbox" ${D.priceFit?'checked':''} onchange="S.disc.priceFit=this.checked;render()">Stay near my current price ranges</label></div>
     <div><div class="fld"><label for="dreg">Region</label><select id="dreg" onchange="S.disc.region=this.value;render()"><option value="all">All store regions</option>${STORES.map(s=>`<option value="${s}" ${D.region===s?'selected':''}>${CITY[s]}</option>`).join('')}</select></div>
      <div class="small muted" style="margin:12px 0 4px">Look in</div>
      <label class="check small"><input type="checkbox" ${D.src.web?'checked':''} onchange="S.disc.src.web=this.checked;render()">Web articles and reviews</label>
      <label class="check small" style="margin-top:6px"><input type="checkbox" ${D.src.social?'checked':''} onchange="S.disc.src.social=this.checked;render()">Public social posts and creator roundups</label>
      <label class="check small" style="margin-top:6px"><input type="checkbox" ${D.src.market?'checked':''} onchange="S.disc.src.market=this.checked;render()">Marketplace best-seller lists</label></div>
     <div><div class="fld"><label for="dex">Brands to leave out</label><input id="dex" ${dis} placeholder="Comma-separated, for example: BrandA, BrandB" value="${esc(D.excl)}" onchange="S.disc.excl=this.value;render()"></div>
      <div class="fld" style="margin-top:12px"><label for="dvn">Anything else that matters</label><textarea id="dvn" maxlength="200" ${dis} placeholder="For example: prefer repair-friendly designs" oninput="S.disc.vnote=this.value">${esc(D.vnote)}</textarea></div>
      ${own?'':'<p class="small muted" style="margin-top:8px">Only the business owner can change these two.</p>'}
      <label class="check small" style="margin-top:12px"><input type="checkbox" ${D.auto?'checked':''} onchange="S.disc.auto=this.checked;render()"><span>Search automatically when I open this tab<br><span class="muted">Uses these settings and sends the brief below.</span></span></label></div>
    </div>
    <details style="margin-top:12px"><summary>What we send, and what we don’t see</summary><p class="d">Only this brief goes to the search: category names and price ranges, store regions, your focus and your guidelines. No sales figures, customer data, product names or supplier names are sent.</p><p class="small" style="background:var(--surface-2);border-radius:8px;padding:10px 12px;margin-top:8px">${esc(discBrief())}</p><p class="d">We search public pages. We don’t sign in to social platforms, and we can’t see private accounts or your customers’ activity.</p></details>
    <div class="btns" style="margin-top:12px"><button class="btn primary" onclick="runDiscovery()" ${sources&&!searching?'':'disabled'}>${D.state==='done'?'Search again':'Search the web'}</button>${!sources?'<span class="small muted" style="align-self:center">Choose at least one source.</span>':''}</div></details>`;
  let body='';
  if(searching)body=`<div class="notice info" aria-live="polite"><span class="spin" aria-hidden="true"></span><div><h3>Searching public sources</h3><p>${D.auto&&!D.manual?'Started automatically with your saved settings. ':''}This can take up to a minute. You can keep using the report.</p><button class="btn sm" onclick="cancelDiscovery()">Cancel</button></div></div>`;
  else if(D.state!=='done')body=`<div class="card" style="text-align:center;padding:48px 24px"><h3>No search yet</h3><p class="muted" style="max-width:48ch;margin:8px auto 16px">Search public web pages, reviews, best-seller lists and social posts for products that could fit your range and guidelines.</p><button class="btn primary" onclick="runDiscovery()" ${sources?'':'disabled'}>Search the web</button></div>`;
  else body=`<div style="margin:0 0 24px"><div class="summary" style="margin-bottom:8px"><span><b class="num">${list.length}</b> ${list.length===1?'idea':'ideas'} · ${live?'searched '+D.run.toLocaleDateString('en-GB',{day:'numeric',month:'short'})+', sources linked':'example results, names and sources are made up'}</span></div>
    ${D.msg?`<div class="notice warn"><div><p style="margin:0">${D.msg}</p></div></div>`:''}
    ${changed?`<div class="notice info"><div><p style="margin:0">Search settings changed since this search. Guidelines and exclusions already filter the results below. <button class="lnk" onclick="runDiscovery()">Search again</button> to look for more matches.</p></div></div>`:''}
    ${hidden.length?`<div class="notice info"><div><p style="margin:0"><b>${hidden.length}</b> ${hidden.length===1?'idea is':'ideas are'} ${D.showHidden?'shown although they':'hidden because they'} don’t meet a must-have guideline. <button class="lnk" onclick="S.disc.showHidden=${!D.showHidden};render()">${D.showHidden?'Hide them':'Show them'}</button></p></div></div>`:''}
    ${shown.length?`<div class="oppgrid">${shown.map(v=>oppCard(v)).join('')}</div>`:'<div class="empty">Nothing matches. Relax a guideline or choose another category.</div>'}
    <div class="summary" style="margin-top:12px"><span>Showing <b class="num">${shown.length}</b> of <b class="num">${list.length}</b></span>${list.length>shown.length?`<button class="btn sm" onclick="S.disc.shown+=6;render()">Show ${Math.min(6,list.length-shown.length)} more</button>`:''}</div>
    <p class="small muted" style="margin-top:12px;max-width:70ch">Confidence reflects how many independent sources we found, not how popular a product is. Social posts count as weaker evidence than reviews or sales lists, and trends can be promotional. Treat these as leads to research.</p></div>`;
  const shortlist=sl.length?`<div class="card" style="margin:0"><div class="card-head" style="margin-bottom:8px"><div><h3>Shortlist (${sl.length})</h3><p>Shortlisting doesn’t order anything. Check margin, supplier terms and minimums first.</p></div><button class="btn sm" onclick="slCSV()" ${canExport()?'':'disabled title="Your role can’t export"'}>Download shortlist</button></div>
     ${sl.map(o=>`<div class="ev" style="align-items:center"><span style="flex:1"><b>${esc(o.brand)}</b> · ${esc(o.product)}<br><span class="small muted">${esc(o.category)} · ${o.momentum} · ${o.conf} confidence${o.based_in?' · '+esc(o.based_in):''}</span></span><div class="fld" style="width:min(320px,45%)"><label class="sr" for="n-${o.id}">Note for ${esc(o.brand)}</label><input id="n-${o.id}" placeholder="Note, for example: ask Helix for terms" value="${esc(D.notes[o.id]||'')}" onchange="S.disc.notes['${o.id}']=this.value"></div><button class="iconbtn" aria-label="Remove ${esc(o.brand)} from shortlist" onclick="slToggle('${o.id}')">✕</button></div>`).join('')}</div>`:'';
  return head+filters+body+shortlist+settings;
}

function s4(){
  const mdl=MODELS.find(x=>x.id===S.model).name;
  const tabs=`<div class="tabs" role="tablist">${TABS.map(([k,l])=>`<button role="tab" aria-selected="${S.tab===k}" onclick="S.tab='${k}';render()">${k==='ideas'&&S.disc.sl.length?l+' ('+S.disc.sl.length+')':l}</button>`).join('')}</div>`;
  let body='';
  if(S.tab==='summary'){
    const al=alertsList();
    const prev=S.rows.filter(r=>r.qty>0).sort((a,b)=>b.qty-a.qty).slice(0,5);
    body=`<div class="kpis k4">
      <div class="card kpi"><div class="v num">${skuCount()}</div><div class="l">SKUs to order</div><div class="s">Unique products</div></div>
      <div class="card kpi"><div class="v num">${fmt(totalUnits())}</div><div class="l">Units to order</div><div class="s">Total quantity across stores</div></div>
      <div class="card kpi"><div class="v num">${money(orderValue())}${orderMissing()?'+':''}</div><div class="l">Order value</div><div class="s">At cost${orderMissing()?'. Excludes '+orderMissing()+' units with no cost':''}</div></div>
      <div class="card kpi ${toReview()?'kpiwarn':''}"><div class="v num">${toReview()}</div><div class="l">Entries to review</div><div class="s">Product–store entries flagged</div></div></div>
    ${attentionCard(mdl)}
    ${stockCard()}
    ${pbCompare()}
    <section class="card"><div class="card-head"><h2>Largest orders</h2><button class="btn ghost" onclick="go(5)">See full list</button></div>
    <div class="tablewrap"><table><thead><tr><th>Product</th><th>Store</th><th class="r">Order qty</th><th>Signals</th></tr></thead><tbody>
    ${prev.map(r=>`<tr><td>${PROD[r.p].n}</td><td>${STORES[r.s]}</td><td class="r num"><b>${r.qty}</b></td><td>${r.up>=25?`<span class="chip up">↑ ${r.up}%</span> `:''}${r.seasonal?`<span class="chip seas">${PROD[r.p].season}</span> `:''}${needsReview(r)?'<span class="chip warn">Review</span>':''}${r.up<25&&!r.seasonal&&!needsReview(r)?'<span class="muted">—</span>':''}</td></tr>`).join('')}</tbody></table></div></section>`;
  }else{
    body=({data:dataTab,customers:custTab,products:prodTab,trends:trendsTab,ideas:discCard}[S.tab]||dataTab)();
  }
  return `<div class="page-head"><h1>Your business report</h1><p>${TAB_SUB[S.tab]}</p></div>${staleBanner()}${tabs}${body}${lateInput()}
  <div class="actions"><button class="btn ghost" onclick="go(3)">← Back to models</button><div class="right"><button class="btn primary" onclick="go(5)">Review and edit orders →</button></div></div>`;
}

/* ---------- Screen 5 ---------- */
const me=()=>PEOPLE.find(p=>p.id===S.user);
const canEdit=r=>{const m=me();return !!m.owner||m.stores.includes(STORES[r.s])};
const canStore=st=>me().stores.includes(st);
const allStoresDone=()=>STORES.every(s=>S.appr[s].state==='approved');
const allApproved=()=>allStoresDone()&&S.appr.owner.state==='approved';
const doneCount=()=>[...STORES,'owner'].filter(k=>S.appr[k].state==='approved').length;
const canExport=()=>{const m=me();return !!m.owner||m.stores.length>0};
const exportIdx=()=>S.rows.map((r,i)=>i).filter(i=>canEdit(S.rows[i]));
const nowStr=()=>new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
const unitsFor=st=>S.rows.filter(r=>STORES[r.s]===st).reduce((a,r)=>a+r.qty,0);
const approvers=st=>PEOPLE.filter(p=>p.stores.includes(st));
const isWatch=r=>r.qty===0&&watchDays(r)!==null;
const DIR=()=>[...PEOPLE.map(p=>({name:p.name,email:p.email,desc:p.role+(p.stores.length?' · '+p.stores.join(', '):''),tag:'Workspace'})),...EXTERNAL.map(e=>({name:e.name,email:e.email,desc:'Accountant',tag:'Approved external'})),...S.pending.map(e=>({name:e,email:e,desc:'Awaiting admin approval',tag:'Pending',locked:true}))];

function filterOpts(){
  const m=me();const c=k=>S.rows.filter(r=>pass(r,k)).length;
  const o=[['all','All entries ('+S.rows.length+')','Priority'],['sev-act','Needs action ('+c('sev-act')+')','Priority'],['sev-review','Needs review ('+c('sev-review')+')','Priority'],['sev-watch','On watch ('+c('sev-watch')+')','Priority'],
   ['supplier','Supplier below minimum ('+c('supplier')+')','Type'],['slow','Not moving ('+c('slow')+')','Type'],['old','Going out of date ('+c('old')+')','Type'],['watch','Approaching low stock ('+c('watch')+')','Type'],['uptick','Sales uptick ('+c('uptick')+')','Type'],['seasonal','Possible seasonal ('+c('seasonal')+')','Type']];
  if(S.expPreview)o.push(['expiry','Expiring ('+c('expiry')+')','Type']);
  o.push(['edited','Edited ('+c('edited')+')','Other']);
  if(!m.owner&&m.stores.length)o.push(['mine','My stores ('+c('mine')+')','Other']);
  return o}
function filterSelect(){
  const o=filterOpts();
  return `<div class="fld"><label for="fl">Show</label><select id="fl" onchange="S.rv.filter=this.value;render()">${['Priority','Type','Other'].map(g=>{const rs=o.filter(x=>x[2]===g);return rs.length?`<optgroup label="${g}">${rs.map(([v,t])=>`<option value="${v}" ${v===S.rv.filter?'selected':''}>${t}</option>`).join('')}</optgroup>`:''}).join('')}</select></div>`}
function pass(r,f){
  if(f.startsWith('sev-'))return sevOf(r)===f.slice(4);
  if(f==='mine')return me().stores.includes(STORES[r.s]);
  if(f==='review')return needsReview(r);if(f==='edited')return r.qty!==r.sug;if(f==='uptick')return r.up>=25;if(f==='seasonal')return r.seasonal;
  if(f==='supplier')return rowSupShort(r);if(f==='watch')return isWatch(r);if(f==='slow')return isSlow(r);if(f==='old')return isOld(r);if(f==='expiry')return !!expRisk(r._i);return true}
const SORTS={qty:['Biggest order',(a,b)=>b.qty-a.qty],uptick:['Biggest sales uptick',(a,b)=>b.up-a.up],cover:['Least stock cover',(a,b)=>a.cover-b.cover],last:['Largest vs last restock',(a,b)=>(b.qty/b.last)-(a.qty/a.last)],name:['Product A–Z',(a,b)=>PROD[a.p].n.localeCompare(PROD[b.p].n)||a.s-b.s]};
function gKey(r){const g=S.rv.group;
  if(g==='store')return STORES[r.s];if(g==='product')return PROD[r.p].n;if(g==='supplier')return PROD[r.p].sup;if(g==='category')return PINFO[r.p][0];
  if(g==='attention'){const s=sevOf(r);return s==='act'?'1|Act now':s==='review'?'2|Review':(s==='watch'||r.up>=25||r.seasonal)?'3|Watch':'4|No flags'}
  return '0|All entries'}
function visible(){
  const q=S.rv.q.trim().toLowerCase();
  return S.rows.map((r,i)=>i).filter(i=>{const r=S.rows[i];
    const keepZero=['watch','slow','old','expiry','sev-act','sev-review','sev-watch'].includes(S.rv.filter)||(S.rv.group==='attention'&&!!sevOf(r));
    if(S.rv.hideZero&&!keepZero&&r.qty===0&&r.qty===r.sug)return false;
    if(!pass(r,S.rv.filter))return false;
    if(S.rv.sup&&PROD[r.p].sup!==S.rv.sup)return false;
    if(q&&!(PROD[r.p].n+' '+STORES[r.s]+' '+PROD[r.p].sup).toLowerCase().includes(q))return false;return true});
}
function qtyCell(i){const r=S.rows[i],ok=canEdit(r);const dis=ok?'':`disabled title="Only ${STORES[r.s]} approvers can edit"`;
  return `<div class="qty ${r.qty!==r.sug?'changed':''}"><button aria-label="Decrease" ${dis} onclick="bump(${i},-1)">−</button><input type="number" min="0" value="${r.qty}" ${dis} aria-label="Quantity for ${esc(PROD[r.p].n)} at ${STORES[r.s]}" onchange="setQty(${i},this.value)"><button aria-label="Increase" ${dis} onclick="bump(${i},1)">+</button></div>${r.qty!==r.sug?`<span class="chg">was ${r.sug} · ${esc((r.editor||'').split(' ')[0])}</span>`:''}`}
function rowHTML(i){
  const r=S.rows[i],pr=PROD[r.p],g=S.rv.group,ok=canEdit(r);
  const main=g==='store'?pr.n:g==='product'?STORES[r.s]:pr.n+' · '+STORES[r.s];
  const sub=(g==='supplier'?'':pr.sup+' · ')+(pr.pack>1?'packs of '+pr.pack:'single units');
  const iss=issues(r);const n=S.notes[i];const wd=watchDays(r);
  const fl=rowFlags(r);const fOpen=!!S.openFlags[i];
  const flags=(fOpen?fl:fl.slice(0,2)).map(f=>`<span class="chip ${f.sev==='act'?'bad':f.sev==='review'?'warn':'watch'}">${esc(f.t)}</span>`);
  if(fl.length>2)flags.push(`<button class="chip more" aria-expanded="${fOpen}" onclick="toggleFlags(${i})">${fOpen?'Show less':'+'+(fl.length-2)+' more'}</button>`);
  const reviewed=iss.length&&r.reviewed?'<span class="status ok">✓ Reviewed</span>':'';
  const markBtn=iss.length&&!r.reviewed&&ok?`<button class="notebtn" onclick="markRev(${i})">Mark reviewed</button>`:'';
  const noteBtn=ok?`<button class="notebtn" onclick="S.openNote=S.openNote===${i}?null:${i};render()">${n?'Edit note':'Add note'}</button>`:'';
  return `<tr>
  <td><b>${main}</b><div class="small muted">${sub}</div></td>
  <td class="num"><div><b>${r.onHand}</b> on hand</div><div class="s">Cover ${r.cover<1?`<span class="pill bad">${r.cover} wks</span>`:r.cover<2?`<span class="pill warn">${r.cover} wks</span>`:`${r.cover} wks`}</div>${r.inc?`<div class="s">+${r.inc} incoming</div>`:''}</td>
  <td class="num"><div><b>${r.last}</b> units</div><div class="s">${r.ld}</div></td>
  <td><div>${r.up>=25?`<span class="chip up">↑ ${r.up}%</span>`:`<span class="num">${r.up>0?'+':''}${r.up}%</span>`}</div><div class="s">~${r.weekly}/wk</div>${r.seasonal?`<div style="margin-top:4px"><span class="chip seas">${pr.season}</span></div>`:''}</td>
  <td class="ordercell"><div class="sugg">Suggested <b class="num">${r.sug}</b></div>${qtyCell(i)}<div class="s">${r.qty>0?(lineCost(r)===null?'Cost unknown':money(lineCost(r))+' at cost'):''}</div></td>
  <td class="flagcell">${flags.join('')||'<span class="muted">—</span>'}${reviewed}<div class="acts">${markBtn}${noteBtn}</div>${n&&S.openNote!==i?`<div class="small muted" style="max-width:26ch">“${esc(n)}”</div>`:''}</td></tr>
  ${S.openNote===i?`<tr class="noterow"><td colspan="6"><input id="nt" placeholder="Why are you changing this? Your reviewers will see it." value="${esc(n||'')}" onchange="S.notes[${i}]=this.value.trim();S.openNote=null;render();toast('Note saved')" onblur="S.notes[${i}]=this.value.trim()"></td></tr>`:''}`;
}
function listHTML(){
  const idx=visible();
  if(!idx.length)return `<div class="empty">No entries match. <a href="#" onclick="clearFilters();return false">Clear filters</a></div>`;
  const map={};idx.forEach(i=>{const k=gKey(S.rows[i]);(map[k]=map[k]||[]).push(i)});
  const keys=Object.keys(map).sort();const sf=SORTS[S.rv.sort][1];
  const body=keys.map(k=>{
    const arr=map[k].sort((a,b)=>sf(S.rows[a],S.rows[b]));const label=k.includes('|')?k.split('|')[1]:k;
    const units=arr.reduce((a,i)=>a+S.rows[i].qty,0);const mine=arr.filter(i=>needsReview(S.rows[i])&&canEdit(S.rows[i])).length;const nr=arr.filter(i=>needsReview(S.rows[i])).length;
    const col=S.rv.collapsed[k];
    let sup='';if(S.rv.group==='supplier'){const st=supStat(k);sup=st.none?'<span class="status idle">Nothing to order</span>':!st.ok?`<span class="status warn">Needs ${supRule(st)} · ordering ${supNow(st)}</span>`:`<span class="status ok">✓ Meets ${supRule(st)}</span>`}
    return `<tr class="group-head"><td colspan="6"><div class="gl"><button class="gt" aria-expanded="${!col}" onclick="toggleGroup('${esc(k)}')"><span aria-hidden="true">${col?'▸':'▾'}</span>${label}</button><span class="gs num">${arr.length} entries · ${units} units · ${money(arr.reduce((a,i)=>a+(lineCost(S.rows[i])||0),0))}${nr?` · ${nr} to review`:''}</span>${sup}
      <span class="push">${mine?`<button class="btn sm" onclick="markGroup('${esc(k)}')">Mark ${mine} reviewed</button>`:''}</span></div></td></tr>${col?'':arr.map(rowHTML).join('')}`}).join('');
  return `<div class="listwrap"><table><thead><tr><th>${S.rv.group==='store'?'Product':S.rv.group==='product'?'Store':'Product · store'}</th><th style="min-width:150px">Stock</th><th style="min-width:110px">Last restock</th><th style="min-width:140px">Demand, last 2 wks</th><th style="min-width:160px">Order</th><th style="min-width:220px">Flags and notes</th></tr></thead><tbody>${body}</tbody></table></div>`;
}
function clearFilters(){S.rv.filter='all';S.rv.q='';S.rv.sup='';S.rv.hideZero=false;render()}
function toggleGroup(k){S.rv.collapsed[k]=!S.rv.collapsed[k];render()}
function setAllGroups(c){const g={};S.rows.forEach(r=>{g[gKey(r)]=c});S.rv.collapsed=c?g:{};render()}
function markGroup(k){const vis=visible();S.rows.forEach((r,i)=>{if(gKey(r)===k&&needsReview(r)&&canEdit(r)&&vis.includes(i))r.reviewed=true});render()}
function markVisible(){let n=0;visible().forEach(i=>{const r=S.rows[i];if(needsReview(r)&&canEdit(r)){r.reviewed=true;n++}});render();toast(n?n+' marked as reviewed':'Nothing to mark')}
function jumpWatch(){S.rv.filter='watch';S.rv.sup='';render()}

/* supplier drawer */
function openSup(fromReport){S.supOpen=true;S.supQ='';S.supOnly=true;if(fromReport)S.step=5;render();setTimeout(()=>{const c=$('#dclose');if(c)c.focus()},0)}
function closeSup(){S.supOpen=false;render();const b=$('#sup-open-btn');if(b)b.focus()}
function showSup(n){S.rv.sup=n;S.rv.filter='all';S.supOpen=false;render();const t=$('#order-list');if(t)t.scrollIntoView({behavior:'smooth'})}
function drawerHTML(){
  if(!S.supOpen)return '';
  const all=supStats();const nShort=all.filter(s=>s.short>0).length;
  const list=all.filter(s=>(!S.supOnly||s.short>0)&&s.name.toLowerCase().includes(S.supQ.toLowerCase())).sort((a,b)=>b.short-a.short||a.name.localeCompare(b.name));
  return `<div class="scrim" onclick="closeSup()"></div><aside class="drawer" role="dialog" aria-modal="true" aria-labelledby="dt">
  <header><div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start"><h2 id="dt">Supplier minimums</h2><button class="iconbtn" id="dclose" aria-label="Close" onclick="closeSup()">✕</button></div>
  <p class="muted small" style="margin-top:4px"><b>${nShort}</b> of ${all.length} suppliers are below their minimum order size.</p>
  <div class="fld" style="margin-top:12px"><label for="dq" class="sr">Search suppliers</label><input id="dq" type="search" placeholder="Search suppliers" value="${esc(S.supQ)}" oninput="S.supQ=this.value;render()"></div>
  <label class="check small" style="margin-top:12px"><input type="checkbox" ${S.supOnly?'checked':''} onchange="S.supOnly=this.checked;render()">Only show suppliers below minimum</label></header>
  <div class="dbody">${list.map(s=>{const bar=(have,min,lab)=>`<div class="prog"><i style="width:${Math.min(100,have/min*100)}%"></i></div><div class="small muted num">${lab}</div>`;
    return `<div class="sitem ${s.short>0?'short':''}"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>${s.name}</b>${s.none?'<span class="status idle">Nothing to order</span>':s.short>0?'<span class="status warn">Below minimum</span>':'<span class="status ok">✓ Meets minimum</span>'}</div>
    <div class="small" style="margin:4px 0 6px">Needs ${supRule(s)}${s.both?(s.logic==='either'?' (either one)':' (both)'):''}</div>
    ${s.minU!=null?bar(s.tot,s.minU,`${fmt(s.tot)} of ${fmt(s.minU)} units`):''}
    ${s.minV!=null?bar(s.val,s.minV,`${money(s.val)} of ${money(s.minV)}${s.partial?` · excludes ${s.miss} units with no cost`:''}`):''}
    ${s.short>0?`<p class="small" style="margin-top:6px">${topUp(s.name)||'Add to the order or confirm a smaller order is accepted.'}</p>`:''}
    <div class="btns" style="margin-top:8px"><button class="btn sm" onclick="showSup('${s.name}')">Show entries</button>${me().owner?`<button class="lnk" aria-expanded="${S.supEdit===s.name}" onclick="supEditToggle('${s.name}')">${S.supEdit===s.name?'Done':'Edit minimum'}</button>`:''}</div>
    ${S.supEdit===s.name?`<div class="supedit"><div class="fld"><label for="su-${s.name}">Minimum units</label><input id="su-${s.name}" type="number" min="0" placeholder="None" value="${SUP[s.name].minU??''}" onchange="setSupMin('${s.name}','minU',this.value)"></div><div class="fld"><label for="sv-${s.name}">Minimum order value ($)</label><input id="sv-${s.name}" type="number" min="0" placeholder="None" value="${SUP[s.name].minV??''}" onchange="setSupMin('${s.name}','minV',this.value)"></div><div class="fld full"><label for="sl-${s.name}">When both are set, the order must meet</label><select id="sl-${s.name}" ${s.both?'':'disabled'} onchange="setSupMin('${s.name}','logic',this.value)"><option value="both" ${SUP[s.name].logic==='both'?'selected':''}>Both</option><option value="either" ${SUP[s.name].logic==='either'?'selected':''}>Either one</option></select></div></div>`:''}</div>`}).join('')||'<div class="empty">No suppliers match.</div>'}</div>
  <footer class="small muted">Minimums are checked per supplier across all stores. Order value uses unit cost from your supplier rules file.</footer></aside>`;
}

/* approvals */
function apprStatus(k){const a=S.appr[k];
  if(a.state==='approved')return `<span class="status ok">✓ Approved</span><div class="small muted">${esc(a.by)} · ${a.at}</div>`;
  if(a.state==='changes')return `<span class="status bad">Changes requested</span><div class="small muted">${esc(a.by)} · ${a.at}</div>`;
  const rs=remindState(k);let extra='';
  if(rs){if(rs.off)extra='Waiting '+rs.waiting+'h · reminders off';else if(rs.count>0)extra='Waiting '+rs.waiting+'h · '+rs.count+(rs.count===1?' reminder':' reminders')+' sent'+(rs.nextIn?', next in '+rs.nextIn+'h':'');else extra='Waiting '+rs.waiting+'h · reminder in '+rs.nextIn+'h'}
  return `<span class="status ${rs&&rs.count>0?'warn':'idle'}">${rs&&rs.count>0?'Overdue':'Pending'}</span>`+(extra?`<div class="small muted">${extra}</div>`:'')}
const nudgeBtn=k=>{if(!me().owner||k==='owner'||S.appr[k].state!=='pending')return '';const l=S.nudgeAt[k];return (l!==undefined&&S.clock-l<1)?'<div class="small muted">Reminded just now</div>':`<div><button class="lnk" style="padding-left:0" onclick="remindNow('${k}')">Remind now</button></div>`};
function apprAct(k){
  const owner=k==='owner';const can=owner?(!!me().owner&&allStoresDone()):canStore(k);const a=S.appr[k];
  if(can)return `<div class="btns"><button class="btn sm primary" onclick="approve('${k}','approved')" ${a.state==='approved'?'disabled':''}>Approve</button><button class="btn sm danger" onclick="approve('${k}','changes')" ${a.state==='changes'?'disabled':''}>Request changes</button></div>`;
  if(owner)return `<span class="small muted">${allStoresDone()?'Only the business owner can sign off':'Unlocks after every store approves'}</span>`;
  return '<span class="small muted">Only the approvers listed</span>'}
function approve(k,state){
  const owner=k==='owner';if(owner?!(me().owner&&allStoresDone()):!canStore(k))return;
  S.appr[k]={state,by:me().name,at:nowStr()};
  if(!owner&&state==='approved'&&allStoresDone()){S.since.owner=S.clock;S.remSent.owner=0}
  S.log.unshift(nowStr()+' · '+me().name+(state==='approved'?' approved ':' requested changes for ')+(owner?'the final sign-off':k));
  render();toast(state==='approved'?'Approved by '+me().name:'Changes requested')}
function resetFor(st){
  const had=S.appr[st].state!=='pending',ow=S.appr.owner.state!=='pending';
  if(had||ow){S.appr[st]={state:'pending',by:null,at:null};S.appr.owner={state:'pending',by:null,at:null};S.since[st]=S.clock;S.since.owner=S.clock;S.remSent[st]=0;S.remSent.owner=0;S.escalated[st]=false;S.log.unshift(nowStr()+' · '+me().name+' edited '+st+'. Its approval and the final sign-off were reset');toast('Edited '+st+'. Its approval and the final sign-off were reset.')}
}
function switchUser(id){S.user=id;const m=me();S.rv.filter=(m.owner||!m.stores.length)?'all':'mine';render();toast('Now acting as '+m.name)}
function skipAhead(){const t=nowStr();STORES.forEach(s=>{S.appr[s]={state:'approved',by:PEOPLE.find(p=>p.id===MGR[s]).name,at:t}});S.appr.owner={state:'approved',by:'Alex Rivera',at:t};S.log.unshift(t+' · All approvals completed (prototype shortcut)');render()}
function apprHTML(){
  const rows=STORES.map(st=>`<tr><td><b>${st}</b></td><td>${approvers(st).map(p=>esc(p.name)+' <span class="muted small">('+(MGR[st]===p.id?'manager':'delegate')+')</span>').join('<br>')}</td><td class="num">${unitsFor(st)} units</td><td>${apprStatus(st)}</td><td>${apprAct(st)}${nudgeBtn(st)}</td></tr>`).join('');
  return `<section class="card" id="approvals">
    <div class="card-head"><div><h2>Approvals · ${doneCount()} of ${STORES.length+1} complete</h2><p>Each store is approved by its own manager or a named delegate. The business owner signs off last. Editing a store’s quantities resets that store and the final sign-off.</p></div>
    <div class="actas"><label for="va">Acting as (prototype)</label><select id="va" onchange="switchUser(this.value)">${PEOPLE.map(p=>`<option value="${p.id}" ${S.user===p.id?'selected':''}>${p.name} · ${p.role}</option>`).join('')}</select></div></div>
    <div class="tablewrap"><table class="apptable"><thead><tr><th>Approval</th><th>Who can approve</th><th>Order</th><th>Status</th><th></th></tr></thead><tbody>
    ${rows}
    <tr><td><b>Final sign-off</b></td><td>${PEOPLE.filter(p=>p.owner).map(p=>esc(p.name)+' <span class="muted small">(owner)</span>').join('<br>')}</td><td class="num">${fmt(totalUnits())} units</td><td>${apprStatus('owner')}</td><td>${apprAct('owner')}</td></tr></tbody></table></div>
    ${toReview()&&!allApproved()?`<p class="small muted" style="margin-top:16px">${toReview()} flagged ${toReview()===1?'entry hasn’t':'entries haven’t'} been reviewed yet. Approvers can still approve.</p>`:''}
    ${remHTML()}
    <details style="margin-top:16px"><summary>Activity (${S.log.length})</summary><div class="small muted" style="margin-top:8px">${S.log.slice(0,6).map(l=>`<div>${esc(l)}</div>`).join('')||'No activity yet.'}</div></details>
    <p class="proto">Prototype clock: <b>${S.clock}h</b> since sent for approval · <button class="lnk" onclick="tick(6)">+6 hours</button><button class="lnk" onclick="tick(24)">+1 day</button><button class="lnk" onclick="resetClock()">Reset</button> · <a href="#" onclick="skipAhead();return false">Complete all approvals</a></p>
  </section>`;
}

/* reminders and notifications */
const afterH=()=>S.rem.n*(S.rem.unit==='days'?24:1);
const targets=k=>k==='owner'?PEOPLE.filter(p=>p.owner):approvers(k);
const remOff=()=>!S.rem.on||(!S.rem.push&&!S.rem.email);
function notify(to,text,kind){S.notifs.unshift({id:++uid,to:to.map(p=>p.id),text,kind,read:false,at:nowStr()})}
function remindState(k){
  const a=S.appr[k];if(a.state!=='pending')return null;
  if(k==='owner'&&!allStoresDone())return null;
  const waiting=S.clock-S.since[k];if(remOff())return{waiting,off:true};
  const af=afterH();if(waiting<af)return{waiting,count:0,nextIn:af-waiting};
  const rp=S.rem.repeat;const count=rp?Math.floor((waiting-af)/rp)+1:1;
  return{waiting,count,nextIn:rp?rp-((waiting-af)%rp):null}
}
const chanTxt=()=>[S.rem.push&&'Push',S.rem.email&&'email'].filter(Boolean).join(' and ');
function processReminders(){
  let people=0;
  [...STORES,'owner'].forEach(k=>{
    const rs=remindState(k);if(!rs||rs.off)return;
    const sent=S.remSent[k]||0;const t=targets(k);const label=k==='owner'?'final sign-off':k+' order list';
    if(rs.count>sent){
      notify(t,`Reminder: the ${label} is waiting for your approval (${rs.waiting}h).`,'reminder');
      S.remSent[k]=rs.count;people+=t.length;
      S.log.unshift(`${nowStr()} · ${chanTxt()} reminder to ${t.map(p=>p.name).join(', ')} (${label}, ${rs.waiting}h waiting)`);
    }
    if(S.rem.escalate&&k!=='owner'&&rs.count>=2&&!S.escalated[k]){
      const o=PEOPLE.filter(p=>p.owner);
      notify(o,`${k} approval is overdue (${rs.waiting}h). ${t.map(p=>p.name).join(' and ')} haven't responded after ${rs.count} reminders.`,'escalation');
      S.escalated[k]=true;people+=o.length;
      S.log.unshift(`${nowStr()} · Escalated ${k} to ${o.map(p=>p.name).join(', ')}`)
    }
  });
  return people}
function tick(h){S.clock+=h;const n=processReminders()+processStockAlerts();render();toast(n?`Reminders sent to ${n} ${n===1?'person':'people'}`:`Clock +${h}h. No reminders due.`)}
function resetClock(){S.clock=0;Object.keys(S.since).forEach(k=>S.since[k]=0);S.remSent={};S.escalated={};S.nudgeAt={};S.notifs=[];S.stockSeen=new Set();processStockAlerts(true);render()}
function remindNow(k){if(!me().owner||S.appr[k].state!=='pending')return;const t=targets(k);notify(t,`${me().name} asked you to review the ${k} order list.`,'nudge');S.nudgeAt[k]=S.clock;S.log.unshift(`${nowStr()} · ${me().name} sent a reminder to ${t.map(p=>p.name).join(', ')} (${k})`);render();toast('Reminder sent to '+t.map(p=>p.name.split(' ')[0]).join(' and '))}
function setRem(key,val){
  if(!me().owner)return;
  if(key==='n')val=Math.min(99,Math.max(1,parseInt(val)||1));
  if(key==='repeat')val=parseInt(val);
  S.rem[key]=val;processReminders();render()}
function remSummary(){
  if(remOff())return 'Reminders are off. Approvers are only notified when you use “Remind now”.';
  return `Approvers get a ${chanTxt().toLowerCase()} reminder after ${S.rem.n} ${S.rem.unit}${S.rem.repeat?`, then every ${S.rem.repeat} hours until they respond`:' (once)'}.`+(S.rem.escalate?(S.rem.repeat?' If a store is still pending after 2 reminders, the business owner is notified.':' Escalation needs a repeat interval.'):'')}
function remHTML(){
  const own=!!me().owner;const d=own?'':'disabled';
  return `<details class="remcfg" ${S.remOpen?'open':''} ontoggle="S.remOpen=this.open"><summary><b>Reminders</b><span>${remOff()?'Off':'On · after '+S.rem.n+' '+S.rem.unit}</span></summary>
    <div class="remgrid">
      <label class="check"><input type="checkbox" ${S.rem.on?'checked':''} ${d} onchange="setRem('on',this.checked)"><span>Remind approvers who haven’t responded<br><span class="small muted">Applies to each store and to the final sign-off.</span></span></label>
      <div class="fld"><label for="rm-n">Remind after</label><div style="display:flex;gap:8px"><input id="rm-n" type="number" min="1" max="99" value="${S.rem.n}" ${d} onchange="setRem('n',this.value)"><select id="rm-u" aria-label="Unit" ${d} onchange="setRem('unit',this.value)"><option ${S.rem.unit==='hours'?'selected':''}>hours</option><option ${S.rem.unit==='days'?'selected':''}>days</option></select></div></div>
      <div class="fld"><label for="rm-r">Then repeat</label><select id="rm-r" ${d} onchange="setRem('repeat',this.value)">${[[0,'Don’t repeat'],[12,'Every 12 hours'],[24,'Every 24 hours'],[48,'Every 48 hours']].map(([v,t])=>`<option value="${v}" ${S.rem.repeat===v?'selected':''}>${t}</option>`).join('')}</select></div>
      <div class="fld"><label>Send by</label><label class="check"><input type="checkbox" ${S.rem.push?'checked':''} ${d} onchange="setRem('push',this.checked)">Push notification</label><label class="check"><input type="checkbox" ${S.rem.email?'checked':''} ${d} onchange="setRem('email',this.checked)">Email</label></div>
      <label class="check" style="grid-column:1/-1"><input type="checkbox" ${S.rem.escalate?'checked':''} ${d} onchange="setRem('escalate',this.checked)"><span>Tell the business owner if a store is still pending after 2 reminders</span></label>
    </div>
    <p class="small" style="margin-top:12px">${remSummary()}</p>
    <p class="small muted" style="margin-top:4px">Reminders go to the approvers listed for each store. People without push enabled on their device get an email instead.${own?'':' Only the business owner can change these settings.'}</p></details>`;
}
const myNotifs=()=>S.notifs.filter(n=>n.to.includes(S.user));
function updateBell(){
  const list=myNotifs();const un=list.filter(n=>!n.read).length;const bd=$('#bell-badge');bd.hidden=!un;bd.textContent=un;
  $('#bell-menu').innerHTML=`<div class="who" style="display:flex;justify-content:space-between;align-items:center"><b>Notifications</b>${un?'<button class="lnk" onclick="markAllRead()">Mark all read</button>':''}</div>`+(list.length?list.slice(0,8).map(n=>`<a href="#" role="menuitem" class="nitem ${n.read?'':'unread'}" onclick="openNotif(${n.id});return false"><span class="ndot" aria-hidden="true"></span><span><span class="small muted">${n.kind==='escalation'?'Overdue':n.kind==='nudge'?'Request':n.kind==='stock'?'Stock alert':n.kind==='models'?'Results ready':'Reminder'} · ${n.at}</span><br>${esc(n.text)}</span></a>`).join(''):'<div class="small muted" style="padding:16px">No notifications.</div>')}
function toggleBell(force){const m=$('#bell-menu'),b=$('#bell-btn');const open=force!==undefined?force:m.hidden;if(m.hidden===!open)return;m.hidden=!open;b.setAttribute('aria-expanded',open);if(open)toggleMenu(false)}
function markAllRead(){myNotifs().forEach(n=>n.read=true);updateBell()}
function openNotif(id){const n=S.notifs.find(x=>x.id===id);if(n)n.read=true;toggleBell(false);const st=n&&n.kind==='stock';const md=n&&n.kind==='models';S.step=md?3:st?4:5;if(st){S.tab='summary';S.fold.stock=true}render();const a=$(st?'#stock-alerts':'#approvals');if(a)a.scrollIntoView({behavior:'smooth'})}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('#bell-menu').hidden){toggleBell(false);$('#bell-btn').focus()}});

/* delivery */
const selR=e=>S.recip.has(e)||S.always.has(e);
const recipients=()=>DIR().filter(d=>!d.locked&&selR(d.email));
const scopeOf=e=>{const p=PEOPLE.find(x=>x.email===e);return S.scope&&p&&p.stores.length&&!p.owner?p.stores.join(', '):'All stores'};
const QGROUPS=[['owner','Business owner'],['mgr','Store managers'],['del','Delegates'],['viewer','Viewers'],['ext','External contacts']];
function groupEmails(g){
  if(g==='owner')return PEOPLE.filter(p=>p.owner).map(p=>p.email);
  if(g==='mgr')return PEOPLE.filter(p=>p.role==='Store manager').map(p=>p.email);
  if(g==='del')return PEOPLE.filter(p=>p.role==='Delegate').map(p=>p.email);
  if(g==='viewer')return PEOPLE.filter(p=>/Viewer/.test(p.role)).map(p=>p.email);
  return EXTERNAL.map(e=>e.email)}
const groupOn=g=>{const em=groupEmails(g);return em.length>0&&em.every(selR)};
const allEmails=()=>DIR().filter(d=>!d.locked).map(d=>d.email);
function toggleRecip(e){if(!canExport()||S.always.has(e))return;if(S.recip.has(e))S.recip.delete(e);else S.recip.add(e);render()}
function quick(g){
  if(!canExport())return;
  if(g==='none')S.recip.clear();
  else{const em=g==='all'?allEmails():groupEmails(g);const on=em.every(selR);em.forEach(e=>on?S.recip.delete(e):S.recip.add(e))}
  render()}
function quickStore(st){if(!canExport()||!st)return;const ap=approvers(st);ap.forEach(p=>S.recip.add(p.email));render();toast('Added the '+st+' team ('+ap.length+')')}
function alwaysToggle(e){
  if(!me().owner)return;const d=DIR().find(x=>x.email===e);
  if(S.always.has(e)){S.always.delete(e);S.recip.add(e);S.log.unshift(nowStr()+' · '+me().name+' stopped always sending reports to '+d.name)}
  else{S.always.add(e);S.log.unshift(nowStr()+' · '+me().name+' set reports to always go to '+d.name)}
  render()}
function addRecip(){
  const v=($('#ar').value||'').trim().toLowerCase();S.arVal=v;
  const d=DIR().find(x=>x.email===v);
  if(!/^\S+@\S+\.\S+$/.test(v))S.recMsg={t:'err',x:'Enter a full email address.'};
  else if(d&&d.locked)S.recMsg={t:'err',x:'Already requested. An admin still needs to approve it.'};
  else if(d){S.recip.add(d.email);S.recMsg={t:'ok',x:d.name+' added.'};S.arVal=''}
  else if(v.endsWith('@'+ORG))S.recMsg={t:'err',x:'This person isn’t in your workspace yet. Ask an admin to invite them under Team and permissions.'};
  else S.recMsg={t:'ext',x:'External addresses can’t receive reports until an admin approves them.',e:v};
  render()}
function requestApproval(e){S.pending.push(e);S.recMsg={t:'ok',x:'Request sent to your workspace admins.'};S.arVal='';render()}
function openSend(){if(!(allApproved()&&canExport())||!recipients().length)return;S.confirmSend=true;render();setTimeout(()=>{const b=$('#sendgo');if(b)b.focus()},0)}
function closeSend(){S.confirmSend=false;render();const b=$('#sendbtn');if(b)b.focus()}
function confirmHTML(){
  if(!S.confirmSend)return '';
  const rs=recipients();const scoped=S.scope&&rs.some(d=>scopeOf(d.email)!=='All stores');
  return `<div class="scrim" onclick="closeSend()"></div><div class="modal" role="dialog" aria-modal="true" aria-labelledby="cft"><h2 id="cft">Send this report?</h2>
   <p class="muted" style="margin-top:8px">weekly_restocking_recommendations.csv and a one-page summary will be emailed to <b>${rs.length} ${rs.length===1?'person':'people'}</b>.</p>
   <p class="small" style="margin-top:12px">${rs.slice(0,5).map(d=>esc(d.name)).join(', ')}${rs.length>5?' and '+(rs.length-5)+' more':''}</p>
   ${scoped?'<p class="small muted" style="margin-top:8px">Store managers and delegates will only see their own stores’ lines.</p>':''}
   ${rs.some(d=>S.always.has(d.email))?'<p class="small muted" style="margin-top:8px">Includes people set to always receive reports.</p>':''}
   <div class="btns" style="justify-content:flex-end;margin-top:24px"><button class="btn" onclick="closeSend()">Cancel</button><button class="btn primary" id="sendgo" onclick="doSend()">Send report</button></div></div>`}
function doSend(){
  const rs=recipients();if(!rs.length||!(allApproved()&&canExport()))return;
  const send={id:++uid,at:stamp(),by:me().name,status:'sending',recipients:rs.map(d=>({name:d.name,email:d.email,scope:scopeOf(d.email),always:S.always.has(d.email),status:'queued'}))};
  S.sends.unshift(send);S.sendOpen[send.id]=true;S.confirmSend=false;
  S.log.unshift(nowStr()+' · '+me().name+' emailed the report to '+rs.length+(rs.length===1?' person':' people'));
  render();setTimeout(()=>{const h=$('#history');if(h)h.scrollIntoView({behavior:'smooth',block:'center'})},50);
  send.recipients.forEach((r,i)=>setTimeout(()=>{r.status='sent';if(i===send.recipients.length-1){send.status='sent';toast('Report sent to '+send.recipients.length+(send.recipients.length===1?' person':' people'))}if(S.step===5)render()},500+i*250))
}
function toggleQs(){if(!canExport())return;S.qsOpen=!S.qsOpen;render()}
function qsMenu(){
  const mark=on=>`<span class="ck" aria-hidden="true">${on?'✓':''}</span>`;
  const allOn=allEmails().every(selR);
  return `<div class="menu qsmenu" role="menu"><button class="mi" role="menuitem" onclick="quick('all')">${mark(allOn)}Everyone</button>
   ${QGROUPS.map(([k,l])=>`<button class="mi" role="menuitem" onclick="quick('${k}')">${mark(groupOn(k))}${l}</button>`).join('')}<hr>
   ${STORES.map(s=>`<button class="mi" role="menuitem" onclick="quickStore('${s}')">${mark(false)}Add ${s} team</button>`).join('')}<hr>
   <button class="mi" role="menuitem" onclick="quick('none')">${mark(false)}Clear selection</button></div>`}
function showHistory(){const h=$('#history');if(h)h.scrollIntoView({behavior:'smooth',block:'center'})}
function historyHTML(){
  if(!S.sends.length)return '';
  return `<div class="card" id="history" style="margin:24px 0 0"><div class="card-head"><div><h3>Delivery history</h3><p>“Sent” means the email was handed to the mail server. Whether it arrives depends on each recipient’s inbox.</p></div></div>
   <div class="tablewrap"><table><thead><tr><th>When</th><th>Sent by</th><th class="r">People</th><th>Status</th><th></th></tr></thead><tbody>
   ${S.sends.map(s=>{const done=s.recipients.filter(r=>r.status==='sent').length;const open=!!S.sendOpen[s.id];
    return `<tr><td>${esc(s.at)}</td><td>${esc(s.by)}</td><td class="r num">${s.recipients.length}</td><td>${s.status==='sent'?'<span class="status ok">✓ Sent</span>':`<span class="status teal"><span class="spin" style="width:12px;height:12px;border-width:2px" aria-hidden="true"></span>Sending ${done} of ${s.recipients.length}</span>`}</td><td class="r"><button class="notebtn" aria-expanded="${open}" onclick="S.sendOpen[${s.id}]=${!open};render()">${open?'Hide':'Details'}</button></td></tr>
    ${open?`<tr class="pdet"><td colspan="5"><table class="matrix"><thead><tr><th>Recipient</th><th>Receives</th><th>Status</th></tr></thead><tbody>${s.recipients.map(r=>`<tr><td><b>${esc(r.name)}</b>${r.always?' <span class="chip seas">Always</span>':''}<div class="small muted">${esc(r.email)}</div></td><td class="small">${esc(r.scope)}</td><td>${r.status==='sent'?'<span class="status ok">✓ Sent</span>':'<span class="status idle">Queued</span>'}</td></tr>`).join('')}</tbody></table></td></tr>`:''}`}).join('')}</tbody></table></div></div>`
}
function dlCSV(){
  let c='store,product,supplier,unit_cost,line_cost,pack_size,on_hand,incoming,last_restock_qty,suggested_qty,usual_method_qty,order_qty,edited_by,reviewed,note\n';
  exportIdx().forEach(i=>{const r=S.rows[i],p=PROD[r.p];c+=[STORES[r.s],'"'+p.n.replace(/"/g,'""')+'"',p.sup,(unitCost(r.p)===null?'':unitCost(r.p)),(lineCost(r)===null?'':lineCost(r)),p.pack,r.onHand,r.inc,r.last,r.sug,(pbUsesAvg()?baseQty(r):''),r.qty,r.qty!==r.sug?(r.editor||''):'',issues(r).length?(r.reviewed?'yes':'no'):'n/a','"'+(S.notes[i]||'').replace(/"/g,'""')+'"'].join(',')+'\n'});
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([c],{type:'text/csv'}));a.download='weekly_restocking_recommendations.csv';a.click();toast('Downloaded')
}
function saveSched(){S.sched.saved=true;render();toast('Recurring report saved')}
function deliveryHTML(){
  const m=me();const own=!!m.owner;const ok=canExport();const open=allApproved()&&ok;const rs=recipients();const n=rs.length;
  const ex=exportIdx();const scopeTxt=m.owner?'all stores':'your stores ('+m.stores.join(', ')+')';
  const dis=open?'':'disabled';const cx=ok?'':'disabled';
  const q=S.rq.trim().toLowerCase();
  const dir=DIR().filter(d=>!q||(d.name+' '+d.email+' '+d.desc).toLowerCase().includes(q));
  const alw=DIR().filter(d=>S.always.has(d.email));
  const last=S.sends[0];
  const alwaysRows=dir.filter(d=>S.always.has(d.email)),otherRows=dir.filter(d=>!S.always.has(d.email));
  const rowR=d=>{const al=S.always.has(d.email);const idn='rc-'+slug(d.email);
    return `<div class="rcp ${d.locked?'locked':''}"><input id="${idn}" type="checkbox" ${selR(d.email)?'checked':''} ${d.locked||!ok||al?'disabled':''} ${al?'title="Always included"':''} onchange="toggleRecip('${d.email}')"><label for="${idn}">${esc(d.name)}<small>${esc(d.desc)} · ${esc(d.email)}</small></label><span class="rcpr"><span class="status ${d.tag==='Workspace'?'idle':d.tag==='Pending'?'warn':'teal'}">${d.tag}</span>${d.locked?'':own?`<button class="pin" aria-pressed="${al}" aria-label="Always send to ${esc(d.name)}" onclick="alwaysToggle('${d.email}')">${al?'✓ Always':'Always'}</button>`:al?'<span class="chip seas">Always</span>':''}</span></div>`};
  return `<section aria-labelledby="dl"><div class="card-head"><div><h2 id="dl">Delivery</h2><p>${!allApproved()?'Delivery unlocks when every store and the business owner have approved.':!ok?`Your role (${m.role}) can’t export or share this report. Ask the business owner.`:'Approved. Choose who receives the order list and how.'}</p></div>${open?'<span class="status ok">✓ Export enabled</span>':'<span class="status idle">Locked</span>'}</div>
  <div class="card"><div class="card-head" style="margin-bottom:12px"><div><h3>Who receives this report</h3><p>Only people in your workspace and approved external contacts.</p></div><span class="status teal">${n} will receive it</span></div>
   <div class="toolbar" style="margin-bottom:12px"><div class="fld grow"><label for="rq" class="sr">Search people</label><input id="rq" type="search" placeholder="Search people" value="${esc(S.rq)}" oninput="S.rq=this.value;render()"></div>
    <div class="menuwrap"><button class="btn" id="qsb" aria-haspopup="true" aria-expanded="${S.qsOpen}" ${cx} onclick="toggleQs()">Quick select ▾</button>${S.qsOpen?qsMenu():''}</div></div>
   <div class="rcp-list" role="group" aria-label="Recipients">${alwaysRows.length?`<div class="rgroup">Always send (${alwaysRows.length})</div>`+alwaysRows.map(rowR).join(''):''}${otherRows.length?`<div class="rgroup">${alwaysRows.length?'Everyone else':'People'}</div>`+otherRows.map(rowR).join(''):''}${dir.length?'':'<div class="empty" style="border:0">No one matches.</div>'}</div>
   <p class="small muted" style="margin-top:8px">People marked Always get every report, including scheduled ones. ${own?'Use Always on a row to change it.':'Only the business owner can change this.'}</p>
   <details style="margin-top:12px" ${S.recMsg||S.arVal?'open':''}><summary>Add someone outside this list</summary><div class="fld" style="margin-top:8px"><label for="ar" class="sr">Email address</label><div style="display:flex;gap:8px"><input id="ar" type="email" placeholder="name@${ORG}" value="${esc(S.arVal)}" oninput="S.arVal=this.value" ${cx}><button class="btn" onclick="addRecip()" ${cx}>Add</button></div>
    ${S.recMsg?`<div class="msg ${S.recMsg.t==='ok'?'ok':'err'}">${S.recMsg.x}${S.recMsg.t==='ext'?` <button class="lnk" onclick="requestApproval('${esc(S.recMsg.e)}')">Request admin approval</button>`:''}</div>`:''}</div></details>
   <label class="check" style="margin-top:16px"><input type="checkbox" ${S.scope?'checked':''} onchange="S.scope=this.checked;render()"><span>Store managers and delegates receive only their own stores’ lines<br><span class="small muted">Recommended. The business owner and finance receive every store.</span></span></label></div>
  <div class="deliver">
    <div class="card ${open?'':'locked'}"><h3>Download CSV</h3><p class="muted small">weekly_restocking_recommendations.csv<br>${ex.length} rows · ${fmt(ex.reduce((a,i)=>a+S.rows[i].qty,0))} units · ${scopeTxt}<br>Edits, editors and notes included</p>
      <button class="btn primary" style="margin-top:auto" onclick="dlCSV()" ${dis}>Download CSV ↓</button></div>
    <div class="card ${open?'':'locked'}"><h3>Email report</h3><p class="muted small">Sends the CSV and a one-page summary to the ${n} ${n===1?'person':'people'} above. You’ll confirm before it goes.</p>
      ${last?`<div class="sentline"><span class="status ${last.status==='sent'?'ok':'teal'}">${last.status==='sent'?'✓ Sent':'Sending…'}</span><span class="small muted">${last.recipients.length} ${last.recipients.length===1?'person':'people'} · ${esc(last.at)}</span><button class="lnk" onclick="showHistory()">View details</button></div>`:''}
      <button class="btn" id="sendbtn" style="margin-top:auto" onclick="openSend()" ${open&&n?'':'disabled'}>Send to ${n} ${n===1?'person':'people'}</button></div>
    <div class="card wide ${open?'':'locked'}"><div class="card-head" style="margin-bottom:0"><div><h3>Recurring report</h3><p>Send this order list automatically. Each run goes to the ${n} ${n===1?'person':'people'} above, including anyone set to always receive it.</p></div>${S.sched.saved?'<span class="status ok">✓ Scheduled</span>':''}</div>
      <div class="recgrid">
        <div class="fld"><label for="fq">Repeats</label><select id="fq" ${dis} onchange="S.sched.freq=this.value;render()"><option ${S.sched.freq==='Weekly'?'selected':''}>Weekly</option><option ${S.sched.freq==='Daily'?'selected':''}>Daily</option></select></div>
        <div class="fld"><label for="fd">On</label><select id="fd" ${open&&S.sched.freq==='Weekly'?'':'disabled'} onchange="S.sched.day=this.value">${S.sched.freq==='Daily'?'<option>Every day</option>':['Monday','Tuesday','Wednesday','Thursday','Friday'].map(d=>`<option ${S.sched.day===d?'selected':''}>${d}</option>`).join('')}</select></div>
        <div class="fld"><label for="ft">At</label><input id="ft" type="time" value="${S.sched.time}" ${dis} onchange="S.sched.time=this.value"></div>
      </div>
      <label class="check"><input type="checkbox" ${S.sched.needsApproval?'checked':''} ${dis} onchange="S.sched.needsApproval=this.checked"><span>Require every approval before each report is sent<br><span class="small muted">Recommended. Otherwise reports go out unreviewed.</span></span></label>
      <div class="recfoot"><span class="small ${S.sched.saved?'':'muted'}" ${S.sched.saved?'style="color:var(--green-ink)"':''}>${S.sched.saved?'✓ '+(S.sched.freq==='Daily'?'Every day':'Every '+S.sched.day)+' at '+S.sched.time:'Not scheduled yet'}</span>
      <button class="btn" onclick="saveSched()" ${open&&n?'':'disabled'}>${S.sched.saved?'Update schedule':'Set up recurring report'}</button></div></div>
  </div>${historyHTML()}</section>`;
}

function attnBar(){
  const sh=supShort();const c={act:sevCount('act'),review:sevCount('review'),watch:sevCount('watch')};
  if(!c.act&&!c.review&&!c.watch&&!sh.length)return '';
  const L={act:'Act now',review:'Review',watch:'Watch'};
  return `<div class="attn"><span class="small muted">Entries needing attention</span><div class="chips" role="group" aria-label="Priority">${['act','review','watch'].filter(k=>c[k]).map(k=>`<button class="sev ${k}" aria-pressed="${S.rv.filter==='sev-'+k}" onclick="setFilter('${S.rv.filter==='sev-'+k?'all':'sev-'+k}')"><i aria-hidden="true"></i>${L[k]}<span class="n num">${c[k]}</span></button>`).join('')}</div>${sh.length?`<button class="lnk" id="sup-open-btn" onclick="openSup()">View suppliers (${sh.length} below minimum)</button>`:''}</div>`}

function s5(){
  const idx=visible();
  const sel=(id,label,opts,val,fn)=>`<div class="fld"><label for="${id}">${label}</label><select id="${id}" onchange="${fn}">${opts.map(([v,t])=>`<option value="${v}" ${v===val?'selected':''}>${t}</option>`).join('')}</select></div>`;
  return `
  <div class="page-head"><h1>Review and edit your order list</h1><p>Find what needs a look, edit quantities, then get each store and the owner to approve.</p></div>
  ${pbStrip()}
  <section class="card" id="order-list">
    <div class="toolbar">
      <div class="fld grow"><label for="sq">Search</label><input id="sq" type="search" placeholder="Product, store or supplier" value="${esc(S.rv.q)}" oninput="S.rv.q=this.value;render()"></div>
      ${filterSelect()}
      ${sel('gb','Group by',[['store','Store'],['product','Product'],['category','Category'],['supplier','Supplier'],['attention','What needs attention'],['none','No grouping']],S.rv.group,"S.rv.group=this.value;render()")}
      ${sel('so','Sort by',Object.entries(SORTS).map(([k,v])=>[k,v[0]]),S.rv.sort,"S.rv.sort=this.value;render()")}
    </div>
    ${S.rv.sup?`<div class="activefilters"><span class="status teal">Supplier: ${S.rv.sup}<button aria-label="Clear supplier filter" onclick="S.rv.sup='';render()">✕</button></span></div>`:''}
    ${attnBar()}
    <div class="summary"><span>Showing <b class="num">${idx.length}</b> of <b class="num">${S.rows.length}</b> · <b class="num">${skuCount()}</b> SKUs · <b class="num">${fmt(totalUnits())}</b> units · <b class="num">${money(orderValue())}${orderMissing()?'+':''}</b> at cost · <b class="num">${edited()}</b> edited · <b class="num">${toReview()}</b> to review</span>
      <span class="tools"><label class="check small"><input type="checkbox" ${S.rv.hideZero?'checked':''} onchange="S.rv.hideZero=this.checked;render()">Hide zero orders</label>
      ${S.rv.group!=='none'?`<button class="lnk" onclick="setAllGroups(true)">Collapse all</button><button class="lnk" onclick="setAllGroups(false)">Expand all</button>`:''}
      <button class="lnk" onclick="markVisible()">Mark visible reviewed</button></span></div>
    ${listHTML()}
    <div class="fld" style="margin-top:24px"><label for="gn">Feedback for reviewers</label><textarea id="gn" placeholder="Anything the approvers should know?" oninput="S.general=this.value">${esc(S.general)}</textarea></div>
  </section>
  ${apprHTML()}
  ${deliveryHTML()}
  <div class="actions"><button class="btn ghost" onclick="go(4)">← Back to report</button></div>`;
}
function setQty(i,v){const r=S.rows[i];if(!canEdit(r))return;v=Math.max(0,parseInt(v)||0);if(v!==r.qty){r.qty=v;r.editor=me().name;resetFor(STORES[r.s])}render()}
function bump(i,d){setQty(i,S.rows[i].qty+d)}
function markRev(i){if(canEdit(S.rows[i])){S.rows[i].reviewed=true;render()}}

/* ---------- render ---------- */
function updateAcct(){const m=me();$('#acct-av').textContent=m.name.split(' ').map(x=>x[0]).join('');$('#acct-name').textContent=m.name;$('#acct-email').textContent=m.role+(m.stores.length?' · '+m.stores.join(', '):'')+' · '+m.email}
function render(){
  const mx=maxStep();
  const stepper=`<nav class="stepper" aria-label="Progress">${STEPS.map((l,i)=>{const n=i+1;const cls=n<S.step?'done':n===S.step?'now':'';return `<button class="${cls}" ${n>mx&&n!==S.step?'disabled':''} ${n===S.step?'aria-current="step"':''} onclick="go(${n})"><div class="bar"></div><div class="label">Step ${n} of 5 · ${l}${n===3&&S.modelState==='running'?' · running':''}</div></button>`}).join('')}</nav>`;
  const f=document.activeElement;const id=f&&f.id;const ss=f&&f.selectionStart;
  const sy=window.scrollY;
  $('#app').innerHTML=stepper+[null,s1,s2,s3,s4,s5][S.step]();
  $('#drawer-root').innerHTML=S.step===5?(drawerHTML()+confirmHTML()):'';
  if(S.step!==5){S.supOpen=false;S.confirmSend=false}
  const h=$('#nav-home');if(h)h.style.color=S.step===1?'var(--blue)':'';
  if(S.step===3)S.runPending=false;
  updateAcct();updateBell();updateRunBar();
  if(id){const e=document.getElementById(id);if(e){e.focus({preventScroll:true});if(ss!=null&&e.setSelectionRange){try{e.setSelectionRange(ss,ss)}catch(_){}}}}
  window.scrollTo({top:sy});
  if(S.step===4&&S.tab==='ideas'&&S.disc.auto&&!S.disc.ran&&S.disc.state==='idle'){S.disc.ran=true;setTimeout(()=>runDiscovery(true),0)}
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&S.confirmSend)closeSend();else if(e.key==='Escape'&&S.qsOpen){S.qsOpen=false;render()}else if(e.key==='Escape'&&S.supOpen)closeSup()});
document.addEventListener('click',e=>{if(S.qsOpen&&e.target.isConnected&&!e.target.closest('.menuwrap')){S.qsOpen=false;render()}});
processStockAlerts(true);render();
