/**
 * Suiro AI domain types, derived from the prototype's state object.
 * These are a starting point for the API contract, not a final schema.
 */

export type StoreCode = string;            // e.g. "LON-01"
export type Role = "owner" | "manager" | "delegate" | "viewer";
export type Severity = "act" | "review" | "watch";
export type ISODate = string;

/* ---------- people and permissions ---------- */
export interface Person {
  id: string;
  name: string;
  email: string;
  role: Role;
  roleLabel: string;                       // "Business owner", "Store manager", "Delegate", "Viewer (finance)"
  stores: StoreCode[];                     // stores this person can edit and approve. Empty for owner and viewer.
}
export interface StoreApprovers { store: StoreCode; managerId: string; delegateIds: string[] }
export interface ExternalContact { name: string; email: string; approved: boolean }

/* ---------- step 1 and 2: question, files, readiness ---------- */
export type FileRole = "Sales history" | "Stock on hand" | "Incoming shipments" | "Supplier rules" | "Other";
export interface DataFile {
  id: string; name: string; role: FileRole; rows: number; columns: number;
  dateRange?: { from: ISODate; to: ISODate } | "snapshot" | "current";
}
export interface Analysis {
  id: string; question: string; files: DataFile[]; createdBy: string;
  status: "draft" | "approved" | "running" | "models_ready" | "report_ready";
  staleSince?: ISODate;                    // set when files are added after the report was built
  decisionNote?: DecisionNote;
}
export interface Readiness {
  role: FileRole; state: "ok" | "warn" | "bad"; file?: string; detail: string; why: string;
}
export interface DecisionNote {
  methods: Array<"avg" | "lastyear" | "reorder" | "supplier" | "gut">;
  text: string;                            // max 300
  by: string; at: ISODate; forQuestion: string;
  history: Omit<DecisionNote, "history">[];
}

/* ---------- step 3: models ---------- */
export interface ModelResult {
  id: string; name: string; tag: string;
  accuracy: number;                        // 0-100, 100 - WAPE
  typicalErrorUnits: number;               // MAE
  shortagesCaught: number;                 // 0-100, recall
  unneededOrders: number;                  // 0-100, 1 - precision
  influence: Array<{ label: string; share: number; source: FileRole }>;
  plain: string; bestAt: string; watchOutFor: string;
}
export interface ModelRun {
  analysisId: string; state: "queued" | "running" | "done" | "failed";
  done: number; total: number; startedBy: string;
  notify: { push: boolean; email: boolean };
  results?: ModelResult[]; recommendedId?: string; selectedId?: string;
}

/* ---------- catalogue and order lines ---------- */
export interface Product {
  id: string; name: string; category: string; supplierId: string; packSize: number;
  retailPrice: number; unitCost: number | null; monthsOnSale: number; season?: string;
}
export interface Supplier {
  id: string; name: string; leadTimeDays: number;
  minUnits: number | null; minValue: number | null; logic: "both" | "either";
}
export interface OrderLine {
  id: string; analysisId: string; productId: string; store: StoreCode;
  onHand: number; incoming: number; weeklyPace: number; trendPct: number; coverWeeks: number;
  lastRestockQty: number; lastRestockDate: ISODate; daysSinceLastSale: number;
  expiryDate?: ISODate;
  suggestedQty: number; qty: number;       // qty = what the user chose
  reviewed: boolean; note?: string;
  editedBy?: string; editedAt?: ISODate;
  /** Computed by the server, never trusted from the client */
  flags: Array<{ severity: Severity; code: string; text: string }>;
  lineCost: number | null;
}

/* ---------- approvals and delivery ---------- */
export type ApprovalState = "pending" | "approved" | "changes";
export interface Approval {
  scope: StoreCode | "owner"; state: ApprovalState; by?: string; at?: ISODate; reason?: string;
  waitingSince: ISODate; remindersSent: number; escalated: boolean; lastNudgeAt?: ISODate;
}
export interface ReminderSettings {
  on: boolean; after: { n: number; unit: "hours" | "days" };
  repeatHours: 0 | 12 | 24 | 48; push: boolean; email: boolean; escalateToOwnerAfter2: boolean;
}
export interface Recipient {
  email: string; name: string; kind: "workspace" | "external" | "pending"; always: boolean; selected: boolean;
}
export interface DeliverySettings { scopeToOwnStores: boolean; recipients: Recipient[] }
export interface DeliveryRecord {
  id: string; analysisId: string; sentBy: string; at: ISODate; file: string;
  recipients: Array<{ email: string; name: string; scope: "all" | StoreCode[]; always: boolean; status: "queued" | "sent" | "failed" }>;
  status: "sending" | "sent" | "partly_failed";
}
export interface Schedule {
  frequency: "daily" | "weekly"; day?: "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday";
  time: string; requireApproval: boolean; active: boolean;
}

/* ---------- alerts ---------- */
export type StockKind = "std" | "long" | "perish" | "tech";
export interface CategoryRule { category: string; kind: StockKind; limit: number; frequency: "daily" | "weekly" | "monthly" | "quarterly"; nextCheck: ISODate }
export interface AlertSettings { push: boolean; email: boolean; flagHighCover: boolean; highCoverWeeks: number; categories: CategoryRule[] }
export interface Notification {
  id: string; to: string[]; kind: "reminder" | "escalation" | "nudge" | "stock" | "models";
  text: string; at: ISODate; read: boolean; target: string;   // deep link
}
export interface ReportAlert {
  group: "act" | "review" | "watch" | "ahead"; tone: "info" | "warn" | "bad";
  title: string; detail: string; action: { label: string; target: string };
}

/* ---------- ideas (web search) ---------- */
export interface Guideline { key: string; strictness: "nice" | "must" }
export interface Opportunity {
  id: string; brand: string; product: string; category: string; priceUsd: number | null;
  momentum: "Rising" | "Steady" | "Early"; reason: string; basedIn: string | null;
  valuesStated: string[];                  // only keys that a cited source explicitly states
  evidence: Array<{ type: "article" | "review" | "social" | "marketplace"; title: string; publisher: string; url: string; date?: string }>;
  risks: string[];
  // computed server side:
  confidence: "Low" | "Medium" | "High"; fit: { stocked: boolean; priceFit: "fit" | "above" | "below" | "unknown" | "new"; overlap: string[]; categoryGrowthPct: number | null };
  guidelineMatch: Array<{ key: string; strictness: "nice" | "must"; status: "matched" | "unverified" | "no" | "unknown" }>;
}
