# 5. Data model and API

Types are in `docs/types.d.ts`. Everything in this document is a **proposal** to react to. The prototype has no server, so no contract exists yet.

## Entities

| Entity | Purpose | Key fields |
| --- | --- | --- |
| Workspace | Tenant. Owns people, stores, suppliers, products | name, email domain, settings |
| Person | A member with a role and store access | name, email, role, stores |
| Store | A location | code (LON-01), city, region, opened date |
| Supplier | Source of products | name, lead time, minimum units, minimum value, both or either |
| Product | Catalogue item | name, category, supplier, pack size, retail price, unit cost, months on sale |
| DataFile | An uploaded file with a content type | name, role, rows, columns, date range |
| Analysis | One run of the flow for a question | question, files, status, decision note, stale marker |
| ModelRun | The model comparison for an analysis | state, progress, results, recommended, selected, started by, notify prefs |
| OrderLine | One product in one store for one analysis | on hand, incoming, pace, trend, cover, last restock, suggested, quantity, reviewed, note, editor |
| Approval | One per store plus the owner sign-off | state, by, at, reminders sent, escalated |
| Delivery | One email send | sender, time, recipients with scope and status |
| Schedule | A recurring report | frequency, day, time, require approval |
| AlertRule | One per category | stock type, limit, frequency, next check |
| Notification | Something for a person to see | kind, text, read, deep link |
| Opportunity | A search result | brand, product, evidence, guideline match |
| ActivityEntry | Audit trail | who, what, when, target |

### Derived fields (compute on the server)

`coverWeeks`, `suggestedQty`, `flags` and priority, `lineCost`, supplier `units` and `value` and meets-minimum, approvals status, `watch` days, perishable at-risk units, chart series by period, KPIs, alert groups, opportunity `confidence` and guideline `status`. Formulas are in `docs/04-business-rules.md`. Do not trust any of these from the client.

## Proposed endpoints

REST and JSON. Authenticate every request. Authorise every request against the person's role and stores.

| Method and path | What it does |
| --- | --- |
| `POST /analyses` | Create from a question. Body: question |
| `PUT /analyses/{id}/question` | Edit the question. Marks the decision note as "written for a different question" if it differs |
| `POST /analyses/{id}/files` | Add a file (multipart). Returns rows, columns, detected content type |
| `PATCH /analyses/{id}/files/{fileId}` | Change content type |
| `DELETE /analyses/{id}/files/{fileId}` | Remove a file |
| `GET /analyses/{id}/readiness` | Readiness table |
| `PUT /analyses/{id}/decision-note` | Owner only. Saves a version |
| `POST /analyses/{id}/approve-task` | Starts the model run |
| `GET /analyses/{id}/model-run` | Progress and results. Also pushed as events |
| `PUT /analyses/{id}/model-run/selection` | Choose a model |
| `POST /analyses/{id}/report` | Build the report for the selected model |
| `GET /analyses/{id}/report/summary` | KPIs and grouped alerts |
| `GET /analyses/{id}/report/{tab}` | Data, customers, products, trends |
| `GET /analyses/{id}/order-lines` | Query: `store`, `product`, `category`, `supplier`, `filter`, `priority`, `q`, `sort`, `group`, `hideZero`, `cursor`, `limit` |
| `PATCH /order-lines/{id}` | Body: quantity, note, reviewed. Server records editor and resets the store's approval and the sign-off |
| `POST /order-lines:bulk-review` | Mark many reviewed (same permission checks) |
| `GET /analyses/{id}/suppliers/minimums` | Totals and status per supplier |
| `PATCH /suppliers/{id}/minimums` | Owner only |
| `GET /analyses/{id}/approvals` | Status, approvers, waiting time |
| `POST /analyses/{id}/approvals/{scope}` | Body: decision (approved or changes). `scope` is a store code or `owner` |
| `POST /analyses/{id}/approvals/{store}/nudge` | Owner only. Rate-limited |
| `PUT /workspace/reminder-settings` | Owner only |
| `GET/PUT /workspace/alert-rules` | Owner only. Check now: `POST /workspace/alert-rules:check` |
| `GET/PUT /analyses/{id}/delivery/recipients` | Selection, always list, scope toggle |
| `POST /recipients/external-requests` | Ask admins to approve an address |
| `POST /analyses/{id}/deliveries` | Send the email. Returns a Delivery in `sending` state |
| `GET /analyses/{id}/deliveries` | History |
| `GET /analyses/{id}/export.csv` | CSV scoped to the caller |
| `PUT /analyses/{id}/schedule` | Create or update |
| `GET /notifications`, `POST /notifications/{id}/read` | Bell |
| `POST /discovery/searches` | Run a search. Body: focus, guidelines, region, sources, exclusions. The server builds the brief |
| `GET /discovery/searches/{id}` | Results with computed confidence and fit |
| `PUT /analyses/{id}/shortlist` | Shortlist and notes |

### Real-time events (SSE or WebSocket)

`model_run.progress`, `model_run.done`, `order_line.updated`, `approval.changed`, `delivery.recipient_status`, `notification.created`. The prototype simulates these with timers.

## Requirements the prototype cannot show

**Security and privacy**
- Enforce roles and store scope on the server for every read and write, including CSV export and email scope.
- Treat all search and model output as untrusted. Escape text. Allow only `http` and `https` links. Never let a search result change permissions or settings.
- The discovery brief must contain only what `docs/04-business-rules.md` section 4.10 lists. Log what was sent. Keep an off switch for automatic search.
- Email recipients must be validated server-side against the workspace list and the approved external list.
- Audit trail for approvals, edits, resets, setting changes and sends. Immutable.

**Reliability**
- Model runs are jobs. Progress survives page reloads and users leaving. Completion creates a notification even if nobody is connected.
- Quantity edits are optimistic in the UI but saved per line. Show "Not saved" if a save fails.
- Concurrent edits: last write wins per line, but show the editor's name and warn when a line changed since it was loaded.
- Idempotent send: a double-click must not email twice.

**Performance**
- Order lines: server-side filter, sort, group and pagination. Virtualise rendering above about 200 rows. Group headers need server-side totals (units, cost, to-review count).
- Chart series: aggregate on the server by period. Return completeness (days with data vs days in period).

**Internationalisation**
- Currency, number and date formats should come from the workspace. The prototype uses `$`, `en-GB` separators and "27 Oct". Time zone matters for schedules and the "next check" times.
