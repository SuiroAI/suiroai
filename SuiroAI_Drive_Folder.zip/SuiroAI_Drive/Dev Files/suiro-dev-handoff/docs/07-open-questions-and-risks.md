# 7. Open questions and risks

Decisions we need before or during the build. Each has a suggested default so work can start.

## Product decisions

| # | Question | Why it matters | Suggested default |
| --- | --- | --- | --- |
| 1 | Should store managers set their own alert limits for their stores, or only the owner for the whole workspace? | Today only the owner can. Stores with different products may need different limits | Owner sets defaults. Managers may tighten (never loosen) for their own stores |
| 2 | Should a supplier minimum shortfall offer a one-click top-up that adds the suggested lines for review? | Today it is text only. One click is faster, but changes quantities and resets approvals | Add a "Review top-up" step that previews the changes before applying |
| 3 | Should "Stock-out risk" be split out of "Act now"? | In the sample, most "Act now" entries are stock-out risk, which makes the group large | Split into "Act now: supplier and expiry" and "Low stock", or hide the flag when this week's order already covers the gap |
| 4 | Can an owner approve on behalf of a store? | Removes a blocker when a manager is away, but weakens "named approver" accountability | No. Add a delegate instead. Allow owner override only with a recorded reason |
| 5 | Should the "Tech" check use a launch or end-of-life date instead of months on sale? | Months on sale is a rough proxy for going out of date | Use a launch or end-of-life column when present. Fall back to months on sale and say so |
| 6 | What is the "existing business method" baseline when it cannot be replayed? | The model table shows a score for it. The score is an estimate unless the method is "previous weekly average" | Label as "Estimated" unless replayed, as the prototype does |
| 7 | Do users need to change the forecasting model, or only see the recommendation? | Choice adds support burden and risk | Keep choice, default to recommended, record who chose what |
| 8 | Should viewers get a read-only export? | Finance may need the numbers but cannot export today | Allow CSV for viewers if the owner turns it on |
| 9 | How long do approvals stay valid? | A Monday approval may be stale by Thursday | Expire approvals when the underlying data is refreshed |
| 10 | Should the Ideas search run automatically on opening the tab? | It sends a brief without a click | Keep it on, with the disclosure and the off switch, but ask the owner to approve it once |

## Data and modelling

| # | Question | Notes |
| --- | --- | --- |
| 11 | Real model evaluation. The prototype's five scores are illustrative | Data science must confirm the four metric definitions in `docs/04-business-rules.md` and the way "recommended" is chosen |
| 12 | Unit cost source. The prototype assumes it comes from the supplier rules file, and two products have none | Decide the file format. Decide whether value minimums can be computed when some lines have no cost (currently shown as partial, `+`) |
| 13 | Customer and receipt IDs, promotions calendar, expiry dates, returns | Not in the sample files. Each unlocks a "Not enough data" measure. Decide which are in scope for launch |
| 14 | Seasonality. With under a year of history the system cannot confirm yearly patterns | Keep the caveat. Do not forecast holiday lifts without last year's sales |
| 15 | Same week last year as the owner's method | Needs a year of history |

## Risks

| Risk | Impact | Mitigation |
| --- | --- | --- |
| **Ownership and identity claims** in the Ideas search (women-owned, minority-owned, Black-owned, LGBTQ+-owned, veteran-owned) | Wrong or outdated claims, stereotyping, legal and reputational risk | Show "matched" only when a cited source explicitly states it, never infer from names or photos, always say "confirm with the supplier". **Get legal and privacy review before launch** |
| Search results are wrong, promotional or fabricated | Bad buying decisions | Sources are linked, confidence reflects evidence not popularity, results are leads not orders, fabricated sources are dropped. Consider a human review step |
| Brief leaks business data | Privacy | Only categories, price ranges, regions, focus and guidelines. Log every brief |
| Permissions only enforced in the UI | Data exposure | Enforce on the server. Add tests for every row in the roles table |
| Email delivery assumptions | "Sent" is not "received" | Say what "Sent" means. Surface bounces when the provider reports them |
| Alert fatigue | People ignore alerts | Grouping by priority, digest-style stock checks with "new" counts, owner-controlled frequency. Measure open and action rates |
| Large catalogues | Order list slow | Server-side pagination and virtualisation (see `docs/05-data-model-and-api.md`) |
| Mobile | Not designed or tested | Decide whether the order list and approvals are needed on phones. Approvals and notifications probably are |
| Accessibility gaps | Exclusion, legal | Known gaps are listed in `docs/06-accessibility.md` |
| Sample content mistaken for real | Loss of trust | Keep every sample and example label. Remove the two preview toggles and the "Acting as" switcher from production |

## What changed in the handoff pass

See "Known issues fixed while preparing this handoff" in `README.md`.
