# 3. Screens and flows

Screenshots are in `screenshots/`. Function names are in `src/app.js`.

## Primary flow

```mermaid
flowchart LR
  A[1 Upload data] --> B[2 Confirm task]
  B -->|Approve and analyze| C[3 Test models]
  C -->|running: user may leave| C
  C -->|results ready| D[4 Business report]
  D --> E[5 Review and edit]
  E --> F[Approvals: each store, then owner]
  F --> G[Delivery: download, email, schedule]
  D -. add data later .-> H[Stale banner: re-run analysis]
  H --> B
```

The stepper is always visible. A later step is reachable only when earlier steps are valid. Adding files after a report exists keeps the report and shows a "re-run" banner, so no work is lost.

## Screens

| # | Screen | Function | Screenshot |
| --- | --- | --- | --- |
| 1 | Upload data | `s1` | `01-upload-data.png` |
| 2 | Confirm task | `s2` | `02-confirm-task.png` |
| 3a | Models running | `s3` (running) | `03-models-running.png` |
| 3b | Compare models | `s3` (done) | `04-models-compare.png` |
| 4 | Business report, six tabs | `s4` | `05`, `06`, `07`, `08`, `09`, `10`, `11` |
| 5 | Review, approve, deliver | `s5` | `12` to `19` |

### 1. Upload data
- **Purpose:** state the decision as a question, add files, optionally record how it is decided today.
- **Content:** editable question (200 characters), decision note (owner only), file list with content type, rows and columns, date range, add and remove, totals.
- **Primary action:** Review my task. Disabled until the question is not empty and the required files (sales history, stock on hand) are present.
- **States:** no files (empty message), files present, reading a CSV (rows and columns are counted in the browser), role without edit rights (note is read-only).

### 2. Confirm task
- **Purpose:** show what will be answered and whether the data is good enough, before anything runs.
- **Content:** the question, a four-step plain description of the workflow, the owner's decision note if present, a readiness table per information type (Ready, Check, Missing) with what was found, a warning that promotions and events are not included, and an add-file action.
- **Primary action:** Approve and analyze. Disabled when a required file is missing. Nothing runs until this is pressed.

### 3. Test models
- **Running:** progress bar and per-model status. A card says "You can leave this page. We'll alert you here when the results are ready", with checkboxes for in-app alert and email. If the user leaves, a banner on every screen shows progress. On completion, if the user is elsewhere, the bell gets "Results ready" and a banner offers "View results". If the user stayed, nothing extra.
- **Results:** recommended model banner, table of models with four business metrics, four metric explainer cards for the selected model, what the model looked at (share of influence and source file), a methods matrix.
- **Primary action:** Generate business report.

### 4. Business report
Six tabs: **Summary, Data, Customers, Products, Trends, Ideas.**

| Tab | Purpose | Key content |
| --- | --- | --- |
| Summary | What to do and what to watch | KPIs (SKUs, units, order value, entries to review), grouped alerts, folded stock health, folded comparison with the owner's method, largest orders |
| Data | Understand the data | Averages, time-series chart (period, measure, store, moving average), store share, busiest days, concentration, stock health, predictable demand (searchable, with drivers), data quality |
| Customers | Say what we cannot know, and what we can | "Customer data isn't in your files yet", what sales already show, a table of customer measures marked Not enough data |
| Products | Contribution and dependence | Revenue by category, supplier dependence with lead time and minimum, lifecycle and class counts, margin, a searchable product table |
| Trends | Where demand is heading | Rising and slowest products, category momentum, six-week outlook with range, upcoming dates, order-by dates by supplier, market context (not connected), decisions to consider |
| Ideas | Products and brands to consider | Search of public sources against the range and sourcing guidelines, filters, opportunity cards, shortlist |

### 5. Review, approve, deliver
- **Order list:** see `docs/02-components.md`. Edits are attributed ("was 20 · Priya"). Notes per line. Feedback box for reviewers.
- **Approvals:** each store by its manager or a named delegate, then the business owner. Reminders and escalation are configured here by the owner.
- **Delivery** unlocks when every approval is complete **and** the user is allowed to export. Cards: Download CSV, Email report, Recurring report. Recipients are chosen above them.

## Roles and what each can do

| Capability | Business owner | Store manager | Delegate | Viewer |
| --- | --- | --- | --- | --- |
| View everything | Yes | Yes | Yes | Yes |
| Edit quantities, notes, mark reviewed | All stores | Own stores | Own stores | No |
| Approve a store | No (signs off at the end) | Own stores | Own stores | No |
| Final sign-off | Yes, after all stores | No | No | No |
| Decision note | Edit | Read | Read | Read |
| Reminder settings, alert rules, supplier minimums, sourcing guidelines | Edit | Read | Read | Read |
| "Remind now" | Yes | No | No | No |
| Choose recipients, send email, schedule | Yes | Yes | Yes | No |
| Set "Always send to" | Yes | No | No | No |
| Download CSV | All stores | Own stores | Own stores | No |
| Run an Ideas search | Yes | Yes | Yes | Yes |

A person may be manager of one store and delegate of another. **All of these must be enforced on the server.** The prototype only hides or disables controls.

## Cross-cutting behaviour

- **Editing resets approvals.** Editing a store's quantities resets that store's approval and the final sign-off, logs it, and tells the editor.
- **Late uploads.** Adding a file on a report tab keeps the report and shows "You added data after this report was made. Re-run analysis."
- **Notifications.** Kinds: reminder, escalation, request ("Remind now"), stock alert, results ready. Each opens the right place. Delivered in the app and optionally by email.
- **Activity log.** Approvals, resets, reminders, stock checks, sends, minimum changes and note changes are recorded with who and when.
- **Auto search (Ideas).** On first opening the tab, a search runs with saved settings. This is disclosed in the card, the brief that is sent is viewable, and it can be turned off.

## States every screen must handle (not all are mocked)

| State | Expected behaviour |
| --- | --- |
| Loading | Skeleton or spinner with a one-line explanation. Never a blank page |
| Empty | One sentence and one recovery action |
| Partial data | Show what can be computed, mark the rest "Not enough data" with what unlocks it, mark partial totals with `+` |
| Error | What happened, what to do, a retry. Live search failure falls back to a clearly labelled state |
| No permission | Control visible but disabled, with a tooltip or note saying who can do it |
| Offline or slow | Keep local edits, show "Not saved" until confirmed |
