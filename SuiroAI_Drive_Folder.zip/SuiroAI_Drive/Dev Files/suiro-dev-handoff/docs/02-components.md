# 2. Components

Class names refer to `src/styles.css`. Function names refer to `src/app.js`. See each component live in `design-system.html`.

**How to read the specs.** *Data* is what the component needs. *States* lists every state to build. *Behaviour* covers interaction. *A11y* is what must be true for keyboard and screen-reader users.

## Foundations

### Button
- **Variants:** primary (`.btn.primary`), default (`.btn`), danger (`.btn.danger`), ghost (`.btn.ghost`), small (`.btn.sm`).
- **States:** default, hover, focus-visible (3px teal ring), disabled (grey fill, `not-allowed`).
- **Rules:** one primary per view. Minimum height 44px (32px small). A disabled primary explains why nearby ("Analysis will not run until you approve this task.").
- **Related:** text button `.lnk` (underlined, blue, used inline in sentences), note button `.notebtn`, icon button `.iconbtn` (needs `aria-label`).

### Status, chip, tag, pill
| Component | Class | Variants | Use |
| --- | --- | --- | --- |
| Status | `.status` | `ok`, `warn`, `bad`, `idle`, `teal` | State of an object: Approved, Pending, Recommended, Sent. Always has text. |
| Chip | `.chip` | `up`, `seas`, `warn`, `bad`, `watch`, `pos`, `neg`, `flat`, `more` | A signal on a row or card. `.chip.more` is a button ("+2 more"). |
| Tag | `.tag` | none | Neutral label: category, price |
| Pill | `.pill` | `bad`, `warn` | A number that needs attention inside a cell (cover 0.9 wks) |
| Priority chip | `.sevchip` | `act`, `review`, `watch` | Counts in the alerts header |

### Filter chip (toggle)
`.chips > button[aria-pressed]`. Optional count `<span class="n num">`. Variant `.must` is the strict state of a three-state guideline chip (off, nice to have, must have): press cycles the state. Disabled when the user lacks permission. **A11y:** `aria-pressed`, and for the three-state chip an `aria-label` that says the current state ("Women-owned, must have. Press to change.").

### Segmented control and tabs
- Segmented control `.seg > button[aria-pressed]`: switch between 2-5 views of the same data (By store, By product).
- Tabs `.tabs[role=tablist] > button[role=tab][aria-selected]`: switch between sibling pages (Summary, Data, Customers, Products, Trends, Ideas). Tab titles are single nouns. Wraps on narrow screens. Label may carry a count: "Ideas (2)".

### Stepper
`.stepper > button` with `.done`, `.now` or `disabled`. Five steps. A step is reachable only if earlier steps are valid (`maxStep()`). Label shows "Step 3 of 5 · Test models", plus " · running" while a model run is active. Labels hide below 900px. **A11y:** `aria-current="step"` on the current step.

### Form field
`.fld` wraps a `<label>` and an `<input>`, `<select>` or `<textarea>`. Labels sit above. Help text is `.small.muted`. Messages: `.msg.err`, `.msg.ok`. Checkbox with help: `.check` (input never shrinks). Large question input: `textarea.q`. File drop zone: `.dropzone` (must also offer a "browse" button, because drag-and-drop is not keyboard accessible).

### Quantity stepper
`.qty` (− input +). `.qty.changed` (orange outline) with `.chg` caption "was 20 · Priya" when the value differs from the suggestion. Disabled when the user cannot edit that store (tooltip: "Only LON-01 approvers can edit"). Typing commits on change. Minimum 0, integers only.

### Card, KPI, stat, notice, empty
- `.card` with optional `.card-head` (title and one-line description left, actions right).
- KPI `.card.kpi` (`.v` value, `.l` label, `.s` sublabel). Grid `.kpis` or `.kpis.k4`. Warning variant `.kpiwarn` tints the value orange.
- Stat tile `.card.stat` (`h4`, `.v`, `.basis`). `.stat.na` is the "Not enough data" state: grey value, basis says what unlocks it.
- Notice `.notice.info|warn|ok|bad` (`h3`, `p`, optional button). Use for page-level messages, not for field errors.
- Empty `.empty` with one recovery link ("Clear filters").

### Progress and bars
- `.progress-wrap > .progress-fill` for a running job (`role=progressbar`, `aria-valuenow`).
- `.bar > i` for a value in a table or list (`.best` is the recommended item).
- `.prog > i` for a target (supplier minimum). Green when met, orange when short.
- `.hbar` horizontal bar rows. `.vbar` and `.vrow` for variation. `.rng` for a likely range (bar plus a marker).

### Menu
`.menu` (absolute, below its trigger, right-aligned). Items: `a[role=menuitem]` or `button.mi` with a `.ck` check column. Closes on outside click and Escape. Trigger has `aria-haspopup` and `aria-expanded`. Arrow keys move between items in the account menu. Used for: account, notifications, quick select.

### Drawer and dialog
- Drawer `.drawer` (right, 440px max, header, scrolling body, footer) over `.scrim`. `role=dialog aria-modal=true aria-labelledby`. Closes on scrim click, close button and Escape. Focus moves to the close button on open and returns to the trigger on close.
- Dialog `.modal` (centred, 480px max) for confirmations. Primary button is focused on open. Escape and Cancel close without side effects.

### Toast
`.toast` (bottom centre, auto-dismiss after 2.6s). One short sentence. Never the only record of something important: the same event also appears in the activity log or history. Container is `aria-live="polite"`.

### Notification bell
Header button with unread badge `.badge`. Menu `.menu.notif` lists up to 8 items, newest first (kind label, time, text). Unread items have a blue dot and tint. "Mark all read". Choosing an item marks it read and opens the relevant place: approvals, stock card, or the model results.

## Page patterns

### Header
3-column grid: logo left (`.logo`), navigation centred (Home, Dashboard, Reports, Data sources), bell and account menu right. Sticky. 72px. Account menu: Profile, Account settings, Team and permissions, Notification preferences, Billing and plan, Help and support, then Log out.

### Page head
`.page-head`: H1, one-line subtitle. Max width 720px. On report tabs the H1 stays "Your business report" and the subtitle changes per tab.

### Grouped alerts (summary)
`attentionCard()`. Four groups, always in this order: **Act before ordering**, **Review before approving**, **Keep an eye on**, **Looking ahead**. Each group is a collapsible row (`.agrp > .ghead`) showing a coloured dot, name, count and a one-line preview of its alert titles. Only the first group that has alerts starts open. An open group shows 3 alerts then "Show N more". Each alert (`.alert`) has an icon, title, one sentence and one button. The header shows totals: "2 to act on · 3 to review · 3 to watch".
- **Data:** alerts `{ group, severity, title, detail, action }`.
- **A11y:** group header is a `<button aria-expanded>`.

### Folded card
`.foldh` button that shows a card's title and a one-line summary and expands in place (stock health, comparison with the owner's usual method). State is remembered while the page is open.

### Attention bar (order list)
`.attn`: "Entries needing attention" plus three priority buttons with counts (Act now, Review, Watch), which filter the list, plus one "View suppliers (N below minimum)" link. Hidden when nothing is flagged.

### Order list table
The core screen. Toolbar: Search, Show (grouped options: Priority, Type, Other), Group by (Store, Product, Category, Supplier, What needs attention, None), Sort by. Summary line: entries shown, SKUs, units, order value, edited, to review. Tools: Hide zero orders, Collapse all, Expand all, Mark visible reviewed.

Table columns: **Product** (name, supplier, pack size; sticky), **Stock** (on hand, cover with pill, incoming), **Last restock**, **Demand, last 2 wks** (change, weekly pace, seasonal chip), **Order** (suggested, quantity stepper, cost at cost), **Flags and notes**.
- Group header rows `.group-head` show name, entry count, units, cost, and for supplier grouping the minimum status. Collapsible. "Mark N reviewed" button.
- Flags: at most two chips, in priority order, then `+N more` (toggles the rest). Priority colours: act = red (`.chip.bad`), review = orange (`.chip.warn`), watch = teal (`.chip.watch`).
- Table scrolls inside a 640px box. Header and first column are sticky. Minimum width 960px.
- Rows the user cannot edit show a disabled stepper with a tooltip.
- **Scale:** the prototype renders every row. Production should virtualise above ~200 rows and paginate server-side.

### Supplier minimums drawer
Opened from the attention bar or the "3 suppliers below minimum" alert. Search, "Only show suppliers below minimum" (on by default), list sorted worst first. Each supplier shows: name and status, the rule in words ("Needs 120 units or $3,500 (either one)"), one progress bar per measure, a top-up suggestion, "Show entries" (filters the list and closes) and, for the business owner, "Edit minimum" (units, value, and both-or-either).
- If a line has no unit cost, value is partial: show `+` and "excludes N units with no cost".

### Model comparison row
`.mrow` grid: radio + name + tag, accuracy bar and value, typical error, shortages caught, unneeded orders. `.mrow.sel` highlights the chosen row. Running state: waiting, testing (spinner), done. The recommended row has a `Recommended` status.

### Metric explainer cards
Four cards for the chosen model: value, name, one-sentence definition, an example in the user's terms ("Of 100 reorder suggestions, 9 weren't needed. Your current method: 17."). Definitions are fixed (`docs/04-business-rules.md`).

### Influence list and method matrix
`.feat` rows (label with data source, bar, share) show what the model looked at. A dot matrix (1-3 dots) compares methods on trends, store-by-store and ease of explanation.

### Time-series chart
`chartCard()`. Controls: period (Daily, Weekly, Monthly, Quarterly, Yearly), measure (Units, Sales), store, moving average. A period is disabled when there are too few complete periods, and the reason is in its tooltip and below the chart. Partial periods are hollow points and excluded from comparisons. Hover or touch shows a tooltip (value, per-day average, change vs previous). Keyboard: focus the chart, Left/Right/Home/End move the cursor, Escape clears. Values are announced via a live region. The chart is an `aria-hidden` SVG with a text alternative.

### Approvals table
One row per store plus the final sign-off. Columns: approval, who can approve (name and role), order units, status, action. Status: Pending, Overdue (with "waiting 26h, 1 reminder sent, next in 22h"), Approved (who and when), Changes requested. Buttons appear only for people who may act. The final sign-off unlocks after every store approves. Owner-only "Remind now" (1 hour cool-down). Activity log below.

### Reminders settings
Owner only. Toggle, "Remind after" (number plus hours or days), repeat (never, 12h, 24h, 48h), channels (push, email), escalate to the owner after two reminders. A plain-English summary line states exactly what will happen.

### Recipient picker
Search, **Quick select** menu (Everyone, roles, store teams, Clear), list grouped as "Always send (N)" then "Everyone else". Each row: checkbox, name, role and email, tag (Workspace, Approved external, Pending), and for the owner an "Always" toggle. "Add someone outside this list" is collapsed. Unknown external addresses can be sent for admin approval but never selected. A checkbox limits store managers to their own stores' lines.

### Send confirmation and delivery history
Dialog states the file, the recipient count and names, and the scope rule. After sending, the email card shows "✓ Sent · 8 people · time" and **Delivery history** lists each send with per-recipient status (Queued, Sent) and what each person receives. "Sent" means handed to the mail server.

### Decision note
Owner-only card on step 1: multi-select method chips, free text (300 characters), save with author and time, earlier versions kept. Read-only for others. Shows a warning if the question changed since it was written. Referenced on step 2, step 3 and step 5, and drives the "Compared with how you decided before" card.

### Stock alert rules
Folded card on the Summary. Rules table with one row per category: stock type (Standard, Long-life, Perishable, Tech), alert limit (days or months), check frequency (Daily, Weekly, Monthly, Quarterly), next check. Notify channels. "Check now" and "Reset to defaults" for the owner. Results are grouped by category with each group's rule in its header.

### Product opportunity card
`.opp`: brand and product, location, category, price, momentum, confidence, one-sentence reason, **Your guidelines** row (✓ matched, ? not stated, ✗ doesn't match, with "must" marked), **Range fit** row, overlap with your products, expandable evidence (linked sources) and risks, and "Add to shortlist" / "Not interested". Hidden when a must-have guideline is not met, with a count and a "Show them" link. Selected state `.opp.sel`.

### "Not enough data" patterns
Used wherever a measure cannot be computed: grey stat tile, or a table row with status `Not enough data`, always with what unlocks it and an "Add file" action. The prototype also has two preview toggles (example customer data, example expiry dates). Treat these as design aids only and do not ship them.
