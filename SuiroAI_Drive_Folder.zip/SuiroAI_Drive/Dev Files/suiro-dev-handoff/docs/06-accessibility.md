# 6. Accessibility

Target: **WCAG 2.2 AA**. This is what the prototype does, what it measured, and what is still missing.

## Colour contrast (measured from the tokens)

Ratios are WCAG contrast. Normal text needs 4.5 or more; large text and UI parts need 3 or more.

| Pair | Light | Dark |
| --- | --- | --- |
| Body text (`--ink` on `--surface`) | 14.16 | 14.23 |
| Secondary text (`--ink-2` on `--surface`) | 6.29 | 7.75 |
| Tertiary text (captions, hints) (`--ink-3` on `--surface`) | 5.33 | 5.00 |
| Secondary text on page background (`--ink-2` on `--bg`) | 5.93 | 8.49 |
| Link and text button (`--blue` on `--surface`) | 6.74 | 5.77 |
| Primary button label (`--on-blue` on `--blue`) | 6.74 | 6.35 |
| Teal ink on teal wash (Recommended, watch) (`--teal-ink` on `--teal-wash`) | 5.11 | 6.24 |
| Teal ink on surface (field labels, current step) (`--teal-ink` on `--surface`) | 5.79 | 7.96 |
| Orange ink on orange wash (warnings) (`--orange-ink` on `--orange-wash`) | 5.82 | 8.80 |
| Red on red wash (errors, flags) (`--red` on `--red-wash`) | 4.64 | 5.83 |
| Red on surface (`--red` on `--surface`) | 5.44 | 6.27 |
| Green ink on green wash (success) (`--green-ink` on `--green-wash`) | 5.38 | 6.05 |
| Blue on blue wash (selected chips) (`--blue` on `--blue-wash`) | 5.98 | 5.17 |

All listed pairs pass 4.5:1 in both themes. Before this handoff, tertiary text (3.45), teal text (3.24 on a teal wash, 3.67 on white) and green text (3.83) failed in light mode. They now use `--ink-3`, `--teal-ink` and `--green-ink`. **Rule:** use `--teal-ink` and `--green-ink` for text, and `--teal` and `--green` only for fills, lines and dots. Not yet checked: text over the chart band, disabled states (exempt, but keep legible), and focus ring contrast against every background.

## Implemented in the prototype

- Visible focus: `:focus-visible` gives a 3px teal outline with a 2px offset.
- Reduced motion: all animation and transitions are removed.
- Landmarks and names: `header`, `nav` with labels, `main`. Icon-only buttons have `aria-label` (close, remove, bell, account).
- Toggle controls use native `aria-pressed` (chips, segmented, pins, attention buttons), `aria-expanded` (groups, folds, menus, details) and `aria-selected` (tabs). The stepper uses `aria-current="step"`.
- Dialogs and the drawer have `role="dialog"`, `aria-modal` and `aria-labelledby`. Escape closes menus, the drawer and the dialog. Focus moves into them and returns to the trigger.
- Menus support arrow keys (account) and Escape.
- Live regions: toasts, the model-run card and the chart readout use `aria-live="polite"`.
- Chart: keyboard focusable, arrow keys read values, Escape clears, values announced. The SVG itself is hidden from assistive technology and replaced by the readout and labels.
- Forms: every field has a visible label or an `sr`-only label. Disabled controls explain why nearby or in a tooltip.
- Status is never colour alone: chips and status carry text.
- Drag and drop upload always has a "browse" alternative.
- Dark mode and forced light and dark themes.

## Known gaps (to fix in the production build)

| Gap | Fix |
| --- | --- |
| Dialog and drawer move focus in but do not trap it | Trap focus, make the page behind `inert` while open |
| No skip link | Add "Skip to main content" as the first focusable element |
| Data tables have no captions and no `scope` on headers | Add `<caption>` (visually hidden is fine) and `scope="col"` or `row` |
| Collapsible table groups are a button inside a cell | Consider `role="row"` groups with `aria-expanded`, or a tree grid pattern |
| Toasts disappear after 2.6s | Give users longer, allow dismiss, and keep the event in a persistent log (already in the activity log) |
| Tooltips are native `title` only | Provide an accessible description (`aria-describedby`) for disabled-control reasons and chip explanations |
| Tabs do not implement arrow-key roving focus | Follow the WAI-ARIA tabs pattern |
| Segmented and chip groups are tab-stops per button | Acceptable, but consider a single stop with arrow keys for long chip lists |
| Stepper "disabled" steps give no reason | Add a description ("Finish step 2 to continue") |
| Touch targets under 44px (small buttons are 32px, chips about 30px) | Keep a 24px minimum (WCAG 2.2) and enlarge on touch devices |
| Mobile layouts not audited | Test at 390px and 820px. Tables need a card layout or horizontal scroll with a visible hint |
| Language and reading order | Set `lang`, test reading order of the sticky first column |
| Screen reader testing | Test with VoiceOver and NVDA, and keyboard-only |

## Test checklist per component

1. Operable by keyboard alone, in a logical order, with a visible focus ring.
2. Name, role and state are announced (for example "Women-owned, must have, toggle button, pressed").
3. Works at 200% zoom and 400% reflow without losing information.
4. Works in light, dark and forced-colours mode.
5. Respects reduced motion.
6. Error and status messages are announced without moving focus.
