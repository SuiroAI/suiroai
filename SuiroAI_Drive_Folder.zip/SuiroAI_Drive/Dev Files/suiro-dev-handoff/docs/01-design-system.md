# 1. Design system

Open `design-system.html` next to this file. It renders everything below with the real stylesheet and has a Light and Dark switch.

## Principles

1. **Plain language.** Describe results in business terms ("Shortages caught: 93%"), then show the method name.
2. **Show your reasoning.** Every recommendation says why: sources, drivers, confidence, what was not used.
3. **Be honest about missing data.** "Not enough data" plus what would unlock it. Sample and example content is always labelled.
4. **People decide.** The system suggests. A named person edits, reviews and approves. Edits are attributed.
5. **Calm hierarchy.** Many signals are grouped by what to do first: act, review, watch. One primary action per view.

## Foundations

All values are in `tokens/`. Use the role names, never hex values.

### Colour

Roles are identical in light and dark. Only values change.

| Role | Light | Dark | Use |
| --- | --- | --- | --- |
| `--blue` | #3250c8 | #7c92ee | Primary actions, links, selected state |
| `--blue-wash` | #eef1fd | #1c2447 | Selected chips, secondary button fill, quiet info |
| `--teal` | #0093a5 | #3cc3d4 | Recommended, live, focus ring, chart emphasis |
| `--teal-ink` | #00707f | #3cc3d4 | **Teal text.** Passes AA on white and on `--teal-wash` |
| `--orange` / `--orange-ink` / `--orange-wash` | #f99d1b / #8a5200 / #fff3e0 | #f99d1b / #ffc46b / #3a2a10 | Needs a look: warnings, review flags, uptick |
| `--red` / `--red-wash` | #c0392b / #fbe9e7 | #ef7d70 / #3b1a16 | Needs action: errors, stock-out risk, expired |
| `--green` / `--green-ink` / `--green-wash` | #1f8a4c / #17703c / #e3f4ea | #4cc17f / #4cc17f / #143324 | Done or healthy. **Use `--green-ink` for text** |
| `--ink`, `--ink-2`, `--ink-3` | #2b2b2b, #606060, #6b6b6b | #ececec, #b0b0b0, #8c8c8c | Primary, secondary, tertiary text |
| `--line` | #e0e0e0 | #3a3a3f | 1px borders and dividers |
| `--bg`, `--surface`, `--surface-2` | #f7f8fc, #fff, #f7f8fc | #131418, #1c1d23, #16171c | Page, cards, recessed areas |
| `--beige-wash` | #faf6ef | #2a261f | Quiet grouping: table group headers, the attention bar |

Brand palette supplied by design: `#3250c8` blue, `#ebd3a2` beige, `#f99d1b` orange, `#0093a5` teal, black and greys. `--teal-ink`, `--green-ink` and `--ink-3` are accessibility additions to that palette.

Rules:
- Colour never carries meaning alone. Each status has a word, and often a dot or icon.
- Text colours go on matching washes only (for example `--orange-ink` on `--orange-wash`). Do not put `--teal` or `--green` text on a light background.

### Typography

Inter. Fallback: system UI sans. Base 15px, line height 1.5. Use tabular figures for every number (`font-variant-numeric: tabular-nums`).

| Style | Size / weight | Use |
| --- | --- | --- |
| Display | 40 / 700, tracking -0.02em | KPI numbers |
| Stat | 26-28 / 700 | Stat tile values |
| H1 | 32 / 650, line height 1.2 | Page title |
| H2 | 20 / 650, line height 1.3 | Card title |
| H3 | 16 / 650 | Section title |
| H4 | 14 / 650 | Small heading |
| Body | 15 / 400 | Default |
| Page subtitle | 16 / 400, `--ink-2` | Under the H1 |
| Small | 13 / 400 | Help text, table detail |
| Caption | 12 / 600 | Chips, tags |

Weights in use: 400, 500, 600, 650, 700, 750 (logo only). If your font does not support 650, use 600.

### Space, shape, elevation

- Spacing: 8, 16, 24, 32, 48 (`--s1` to `--s5`). Smaller gaps (4, 6, 12) appear only inside compact controls.
- Radius: 8 (inputs, small buttons), 12 (buttons, notices, list items), 16 (cards), pill (chips, status), circle (avatars, dots).
- Cards are flat: 1px `--line` border, no shadow. Shadows are only for things that float (menus, toasts, drawers, dialogs).
- Layers: sticky first column 1, sticky table header 2, quick-select menu 15, header 20, account and bell menus 30, scrim 40, drawer and dialog 41, toast 50.
- Layout: page max width 1120, side padding 32 (16 on mobile), header 72 tall.
- Breakpoints: 1000 (two-column panels stack), 900 (navigation shows icons only, grids go single column, the stepper hides labels). Mobile has not been fully audited.

### Motion

Spinner (0.8s linear), progress width (0.4-0.5s), hover background (0.15s). Nothing else animates. Under `prefers-reduced-motion: reduce` all animation and transitions are removed.

### Icons

The prototype uses inline SVG strokes (1.7px, round caps, 18-20px) for navigation, plus text glyphs (✓ ✕ ! ▾ ▸ ↑) in chips and buttons. In production use one icon set with a matching stroke (Lucide fits) and keep a visible text label next to every status icon.

### Theming

`tokens/tokens.css` defines light on `:root`, dark under `prefers-color-scheme: dark`, and forced modes via `<html data-theme="light|dark">`. Tailwind users: `tokens/tailwind.theme.js` maps colours to the same variables, so no `dark:` classes are needed.

## Content guidelines

- **Sentence case.** "Review and edit orders", not "Review And Edit Orders".
- **Numbers.** Thousands separators (`1,234`). Currency with `$` and no decimals in summaries (`$31,945`). A trailing `+` means "partial": some lines had no cost. Percentages without decimals unless it matters.
- **Dates and times.** "27 Oct", "14:32". Durations in plain units: "waiting 26h", "in 5 days".
- **Not enough data.** Use exactly this phrase, then one line on what would unlock it ("Needs customer or receipt IDs").
- **Sample and example.** Label it ("Example only", "Illustrative scores"). Never show sample data as real.
- **Errors.** Say what happened, then what to do: "This person isn't in your workspace yet. Ask an admin to invite them under Team and permissions."
- **Metrics.** Use these labels and definitions everywhere (`docs/04-business-rules.md`): Forecast accuracy, Typical error, Shortages caught, Unneeded orders.
- **Roles.** Business owner, Store manager, Delegate, Viewer.
- **Buttons** start with a verb: "Review my task", "Approve and analyze", "Send report".
- **Never** use emoji, exclamation marks or marketing language in the product.
