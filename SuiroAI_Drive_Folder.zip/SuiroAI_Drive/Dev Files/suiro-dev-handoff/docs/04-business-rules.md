# 4. Business rules

Everything here is implemented in the prototype with sample data. Production should implement the same rules on the server and unit-test them (acceptance examples at the end).

## 4.1 Order suggestion

Per product and store:

- `weekly` = recent weekly sales pace (units per week).
- `trend` = sales over the last 2 weeks vs the 6 before, as a percentage.
- Target cover `THRESH` = 2.5 weeks.
- `need = weekly × (1 + trend/100) × 2.5 − onHand − incoming`
- `suggested = need > 0 ? ceil(round(need) / pack) × pack : 0` (round up to full packs).
- Cover (weeks) = onHand ÷ weekly.

Suggested quantities account for stock on hand, incoming deliveries and pack sizes. **Supplier minimums are checked, not forced.** The system flags a shortfall for a person to decide.

### Approaching low stock ("watch")
For lines with `suggested = 0`: `runway = (onHand + incoming) ÷ (weekly × (1 + trend/100))`. If runway is under `THRESH + 1` (3.5) weeks, the line is on watch. Days until it reaches the order threshold = `max(1, round((runway − 2.5) × 7))`. Label: "Reorder in ~3d".

## 4.2 Supplier minimums

Per supplier: `minUnits` (optional), `minValue` (optional), `logic` (`both` or `either`, only matters when both exist).

- `units` = sum of order quantities for the supplier across all stores.
- `value` = sum of `quantity × unitCost` for lines that have a unit cost. Lines without cost are excluded and the total is marked partial (`$31,945+`).
- Meets minimum when: only units set → `units ≥ minUnits`; only value set → `value ≥ minValue`; both set → both must pass (`both`) or either (`either`). No minimum set → always met. Nothing ordered → "Nothing to order".
- Shortfall: `shortUnits = max(0, minUnits − units)`, `shortValue = max(0, minValue − value)`.
- **Top-up suggestion:** take the supplier's fastest-selling product that has a cost. Units needed: for `both`, the larger of the unit shortfall and `ceil(shortValue ÷ unitCost)`; for `either` or a single rule, the smaller applicable one. Round up to the product's pack size.
- The owner can edit a supplier's minimums. Each change is logged.

## 4.3 Flags and priority

Each line gets a list of flags, each with a priority. Show at most two, highest priority first; the rest are behind "+N more".

| Priority | Flag | Condition |
| --- | --- | --- |
| Act | Expires in Nd · N at risk / Expired | Perishable category, expiry within the limit, and stock will not sell through |
| Act | Supplier min not met | Line quantity > 0 and its supplier is below minimum |
| Act | Ordering stock that isn't moving | Quantity > 0 and the line is "not moving" (and not reviewed) |
| Act | Ordering a model that may be going out of date | Quantity > 0 and the line is "tech out of date" (and not reviewed) |
| Act | Stock-out risk | Cover < 1 week and nothing incoming |
| Review | Large vs usual restock | `suggested ≥ 1.5 × lastRestock` and `suggested ≥ 15` |
| Review | Short history (new store) | New-store line with quantity > 0 |
| Review | Not a full pack of N | Quantity is not a multiple of pack size (appears after an edit) |
| Watch | No sale in Nd / N wks of cover | Not moving (below) |
| Watch | On sale N mo | Tech out of date (below) |
| Watch | Reorder in ~Nd | Approaching low stock (4.1) |

Review flags and the "Ordering…" act flags clear when someone presses **Mark reviewed**. A row's priority is its highest flag. Counts in the attention bar are numbers of entries, not alerts.

## 4.4 Stock alerts by category

Each category has a **stock type**, a **limit** and a **check frequency**. Changing the type resets the limit and frequency to that type's defaults.

| Type | Flags when | Default limit | Default check |
| --- | --- | --- | --- |
| Standard | Units on hand and no sale for ≥ N days | 30 days | Weekly |
| Long-life | Same, longer limit (slow goods such as toys) | 90 days | Quarterly |
| Perishable | Expires within N days and will not sell through before expiry. Needs expiry dates | 7 days | Daily |
| Tech | Product on sale ≥ N months (stand-in for going out of date) | 15 months | Monthly |

- Optional extra for Standard and Long-life: also flag cover above N weeks (default 12).
- Perishable at risk units = `onHand − floor(weekly ÷ 7 × daysToExpiry × (1 + trend/100))`. If expired, all on-hand units are at risk. Only entries with at-risk units > 0 are flagged.
- **Schedule.** Each category is checked on its own frequency. A check sends a summary only if something is flagged, and again each period while it stays flagged. The summary says how many are new since the last check.
- **Who hears:** store managers and delegates get a summary for their own stores ("LON-01: Laptops 2 going out of date; Desk 1 not moving"). The business owner gets one rollup across stores. Channels: push, email.
- **Baseline.** Items already flagged when alerts are first switched on are treated as known and are not announced as new.
- "Check now" (owner) runs every category immediately. If both channels are off nothing is sent.
- Only the business owner can change rules.

## 4.5 Approvals

- One approval per store, by anyone listed for that store (its manager or delegates). One final sign-off by the business owner, **only after every store is approved**.
- A person can request changes instead of approving. This is recorded with who and when.
- **Editing a store's quantities resets that store's approval and the final sign-off.** Log the reset.
- Delivery is locked until all approvals are complete and the user may export.

### Reminders and escalation (owner configures)
- Remind approvers who have not responded after N hours or days. Repeat every 12, 24 or 48 hours, or never. Channels: push, email.
- A pending approval is "Overdue" once the first reminder has been sent. The row shows time waiting, reminders sent and time to the next.
- Escalate: after two reminders unanswered, tell the business owner once for that store.
- "Remind now" (owner): immediate, once per hour per store.
- Waiting time restarts when a store is reset by an edit.
- The final sign-off reminders start when the last store approves.

## 4.6 Delivery and sharing

- **Allowed recipients:** workspace members and approved external contacts only. A typed address outside the list cannot be selected. External addresses can be sent to admins for approval. A workspace-domain address that is not a member is told to ask an admin to invite them.
- **Always send to:** the owner can mark people who receive every report, including scheduled ones. They cannot be unticked. Un-marking keeps them selected.
- **Scope:** if "Store managers and delegates receive only their own stores' lines" is on, they get only their stores. The owner and viewers get all stores. CSV downloads follow the same rule per user.
- **Confirm before sending.** After sending, record a history row with sender, time and per-recipient status (Queued → Sent). "Sent" means handed to the mail server.
- **Recurring report:** repeat (daily or weekly), day, time, and "require every approval before each report is sent" (on by default). Goes to the same recipients including Always.
- **Quick select** groups: Everyone, Business owner, Store managers, Delegates, Viewers, External contacts, and "Add a store's team". Group toggles on or off. Always-send people stay selected.

## 4.7 Forecast metrics (definitions to keep fixed)

Measured on recent weeks held back from training, per product-store-week.

| Label | Definition | Plain-language example |
| --- | --- | --- |
| Forecast accuracy | 100% − WAPE (weighted absolute percentage error) | "87% means forecasts were off by about 13% of units sold" |
| Typical error | Mean absolute error in units | "For something that sells ~25 a week, expect it to be about 3 units off" |
| Shortages caught | Recall of weeks that would have run out of stock | "Of 100 weeks that would have run out, 93 were flagged in time" |
| Unneeded orders | 1 − precision of reorder suggestions | "Of 100 reorder suggestions, 9 weren't needed" |

The recommended model is the best on accuracy that also catches the most shortages. Always show the user's existing method as a baseline. The prototype's scores are illustrative.

## 4.8 Comparison with the owner's usual method

- The owner records which methods they used (previous weekly average, same week last year, fixed reorder points, supplier minimums and pack sizes, experience) and free text.
- **Only "previous weekly average" is replayed:** `usualQty = ceil(round(weekly × 2.5 − onHand − incoming) / pack) × pack` (the same as 4.1 without the trend). The card shows total units for both, how many entries differ, and the five largest gaps with a reason.
- "Same week last year" needs last year's sales: say so and offer an upload. Other methods are shown as a reference note only.

## 4.9 Not-enough-data rules

| Measure | Needs |
| --- | --- |
| Customers per day, repeat rate, segments, lifetime value | Customer or receipt IDs |
| Average basket | Receipt IDs |
| Promotion response | A promotions calendar |
| Expiry alerts | Expiry or sell-by dates |
| Yearly and quarterly chart views | At least 2 full years / 4 full quarters of sales |
| Margin for a product | Unit cost for that product |
| Same week last year | Last year's sales |

A chart period is enabled only when there are enough complete periods: daily 28, weekly 8, monthly 6, quarterly 4, yearly 2. Partial periods are shown hollow and excluded from comparisons.

## 4.10 Ideas search

- **What is sent:** category names and price ranges, store regions, the focus, the guidelines and excluded brands. Never sales figures, customer data, product names or supplier names. Show the exact brief to the user.
- **Guidelines:** ownership (small or independent, women-owned, minority-owned, Black-owned, LGBTQ+-owned, veteran-owned, family-owned), place (based near my stores, in my stores' countries), practices (sustainable materials, fair labour, B Corp or similar, repairable, plastic-free packaging). Each is off, nice to have or must have.
- **Verification:** a guideline shows as matched only when a cited source explicitly states it. Never infer ownership or identity from a name or photo. Place is computed by the system from the returned location and the store regions.
- **Must have** hides ideas that do not match (with a count and a way to show them). **Nice to have** ranks them higher.
- **Confidence** (Low, Medium, High) reflects the number and independence of sources. Social-only evidence is always Low. It is not a popularity score.
- **Fit** is computed locally: category stocked, price between 75% of the category's lowest price and 125% of its highest, overlap with existing products, recent growth in that category.
- Output is capped at 5 ideas per run, each with at most 2 sources. All model output must be treated as untrusted: escape text, allow only http and https links.

## 4.11 Acceptance examples

1. *Given* a line with weekly 12, trend +14%, on hand 11, incoming 11, pack 10, *when* suggestions are computed, *then* need = 12 × 1.14 × 2.5 − 22 = 12.2 → rounds to 12 → suggested 20.
2. *Given* Kestrel needs 120 units **or** $3,500 and orders 103 units / $968+, *then* it is below minimum, and the top-up names its fastest seller.
3. *Given* Helix needs 80 units **and** $4,000 and orders 104 units / $3,900, *then* it is below minimum (value fails).
4. *Given* all stores are approved and the owner has not signed off, *then* delivery is locked.
5. *Given* LON-01 is approved and its manager edits a quantity, *then* LON-01 and the final sign-off return to Pending and the activity log records it.
6. *Given* a perishable item with 40 on hand, 5 a week with flat demand, expiring in 14 days, *then* sell-through = floor(5 ÷ 7 × 14) = 10, at-risk = 30, so it is flagged.
7. *Given* a "Must have: women-owned" guideline and an idea whose sources do not state it, *then* the idea is hidden and counted.
8. *Given* the model run is in progress and the user is on step 1, *when* it finishes, *then* the bell shows "Results ready" and a banner offers "View results".
9. *Given* an unknown external address typed in the recipient box, *then* it cannot be selected, and "Request admin approval" is offered.
10. *Given* a Viewer, *then* quantity steppers, quick select, send and download are all disabled.
