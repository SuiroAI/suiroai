// Rebuilds the single-file prototype from the files in src/.
// Usage:  node build.mjs
// Output: prototype/suiro-ai-prototype.html  (open it in a browser, or upload it to the Framer component)
import { readFileSync, writeFileSync } from "node:fs"

const html = readFileSync("src/index.html", "utf8")
const css = readFileSync("src/styles.css", "utf8")
const js = readFileSync("src/app.js", "utf8")

if (js.includes("</script>")) throw new Error("src/app.js contains </script>, which would end the inline script early")

const out = html
    .replace('<link rel="stylesheet" href="styles.css">', () => `<style>\n${css}</style>`)
    .replace('<script src="app.js"></script>', () => `<script>\n${js}</script>`)

writeFileSync("prototype/suiro-ai-prototype.html", out)
console.log("Wrote prototype/suiro-ai-prototype.html (" + Math.round(out.length / 1024) + " KB)")
